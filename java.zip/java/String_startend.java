import java.util.*;
import java.io.*;
class String_startend
{
public static void main(String...arg)
{
Scanner S=new Scanner (System.in);
String a,b;
String c;
System.out.println("enter string");
c=S.nextLine();
System.out.println("enter starting character");
a=S.nextLine();

System.out.println("enter ending character");
b=S.nextLine();
System.out.println(c.startsWith(a));
System.out.println(c.endsWith(b));
//String s1 ;
//System.out.println("enter string");

         //s1=S.nextLine(); 
         int s,d;
         System.out.println("enter source and destination");
         s=S.nextInt();
         d=S.nextInt(); 
         System.out.println(c.substring(s,d)); 
         
}
}

