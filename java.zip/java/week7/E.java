import java.util.*;
interface Fare
{
void getAmount(int n,int m);
}
class Bus implements Fare
{
public void getAmount(int t ,int c)
{
System.out.println("bus charge:"+(t*c));
}
}
class Train implements Fare
{
public void getAmount(int t,int c)
{
System.out.println("train charges:"+(t*c));
}
}
class E
{
public static void main(String[] ar)
{
Scanner s=new Scanner(System.in);
int a,b,c,d;
System.out.println("enter no.of  km and fare travelled by Bus");
a=s.nextInt();
b=s.nextInt();
System.out.println("enter no.of km and fare travelled by Train");
c=s.nextInt();
d=s.nextInt();
Fare B=new Bus();
Fare T=new Train();
B.getAmount(a,b);
T.getAmount(c,d);
}
}

