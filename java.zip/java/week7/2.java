import java.util.*;
abstract class Employee
{
abstract void getAmount(int n,int m);
}
class He extends Employee{
public void getAmount(int m,int wages)
{
System.out.println("Hourly employee"+(m*wages));
}
}
class We extends Employee
{
public void getAmount(int p,int wages)
{
System.out.println("Weekly employee"+(p*wages));
}
}
class A
{
public static void main(String[] arg)
{
Scanner s=new Scanner (System.in);
int a,b,c,d;
System.out.println("enter hours and wages of hourly employee");
a=s.nextInt();
b=s.nextInt();
System.out.println("enter hours and wages of weekly employee");
c=s.nextInt();
d=s.nextInt();
Employee h=new He();
Employee w=new We();
h.getAmount(a,b);
w.getAmount(c,d);
}
}
