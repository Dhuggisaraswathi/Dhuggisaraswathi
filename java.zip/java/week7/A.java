import java.util.*;
abstract class Shapes_abs
{
abstract void getArea(int r,int a);
abstract void getVolume(int r,int a);
}
class Calculations extends Shapes_abs
{
public void getArea(int r,int a)
{
System.out.println("area of the circle"+(3.14*r*r));
System.out.println("area of the cube"+(6*a*a));
System.out.println("area of the sphere"+(4*3.14*r*r));
}
public void getVolume(int a,int r)
{
System.out.println("volume of cube"+(a*a*a));

System.out.println("volume of the sphere"+(4*3.14*r*r));
}
}
class A
{
public static void main(String[] arg)
{
Scanner S=new Scanner (System.in);
System.out.println("enter the radius for circle &sphere");
int r=S.nextInt();
System.out.println("enter side for cube");
int s=S.nextInt();
Shapes_abs R=new Calculations();
R.getArea(s,r);
R.getVolume(s,r);
}
}

