import java.util.*;
interface Vehicle
{
void getColor(String c);
void getConsumption(int l,int fuel);
void getNumber(int n);
}
class Tw implements Vehicle
{
public void getColor(String c)
{
System.out.println("color of 2 wheeler" +c);
}
public void getNumber(int n)
{
System.out.println("number of 2 wheeler" +n);
}
public void getConsumption(int l,int fuel)
{
System.out.println("consumption of 2 wheeler:"+(l+fuel));
}
}
class Fw implements Vehicle
{
public void getColor(String c)
{
System.out.println("color of 4 wheeler" +c);
}
public void getNumber(int n)
{
System.out.println("number of 4 wheeler" +n);
}
public void getConsumption(int l,int fuel)
{
System.out.println("consumption of 4 wheeler:"+(l+fuel));
}
}
class C
{
public static void main(String[] arg)
{
Scanner s=new Scanner(System.in);
int n ,l,fuel;
String c;
System.out.println("Two wheeler");
System.out.println("enter number");
n=s.nextInt();
System.out.println("enter color");
c=s.next();
System.out.println("enter consumption litres and fuel");
l=s.nextInt();
fuel=s.nextInt();
System.out.println("four wheeler");
System.out.println("enter number");
int n1=s.nextInt();
System.out.println("enter color");
String c1=s.next();
System.out.println("enter consumption litres and fuel");
int l1=s.nextInt();
int fuel1=s.nextInt();
Vehicle t=new Tw();
Vehicle F=new Fw();
System.out.println("TWO WHEELER");
t.getColor(c);
t.getConsumption(l,fuel);
t.getNumber(n);
System.out.println("FOUR WHEELER");
F.getColor(c1);
F.getConsumption(l1,fuel1);
F.getNumber(n1);
}
}

