import java.util.*;
interface Payable
{
void getAmount(int m,int n);
}
class Cal implements Payable
{
public void getAmount(int m,int n)
{
System.out.println("amount paid to emp:"+(m*100));
System.out.println("invoice:"+((m*100)+n));
}
}
class B
{
public static void main(String[] arg)
{
Scanner s=new Scanner(System.in);
System.out.println("enter amount");
int A=s.nextInt();
System.out.println("enter extra amount");
int e=s.nextInt();
Payable p=new Cal();
p.getAmount(A,e);
}
}
