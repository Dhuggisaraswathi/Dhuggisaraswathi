import java.util.*;
interface StudentFee
{
void getAmount(int  fee);
void getFname(String Fn);
void getLname(String Ln);
void getAddress(String add);
void getContact(int con);
}
class Hostler implements StudentFee
{
public void getAmount(int f)
{
int hstlfee=3000;
System.out.println("fee paid by hostler"+(f+hstlfee));
}
public void getFname(String Fn)
{
System.out.println("Hostler first name"+Fn);
}
public void getLname(String Ln)
{
System.out.println("Hostler Lastname"+Ln);
}
public void getAddress(String add)
{
System.out.println("Hostler Address"+add);
}
public void getContact(int con)

{
System.out.println("hostler contact"+con);
}
}
class NonHostler implements StudentFee
{
public void getAmount(int f)
{
System.out.println("college fee"+f);
}
public void getFname(String Fn)
{
System.out.println("non hostler first name"+Fn);
}
public void getLname(String Ln)
{
System.out.println("non hostler last name"+Ln);
}
public void getAddress(String add)
{
System.out.println("non hostler address"+add);
}
public void getContact(int con)

{
System.out.println("non hostler contact"+con);
}
}
class T
{
public static void main(String[] arg)
{
Scanner  s=new Scanner(System.in);
int f,con;
System.out.println("enter fee");
f=s.nextInt();
System.out.println("enter first name");
String Fn=s.next();
System.out.println("enter Last name");
String Ln=s.next();
System.out.println("enter address");
String add=s.next();
System.out.println("enter contact");
con=s.nextInt();
StudentFee f1=new Hostler();
StudentFee f2=new NonHostler();
f1.getAmount( f);
f1.getFname(Fn);
f1.getLname(Ln);
f1.getAddress(add);
f1.getContact(con);
System.out.println("enter fee");
int f3=s.nextInt();
System.out.println("enter first name");
String Fn1=s.next();
System.out.println("enter Last name");
String Ln1=s.next();
System.out.println("enter address");
String add1=s.next();
System.out.println("enter contact");
int con1=s.nextInt();
f2.getAmount( f3);
f2.getFname(Fn1);
f2.getLname(Ln1);
f2.getAddress(add1);
f2.getContact(con1);
}
}

