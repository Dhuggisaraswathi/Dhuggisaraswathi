import java.util.*;
import java.io.*;
interface Studentfee
{
double getAmount();
String getLname();
String getFname();
String getAddress();
String getContact();
}
class Hostler implements Studentfee
{
String Fname;
String Lname;
String Address;
String contact;
double fee;
public Hostler(String Fname,String Lname,String Address,String contact,double fee)
{
this.Fname=Fname;
this.Lname=Lname;
this.Address=Address;
this.contact=contact;
this.fee=fee;
}
public double getAmount()
{
return fee;
}
public String getLname()
{
return Lname;
}
public String getFname()
{
return Fname;
}
public String getAddress()
{
return Address;
}
public String getContact()
{
return contact;
}
}
class Nonhostler implements Studentfee
{
String Fname;
String Lname;
String Address;
String contact;
double fee;
public Nonhostler(String Fname,String Lname,String Address,String contact,double fee)
{
this.Fname=Fname;
this.Lname=Lname;
this.Address=Address;
this.contact=contact;
this.fee=fee;
}
public double getAmount()
{
return fee;
}
public String getLname()
{
return Lname;
}
public String getFname()
{
return Fname;
}
public String getAddress()
{
return Address;
}
public String getContact()
{
return contact;
}
}
class Main
{
public static void main(String arg[])
{
Scanner Sc=new Scanner(System.in);
System.out.println("Hostler details");
System.out.println("enter First name");
String Fname=Sc.next();
System.out.println("enter Last name");
String Lname=Sc.next();
System.out.println("enter Address");
String Address=Sc.next();
System.out.println("enter contact number");
String contact=Sc.next();
System.out.println("enter hostel fee");
double fee=Sc.nextDouble();
Hostler H=new Hostler(Fname,Lname,Address,contact,fee);
System.out.println(H.getFname());
System.out.println(H.getLname());
System.out.println(H.getAddress());
System.out.println(H.getContact());
System.out.println(H.getAmount());
System.out.println("*******************************************************");

System.out.println(" Non-Hostler details");
System.out.println("enter First name");
String Fn=Sc.next();
System.out.println("enter Last name");
String Ln=Sc.next();
System.out.println("enter Address");
String Addr=Sc.next();
System.out.println("enter contact number");
String cont=Sc.next();
System.out.println("enter hostel fee");
double fe=Sc.nextDouble();
Nonhostler R=new Nonhostler(Fn,Ln,Addr,cont,fe);
System.out.println(R.getFname());
System.out.println(R.getLname());
System.out.println(R.getAddress());
System.out.println(R.getContact());
System.out.println(R.getAmount());
}
}





