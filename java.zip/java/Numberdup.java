import java.util.*;
import java.io.*;
class Numberdup
{
 public static void main(String... args)
 {
  int i;
  int n;
  Scanner M=new Scanner(System.in);
  System.out.println("enter the array size");
  n=M.nextInt();
  int a[]=new int[n];
  System.out.println("enter the elements into array between 10 and 100");
  for(i=0;i<n;i++)
  {
  a[i]=M.nextInt();
  }
  for(i=0;i<n;i++)
  {
  System.out.println(a[i]);
  }
   
 }
}
  
