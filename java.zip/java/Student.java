import java.util.*;
import java.io.*;
class Student
{
int id;
String name;
int marks;
Student(int i,String n,int m)
{
id=i;
name=n;
marks=m;
}
void display()
{
System.out.println("id+ " "+name+" "+marks+" "+);
}

public static void main(String[] arg)
{
int s,i;
Scanner N=new Scanner (System.in);

System.out.println("enter size");
s=N.nextInt();
int a[]=new int[s];
System.out.println("enter details like id ,name,marks");
for(i=0;i<a.length;i++)
{
a[i]=N.nextInt();
}
N.display();
}
}
