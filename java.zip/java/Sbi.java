import java.util.*;
import java.io.*;
interface Payable
{
double getAmount();
}
class Amount
{
double A;
public double getAmount()
{retrun A;
}
}

class Sbi
{
public static void main(String arg[])
{
Payable R=new getAmount();

double A;
Scanner S=new Scanner(System.in);
System.out.println("enter the amount");
A=nextDouble();
System.out.println(R.getAmount());
}
}

