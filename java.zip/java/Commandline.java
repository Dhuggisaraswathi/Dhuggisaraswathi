import java.util.*;
import java.io.*;
class Commandline
{
public static void main(String a[])
{
int i,n;
Scanner s=new Scanner(System.in);
System.out.println("enter the size");
n=s.nextInt();
for(i=0;i<n;i++)
{
System.out.println(a[i]);
}
}
}
