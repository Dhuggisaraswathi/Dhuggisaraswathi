import java.util.*;
import java.io.*;
interface Payable
{
double getAmont();
}
class Invoice implements Payable
{
String InNum;
double Amount;
Invoice(String InNum,double Amount)
{
this.InNum=InNum;
this.Amount=Amount;
}
public double getAmount()
{
return Amount;
}
}
class Employee implements Payable
{
Stirng Empld;
double salary;
Employee(String Empld,double salary)
{
this.Empld=Empld;
this.salary=salary;
}
double getAmount()
{
return salary;
}
}
class Am
{
public static void main(String[] arg)
{
Scanner S=new Scanner (System.in);
System.out.println("enter invoice number");
String InNum=S.next();
System.out.println("enter invoice amount");
double Amount=S.nextDouble();
Invoice I=new Invoice(String InNum,double Amount);

System.out.println("Amount"+I.getAmount());
System.out.println("enter the Emlpoyee id");
String Empld=S.next();
System.out.println("enter employee salary");
double salary=S.nextDouble();
Employee E=new Employee(String Empld,double salary);
System.out.println("Amount:"+E.getAmount());
S.close();
}
}

