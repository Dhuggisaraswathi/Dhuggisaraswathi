package pack2;
import pack2.*;
class A
{
public void display()
{
System.out.println("hello");
}
}

