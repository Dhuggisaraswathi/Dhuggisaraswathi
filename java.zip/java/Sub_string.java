import java.util.*; 
class Sub_String{
   public static void main(String args[]){
   Scanner S=new Scanner(System.in);
   System.out.println("enter any string");
   
   
         String s1 ;
         s1=S.nextLine(); 
         int s,d;
         System.out.println("enter source and destination");
         s=S.nextInt();
         d=S.nextInt(); 
         System.out.println(s1.substring(s,d)); 
         }}
