import java.util.*;
import java.io.*;
class  Vehicle
{
int Vehicle_no;
String Model;
String Milage;
String Fuel_type;
String color;
Scanner S=new Scanner (System.in);
void getDetails()
{
System.out.println("enter the vehicle number:");
Vehicle_no=S.nextInt();
S.nextLine();
System.out.println("enter vehicle model");
Model=S.nextLine();
System.out.println("enter the color");
color=S.nextLine();
System.out.println("enter the fuel type");
Fuel_type=S.nextLine();
System.out.println("enter the milage");
Milage=S.nextLine();
}
}
class two_wheeler extends Vehicle
{
void show()
{
System.out.println("basic details of two wheeler vehicle :\n"+"Vehicle_no"+Vehicle_no+"\n Model:" +Model+"\n color:"+color+"\nFuel_type:"+Fuel_type+"\nMilage:"+Milage);
}
}
class four_wheeler extends Vehicle
{
void show_details()
{
System.out.println("basic details of four wheeler vehicle :\n"+"Vehicle_no"+Vehicle_no+"\n Model:" +Model+"\n color:"+color+"\nFuel_type:"+Fuel_type+"\nMilage:"+Milage);
}

public static void main(String arg[])
{
System.out.println("enter the details of vehicles");
two_wheeler t=new two_wheeler();
four_wheeler f=new four_wheeler();

System.out.println("enter the details of two wheelers");
t.getDetails();
t.show();
System.out.println("enter the details of four wheeler");
f.getDetails();
f.show_details();
}
}


