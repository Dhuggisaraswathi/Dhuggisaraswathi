package org.shapes;

public class  Square1
{
public double getArea(int s)
{ 
return  s*s;
}
public double getPerimeter(int s)
{
return 4*s;
}
}
