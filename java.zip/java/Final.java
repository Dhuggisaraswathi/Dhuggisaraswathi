import java.util.*;
import java.io.*;

class Final
{
final void display()
{
System.out.println("Hello");
}
}
class B extends Final
{
void display()
{
System.out.println("child");
}
}
class C
{
public static void main(String[] arg)
{
B o=new B();
o.display();
}
}

