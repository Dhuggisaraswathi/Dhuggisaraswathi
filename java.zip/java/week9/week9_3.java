class traffic extends Thread
{
String s;
traffic(String s)
{
super(s);
this.s=s;
}
public void run()
{
int i=1;
while(true)
{
System.out.println(this.getName());
i++;
try
{
Thread.sleep(3000);
}
catch(InterruptedException e)
{
System.out.println(e);
}
}
}
}
class week9_3
{
public static void main(String args[]) throws InterruptedException 
{
traffic t1=new traffic("red");
traffic t2=new traffic("yellow");
traffic t3=new traffic("green");
Thread t11=new Thread(t1);
t11.setPriority(10);
t11.start();
Thread t22=new Thread(t2);
Thread.sleep(1000);
t22.setPriority(8);
t22.start();
Thread t33=new Thread(t3);
Thread.sleep(1000);
t33.setPriority(6);
t33.start();
}}
