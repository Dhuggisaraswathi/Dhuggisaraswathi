import java.util.*;
import java.io.*;
class CusException extends Exception
{
CusException(String Msg)
{super(Msg);
}
}
class Exception1
{
public static void main(String[] arg)
{
try
{
throw  Exception();
}
catch(CusException e)
{
System.out.println("caught exception:" +e.getMessage());
System.out.println("\n");
}
finally
{
System.out.println("finally block executed");
System.out.println("\n");
}
}
 void throwException() throws
CusException{
throw new CusException("custom exception");
//System.out.println("\n");
}
}
