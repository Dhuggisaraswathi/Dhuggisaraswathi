class MyThread extends Thread
{
public void run()
{
int i=1;
while(true)
{
System.out.println("kavya rangaiah "+ i);
i++;
try{Thread.sleep(1000);}
catch(InterruptedException e){}

}
}
}
class week9_2
{
public static void main(String args[])
{
MyThread t1=new MyThread();
t1.start();
//t1.interrupt();
}
}

