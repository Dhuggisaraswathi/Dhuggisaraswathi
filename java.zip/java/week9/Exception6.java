import java.util.*;
import java.io.*;
class Exceptionc extends Exception
{
String S;
Exceptionc(String M)
{
super(M);
this.S=M;
}
void  print()
{
System.out.println("stored string:" +S);
}
}
class Exceptione
{
public static void main(String[] arg)
{
Scanner S=new Scanner(System.in);
try{
System.out.println("enter any String");
String i=S.nextLine();
}
catch(Exceptionc e)
{
System.out.println("caught exception"+e.getMessage());
e.print();
}
finally
{
}}
}
