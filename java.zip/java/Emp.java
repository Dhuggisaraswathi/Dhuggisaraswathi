import java.util.*;
import java.io.*;
import java.lang;
class Emp
{
float sal=2000.88;
void show()
{
System.out.println(sal);
}
}
class Contract_emp extends Emp
{
float bonus=1000.22;
float total=sal+bonus;
void display()
{
System.out.println(total);
}
}
class A
{
public static void main(String[] arg)
{
Contract_emp.E=new Contract_emp();
E.show();
E.display();
}
}
