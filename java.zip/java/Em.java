import java.util.*;
import java.io.*;
abstract class Employee
{
abstract double getAmount();
}
class weeklyEmployee extends Employee
{
int Nweeks;
double Tweeks;
weeklyEmployee(int Nweeks,double Tweeks)
{
this.Nweeks=Nweeks;
this.Tweeks=Tweeks;
}
double getAmount()
{
return  Nweeks*Tweeks;
}
}
class hourlyEmployee extends Employee
{
int Nhrs;
double Thrs;
hourlyEmployee(int Nhrs,double Thrs)
{
this.Nhrs=Nhrs;
this.Thrs=Thrs;
}
double getAmount()
{
return Nhrs*Thrs;
}
}
class Em
{
public static void main(String[] arg)
{
Scanner S=new Scanner(System.in);
System.out.println("enter the no.of weeks");
int N=S.nextInt();
System.out.println("enter the total  weeks");
double T=S.nextDouble();
weeklyEmployee W=new weeklyEmployee(N,T);
System.out.println("Amount:"+W.getAmount());
System.out.println("enter the no.of Hours");
int H=S.nextInt();
System.out.println("enter the Total hours");
double A=S.nextDouble();
hourlyEmployee HR=new hourlyEmployee(H,A);
System.out.println("Amount:"+HR.getAmount());
}
}



