import java.util.*;
import java.io.*;
class Arraysum
{
public static void main(String[] arg)
{
int i,n;
Scanner s=new Scanner(System.in);
System.out.println("Enter the size");
n=s.nextInt();
System.out.println("enter the elements");
int a[]=new int[n];
for(i=0;i<a.length;i++)
{
a[i]=s.nextInt();
}
Test t=new Test();
Sum(a);
}

class Test
{
void Sum(int a[])
{
int s=0,i;
for(i=0;i<a.length;i++)
{
s=s+a[i];
}
for(i=0;i<a.length;i++)
{
System.out.println(s);
}
}
}
}
