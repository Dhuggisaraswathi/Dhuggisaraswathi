import java.util.*;
class product
{
int id;
String name;
int qty;
int price;
int tprice(int Q)
{
return(Q*price);
}
}
class week3_2
{
public static void main(String args[])
{
product p[]=new product[3];
p[0]=new product();
p[1]=new product();
p[2]=new product();
Scanner in=new Scanner(System.in);
for(int i=0;i<3;i++)
{
System.out.println("enter the details");
p[i].id=in.nextInt();
p[i].name=in.next();
p[i].qty=in.nextInt();
p[i].price=in.nextInt();
}
int total=0;
int x;
do
{
System.out.println("enter the id");
int id=in.nextInt();
System.out.println("enter the quantity");
int Q=in.nextInt();
switch(id)
{
case 1:total+=p[0].tprice(Q);
break;
case 2:total+=p[1].tprice(Q);
break;
case 3:total+=p[2].tprice(Q);
break;
default:
System.out.println("invalid");
}
System.out.println("do you want buy other enter 1");
x=in.nextInt();
}while(x==1);
System.out.println("total"+total);
}
}

