import java.util.*;
import java.io.*;
class MyThread extends Thread
{
public void run()
{
System.out.println("Thread is running");
}
}
class ThreadEx
{
public static void main(String[] arg)
{
MyThread M=new MyThread();
M.start();
Scanner s=new Scanner(System.in);
System.out.println("enter something and press enter");
String W=s.nextLine();
System.out.println("your Thread:"+W);//close();
}
}

