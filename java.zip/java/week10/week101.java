import java.util.*;
import java.io.*;
class MyThread extends Thread
{
public void run()
{
int j=0;
for(j=0;j<5;j++)
{
System.out.println("Threads class"+j);
}
}
public static void main(String[] arg)
{
MyThread m=new MyThread();
m.start();
int j=0;
for(j=0;j<5;j++)
{
System.out.println("main class "+j);
}
}
}

