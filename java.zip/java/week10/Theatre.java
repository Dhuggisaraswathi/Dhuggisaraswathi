import java.util.*;
import java.io.*;
class  Theatre implements Thread
{

 static synchronized  void run()
{
//int a[]=new int();
for(int i=1;i<n;i++)

{// a[i]=s.nextInt();

//Scanner u=new Scanner(System.in);
//a[i]=u.nextInt();
  static void buy()
{
try
{
Sytem.out.println(" person buyed ticket:"+i);
}

catch(Exception e)
{
}
}
public void show()
{
try{

System.out.println("person showed ticket"+i);
}

catch(Exception e)
{
}
}
public void enter()
{
try
{
System.out.println("person entered into theatre"+i);
}
catch(Exception e)
{}
}
}
}
}
class Te
{
public static void main(String[] arg)
{
Scanner s=new Scanner(System.in);
Theatre T=new Theatre();
int i,n;
System.out.println("enter how many  member to enter into the theatre");
Scanner s=new Scanner(System.in);
n=s.nextInt();

//int a[]=new int[n];

//System.out.println("enter size");
//n=s.nextInt();
T.start();
}
}
