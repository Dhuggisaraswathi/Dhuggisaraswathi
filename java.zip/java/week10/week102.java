import java.util.*;
import java.io.*;
class Consumer extends Thread
{
Scanner s=new Scanner(System.in);
/*public void checkproStatus()
{
System.out.println("no production status ever");
}*/
public void run()
{
for(int i=0;i<5;i++)
{if(i==4)
{
System.out.println("production is over"+i);
}
else
{
System.out.println("production is not over");
//Thread.sleep(100);
}


}
}
public static void main(String[] arg)
{
Consumer w=new Consumer();
w.start();
Thread.sleep(100);
}
}

