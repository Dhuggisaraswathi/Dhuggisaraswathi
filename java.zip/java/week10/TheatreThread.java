import java.util.*;
class entrance
{
synchronized  public void enter(int j)
{try{
System.out.println("person"+j+"buyed the ticket");
System.out.println("person"+j+"entered the theatre");
}
catch(Exception e)
{}

}
}
class person extends Thread
{
int j;
entrance s;
person(int e,entrance r){
s=r;
j=e;
}
public void buyTicket()
{
try{
System.out.println("person"+j+"showed the ticket");
}
catch(Exception e)
{}
public void run()
{
buyTicket();
s.enter(j);
}
}
}
public class TheatreThread
{
public static void main(String[] arg)
{
Scanner s=new Scanner(System.in);
System.out.println("enter no of persons:");
int n=s.nextInt();
person p[]=new person[n+1];
entrance e=new entrance();
for(int i=1;i<n;i++)
{
p[i]=new person(i,e);
for(i=1;i<n;i++)
{
p[i].start();
}
}
}
}
