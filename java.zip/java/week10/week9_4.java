import java.util.*;

class theatre extends Thread
{
String s;
theatre(String s)
{
super(s);
this.s=s;
}
public void getTicket()
{
System.out.println(this.getName() + "bought ticket");
showTicket();
}
public void showTicket()
{
System.out.println(this.getName() + "showed ticket");
}
public void run()
{
getTicket();
System.out.printlln("entered into theatre");
}
}
class week9_4
{
public static void main(String args[])
{
Thread[] t=new Thread[6];
for(int i=0;i<5;i++)
{
String p="person" +(i+1);
t[i]=new Thread(new theatre(p));
t[i].start();
}
}
}

