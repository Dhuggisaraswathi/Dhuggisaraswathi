import java.util.*;
import java.io.*;
class Aaa
{
public static void main(String[] arg)
{
final int a=10;
a=a+10;
System.out.println(a);
}
}

