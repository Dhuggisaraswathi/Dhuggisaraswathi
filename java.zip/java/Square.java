import java.util.*;
import java.io.*;
class Squar
{
int side;
void getarea(int s)
{
side=s;
int A;
A=s*s;
System.out.println(A);
}
void getperimeter(int a)
{
int B;
B=4*a;
System.out.println(B);
}
public static void main(String[] arg)
{
Squar S= new Squar();
Scanner N=new Scanner (System.in);
System.out.println("enter the side");
int a=N.nextInt();
//int b=N.nextInt();
S.getarea(a);
S.getperimeter(a);
}
}
