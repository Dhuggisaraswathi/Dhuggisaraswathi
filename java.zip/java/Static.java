import java.util.*;
import java.io.*;
class Static
{
static int s=0;
Static()
{
s++;
System.out.println(s);
}
public static void main(String arg[])
{
Static a=new Static();
Static b=new Static();
Static c=new Static();
}
}
