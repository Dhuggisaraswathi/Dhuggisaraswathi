import java.applet.Applet;
import java.awt.event.*;
import java.util.*;
import java.io.*;
import java.awt.*;
import javax.swing.*;

class Object 
{
public static void main(String[] args)
{
JFrame f=new JFrame("JFrame");
JLabel l=new JLabel("Hello world");
//f.setBackGround(Color.Black);

l.setBounds(200,120,200,220);
f.add(l);
f.setSize(300,300);
f.setLayout(null);
f.setVisible(true);
f.addWindowListener(new WindowAdapter()
{
public void windowClosing(WindowEvent e)
{
System.exit(0);
}
});
}
}

