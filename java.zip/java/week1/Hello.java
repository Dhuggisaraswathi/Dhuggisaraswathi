import java.util.*;
class Hello
{
public static void main(String[] arg)
{
System.out.println("Hello World");
}
}


