import java.util.*;
class Binary
{
public static void main(String ar[] )
{
int i,j,k=0,n,temp,f=0;
Scanner  s=new Scanner(System.in);
System.out.println("enter the size");
n=s.nextInt();
int a[]=new int[n];
System.out.println("enter the elements");
for(i=0;i<a.length;i++)
{
a[i]=s.nextInt();
}
for(i=0;i<a.length;i++)
{
for(j=i+1;j<a.length;j++)
{
if(a[i]>a[j])
{
temp=a[i];
a[i]=a[j];
a[j]=temp;
}
}
}
System.out.println("after sorting");
for(i=0;i<a.length;i++)
{
System.out.println(a[i]);
}
System.out.println("enter the key");
k=s.nextInt();
int low=0,high=n-1,mid=0;
while(low<=high)
{
mid=(low+high)/2;

if(k==a[mid])
{System.out.println("element "+k+"found at"+mid);
f=1;
break;
}
if(k>a[mid])
{
low=mid+1;
}
else
{
high=mid-1;
}
}
if(f==0)
{
System.out.println("element not found");
}
}
}
