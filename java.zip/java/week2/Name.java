import java.util.*;
class Name
{
public static void main(String...arg)
{
int n,i,j;
Scanner s=new Scanner (System.in);
System.out.println("enter the size");
n=s.nextInt();
s.nextLine();
String a[]=new String[n];
System.out.println("enter the names");
for(i=0;i<a.length;i++)
{
a[i]=s.nextLine();
}
for(i=0;i<a.length;i++)
{
for(j=i+1;j<a.length;j++)
{
if(a[i].compareTo(a[j])>0)
{
String t=a[i];
a[i]=a[j];
a[j]=t;
}
}
}
System.out.println("after sorting");
for(i=0;i<n;i++)
{
System.out.print(" "+a[i]);
}
}
}
