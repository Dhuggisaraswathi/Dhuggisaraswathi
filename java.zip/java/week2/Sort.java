import java.util.*;
class Sort
{
public static void main(String...arg)
{
int i,j,n,t;
Scanner s=new Scanner(System.in);
System.out.println("enter the size");
n=s.nextInt();
int a[]=new int[n];
System.out.println("enter the elements");
for(i=0;i<a.length;i++)
{
a[i]=s.nextInt();
}
for(i=0;i<a.length;i++)
{
for(j=i+1;j<a.length;j++)
{
if(a[i]>a[j])
{
t=a[i];
a[i]=a[j];
a[j]=t;
}
}
}
System.out.println("after sorting");
for(i=0;i<a.length;i++)
{
System.out.print(" "+a[i]);
}
}
}
