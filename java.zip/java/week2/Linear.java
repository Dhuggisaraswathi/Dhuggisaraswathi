import java.util.*;
class Linear
{
public static void main(String...arg)
{
int i,n,k,f=0;
Scanner s=new Scanner (System.in);

System.out.println("enter the size");
n=s.nextInt();
System.out.println("enter the elements");
int a[]=new  int[n];
for(i=0;i<n;i++)
{
a[i]=s.nextInt();
}
System.out.println("enter the search key");
k=s.nextInt();
for(i=0;i<a.length;i++)
{

if(k==a[i])
{
f=1;
break;
}
}
if(f==1)
{
System.out.println("element found"+i);
}
else
{
System.out.println("Not found " );
}
}
}

