import java.util.*;
import java.io.*;
class Namesort
{
public static void main(String...arg)
{
int i,j;
char n,m;
Scanner s=new Scanner (System.in);
System.out.println("enter size");
n=s.next();
//m=s.nextInt();
int a[]=new int[n];
for(i=0;i<a.length;i++)
{
a[i][j]=s.nextInt();
}
for(i=0;i<a.length;i++)
{
for(j=i+1;j<a.length;j++)
{
if(a[i],a[j]>0)
{
strcpy(t,a[i]);
strcpy(a[i],a[j]);
strcpy(a[j],t);
}
}
}
for(i=0;i<a.length;i++)
{
Syatem.out.println(a[i]);
}
}
}
