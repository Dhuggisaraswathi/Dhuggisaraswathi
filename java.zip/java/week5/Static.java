import java.util.*;
class Static 
{
static 
{
System.out.println("Block");
}
static void display()
{
System.out.println("method");
}
static  int a=10;
public static void main(String[] arg)
{
System.out.println(Static.a);
Static.display();
}
}
