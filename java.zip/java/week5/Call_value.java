import java.util.*;
class Call_value
{
Scanner R=new Scanner(System.in);
int age=10;
//System.out.println("enter age");
//ge=R.nextInt();
void change_Age(int age)
{
age=age+10;
System.out.println("Age in local"+age);
}
public static void main(String[] arg)
{
Call_value S=new Call_value();
System.out.println("age before change:"+S.age);
S.change_Age(10);
System.out.println("age after change"+S.age);
}
}

