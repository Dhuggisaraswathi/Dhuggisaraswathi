import java.util.*;
class Call_object
{
//int age;
Scanner R=new Scanner(System.in);
int age=10;
//System.out.println("enter age");
//age=R.nextInt();

void change_age(Call_object S)
{
age=age+10;
System.out.println("Age in local"+age);
}
public static void main(String[] arg)
{
Call_object O=new Call_object();
System.out.println("age before change"+O.age);
O.change_age(O);
System.out.println("age after change:"+O.age);
}
}
