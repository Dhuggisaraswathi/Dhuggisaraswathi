import java.util.*;
class W
{
public static void main(String[] arg)
{
Scanner s=new Scanner(System.in);
System.out.println("enter any value");
int a=s.nextInt();
Integer c=new Integer(a);
System.out.println("enter value");
int b=s.nextInt();
int d=new Integer(b);
System.out.println("ADD"+(c+d));
System.out.println("Sub"+(c-d));
System.out.println("mul"+(c*d));
System.out.println("enter any string");
String s1=s.nextLine();
int e=Interger.parseInt(s1);
System.out.println(e*2);

}
}
