import java.util.*;
class Circle
{
double  radius;
void getArea(double r)
{
radius=r;
double a;
a=(3.14)*r*r;
System.out.println(a);
}
void getPerimeter(double r)
{
double s=r;;
//radius=s;
double p;
p=2*(3.14)*s;
System.out.println(p);

}

public static void main(String...arg)
{
Circle A=new Circle();
Scanner S=new Scanner(System.in);
System.out.println("enter the radius");
double R=S.nextFloat();
A.getArea(R);
A.getPerimeter(R);
}
}
