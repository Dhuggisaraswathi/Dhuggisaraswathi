import java.util.*;
class T
{
int maxspeed=120;
}
class c extends T
{
int maxspeed=180;
void display()
{
System.out.println("max speed"+super.maxspeed);
}
}
class Test
{
public static void main(String[] arg)
{
c D=new c();
D.display();
}
}
