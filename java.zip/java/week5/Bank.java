import java.util.*;
class Account
{
String Acname;
int Accno;
double Wd,Am,de;
Account(String Acname,int Acno,double Wd,double de,double Am)
{
Acname=Acname;
Acno=Acno;
Wd=Wd;
de=de;
Am=Am;
}
public void debit(double w)
{
if(Am>w)
{
Am=(Am-w);
System.out.println("total ammount after withdrawl"+Wd+"is"+Am);

}
else
{
System.out.println("insufficient balance");
System.out.println("enter ammount"+Am);
}
}
public void credit(double d)
{
Am=(Am+d);
System.out.println("Account name"+Acname);
System.out.println("Account number"+Accno);

}
public void getBalance()
{
System.out.println("Total ammount"+de+"is"+Am);
double M=(Am-Wd)+de;
System.out.println("current balance"+M);
}
}
class Bank
{
public static void main(String[] arg)
{
Scanner s=new Scanner(System.in);
System.out.println("enter name");
String name=s.nextLine();
System.out.println("enter account number");
int number=s.nextInt();
System.out.println("enter Ammount");
double A=s.nextDouble();
System.out.println("enter withdrawl ammount");
double W=s.nextDouble();
System.out.println("enter deposit ammount");
double D=s.nextDouble();
System.out.println("ACCOUNT DETAILS");
Account S=new Account(name,number,A,W,D);

S.credit(D);
S.debit(W);
S.getBalance();
}
}

