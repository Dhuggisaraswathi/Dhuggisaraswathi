import java.util.*;
import java.io.*;
class Sum
{
public static void main(String arg[])
{
int a,b,c;
Scanner n=new Scanner(System.in);
System.out.println("enter a,b values");
a=n.nextInt();
b=n.nextInt();
c=a+b;
System.out.println(c);
}
}
