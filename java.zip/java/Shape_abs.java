import java.util.*;
import java.io.*;
abstract class Shape_abs
{
double r;
int s,l;
abstract double getArea();
//abstract double getAreaSquare();
//abstract double getAreaCube();
abstract double getVolume();
}
class Circle extends Shape_abs
{
double r;
  Circle(double r)
{
this.r=r;
}
double getArea()
{
return 3.14*r*r;
}
double getVolume()
{
return 0;
}}
class Square extends Shape_abs
{
int s;
public Square(int s)
{
this.s=s;
}
double getArea()
{
return s*s;
}
double getVolume()
{
return 0;
}
}
 class Cube extends Shape_abs
{
int  l;
public Cube(int l)
{
this.l=l;
}
//this.b=b;
//his.w=w;
double getArea()
{
return 4*l;
}
double getVolume()
{
return l*l*l;
}
}
class Test
{
public static void main(String arg[])
{
double r;
int s,l;
Shape_abs S=new  Shape_abs();
Scanner R=new Scanner(System.in);
System.out.println("enter radius");
r=R.nextDouble();
System.out.println(S.getArea());
System.out.println(S.getVolume());
//Shape_abs A=new Square();
System.out.println("enter side");
s=R.nextInt();
System.out.println(S.getArea());
System.out.println(S.getVolume());
//Shape_abs D=new Cube();
System.out.println("enter length");
l=R.nextInt();
System.out.println(S.getArea());
System.out.println(S.getVolume());
}
}


