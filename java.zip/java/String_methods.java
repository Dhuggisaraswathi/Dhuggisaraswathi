import java.util.*;
import java.io.*;
class String_methods
{
public static void main(String...arg)
{
Scanner S=new Scanner (System.in);
String a,b;
System.out.println("enter two strings");
a=S.nextLine();
b=S.nextLine();

if(a.compareTo(b)>0)
{
System.out.println("+ve");
}
else if(a.compareTo(b)<0)
{
System.out.println("-ve");
}
else
{
System.out.println("0");
}
}
}


