import java.util.*;
class Account
{
String accountnumber;
String accountaddress;
String coustomername;
int balance;
void getbalance(int a)
{
balance=a;
 System.out.println(" current balance:"+balance);
 }
void insertval(String acn,String aca, String cna)
{
accountnumber=acn;
accountaddress=aca;
coustomername=cna;
//balance=b;
}
void withdrawl(int am )
{
 if(balance>=am)
 {
 balance=balance-am;
 System.out.println("balance after withdrawl:"+balance);
 }
 else
 {
 System.out.println("insufficient to withdrawl"+balance);
 }
 }
 void deposit(int am)
 {
 balance=balance+am;
 System.out.println("balance after deposit:"+balance);
 }
 
 void getdetails(String number,String type,String name)
 {
  System.out.println("accountnumber= "+accountnumber);
 System.out.println("accountaddress= "+accountaddress);
 System.out.println("coustername= "+coustomername);
  //System.out.println("intial balance= "+balance);
}
 public static void main(String arg[])
 {
 Account s=new Account();
 int b,a,e;
 String name,aca,number;
 Scanner sc=new Scanner(System.in);
 System.out.print("enter the details number,adress,mame:");
 number=sc.nextLine();
 aca=sc.nextLine();
 name=sc.nextLine();
 System.out.println("enter the intial balance:");
 s.balance=sc.nextInt();
 if(s.balance==0)
 {
 System.out.println("invalid initial balance");
 }
 else if(s.balance!=0)
 {
 s.insertval(number,aca,name);
 }
 s.getdetails(number,aca,name);
  System.out.println("enter the withdrawl ammount :");
 b=sc.nextInt();
 s.withdrawl(b);
  System.out.println("enter the deposit ammount :");
e=sc.nextInt();
 s.deposit(e);
 s.getbalance(s.balance);
 }
 }
