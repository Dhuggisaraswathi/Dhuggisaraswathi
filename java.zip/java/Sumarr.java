import java.util.*;
import java.io.*;
class Sumarr
{
public static void main(String[] arg)
{
int i,j,r,c;
Scanner S=new Scanner(System.in);
System .out.print("enter row&col size");
r=S.nextInt();
c=S.nextInt();
int a[][]=new int[r][c];
int b[][]=new int[r][c];

System.out.println("enter the elements");
for(i=0;i<a.length;i++)
{
for(j=0;j<a.length;j++)
{
a[i][j]=S.nextInt();
}
}/*
for(i=0;i<a.length;i++)
{
for(j=0;j<a.length;j++)
{
System.out.print(a[i][j]+" ");
}
System.out.println();
}
}}*/
System.out.println("enter the elements");
for(i=0;i<b.length;i++)
{
for(j=0;j<b.length;j++)
{
b[i][j]=S.nextInt();
}
}
int  C[][]=new int[r][c];
for(i=0;i<C.length;i++)
{
for(j=0;j<C.length;j++)
{
C[i][j]=a[i][j]+b[i][j];
System.out.print(C[i][j]+" ");
}
System.out.println();
}
}
}
