import java.util.*;
import java.io.*;
interface Vehicle
{
String getColor();
String getNumber();
double getConsumption();
}
class TwoWheeler implements Vehicle
{
String color;
String number;
double Consumption;
public TwoWheeler(String color,String number,double Consumption)
{
this.color=color;
this.number=number;
this.Consumption=Consumption;
}
public String getColor()
{
return color;
}
public String getNumber()
{
return number;
}
public double getConsumption()
{
return Consumption;
}
}
class FourWheeler implements Vehicle
{
String color;
String number;
double Consumption;

public FourWheeler(String color,String number,double Consumption)
{
this.color=color;
this.number=number;
this.Consumption=Consumption;
}
public String getColor()
{
return color;
}
public String getNumber()
{
return number;
}
public double getConsumption()
{
return Consumption;
}
}
class Ve
{
public static void  main(String[] arg)
{
Scanner S=new Scanner(System.in);
System.out.println("TWO WHEELER");
System.out.println("Enter color");
String C=S.nextLine();
System.out.println("Enter registration number");
String R=S.nextLine();
System.out.println("Enter feul consumption");
double f=S.nextDouble();
TwoWheeler T=new TwoWheeler(C,R,f);
System.out.println("FOUR WHEELER");
System.out.println("Enter color");
String c=S.next();
System.out.println("Enter Registration number");
String r=S.next();
System.out.println("Enter feul consumption");
double F=S.nextDouble();
FourWheeler FW=new FourWheeler(c,r,F);

System.out.println("\n Two wheeler details:");
System.out.println(T.getColor());
System.out.println(T.getNumber());
System.out.println(T.getConsumption());
System.out.println("\n Four Wheeler details:");
System.out.println(FW.getColor());
System.out.println(FW.getNumber());
System.out.println(FW.getConsumption());
}
}
