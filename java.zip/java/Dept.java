package Pack;
import dept.*;
class Dept
{
public static void main(String[] arg)
{
Cse a=new Cse();
Ece b=new Ece();
Me c=new Me();
Ce d=new Ce();
a.display();
  b.display();
  c.display();
  d.display();
 }
 }
