import java.io.*;
import java.util.*;
abstract class Shape
{
abstract double getArea();

abstract double getVolume();
}
abstract class TwoDimensionalShape extends Shape
{
double getVolume()
{
return 0;
}
}
abstract class ThreeDimensionalShape extends Shape
{
}
class Square extends TwoDimensionalShape
{

double side;
Square(double side)
{
this.side=side;
}
double getArea()
{
return side*side;
}
}
class Circle extends TwoDimensionalShape
{
double rad;
Circle(double rad)
{
this.rad=rad;
}
double getArea()
{
return 3.14*rad*rad;

}}
class Cube extends ThreeDimensionalShape
{
double side;
Cube(double side)
{
this.side=side;
}
double getArea()
{
return 6*side*side;
}
double getVolume()
{
return side*side*side;
}
}
class Sphere extends ThreeDimensionalShape
{
double rad;
Sphere(double rad)
{
this.rad=rad;
}
double getArea()
{
return 4*3.14*rad*rad;
}
double getVolume()
{
return( (4/3)*3.14*rad*rad*rad);
}
}
class T
{
public static void main(String[] arg)
{
double side;
double rad;

Scanner R=new Scanner(System.in);
System.out.println("enter the side");
side=R.nextDouble();
Square s=new Square(side);
System.out.println("square area"+s.getArea());
Cube C=new Cube(side);
System.out.println("Cube area"+C.getArea());
System.out.println("cube volume"+C.getVolume());
System.out.println("enter rad");
rad=R.nextDouble();

Circle c=new Circle(rad);

System.out.println("circle area"+c.getArea());
//Cube C=new Cube(side);
//System.out.println("Cube area"+C.getArea());
//System.out.println("cube volume"+C.getVolume());
Sphere S=new Sphere(rad);
System.out.println("sphere area"+s.getArea());
System.out.println("sphere area"+s.getVolume());
}
}


