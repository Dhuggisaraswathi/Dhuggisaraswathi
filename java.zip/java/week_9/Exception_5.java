import java.util.*;
wee class week95
{
	public static void main(String[] args)
	{
		System.out.println("hello");
		try
		{
			String s="hello";
			int i=Integer.parseInt(s);
		}
		catch(NumberFormatException e)
		{
			System.out.println(e);
		}
		System.out.println("hai");
	}
}
