import java.io.*;
class Super
{
	int a,b;
	void set1(int a,int b)
	{
	   this.a=a;
	   this.b=b;
	}
	int getval1()
	{
	 return (a/b);
	}
}
class Sub extends Super
{
	int a,b,c;
	void set(int a,int b,int c)
	{
	   this.a=a;
	   this.b=b;
	   this.c=c;
	}
	int getval()
	{
	   return ((a/b)*c);
	}
}
class Exception1
{
	public static void main(String[] args)
	{
	 try
	 {
	  /* Super s=new Super();
	   s.set(12,0);
	   System.out.println("the result is"+s.getval());*/
	   
	   
	   Sub s1=new Sub();
	   s1.set(12,2,2);
	   System.out.println(s1.getval());
	   s1.set1(12,0);
	   System.out.println(s1.getval1());
	   
	   
	 }
	catch(Exception e)
	 {
	     System.out.println("handled");
	 }
	 catch(ArithmeticException e)
	 {
	    System.out.println(e);
	 }
	 catch(NullPointerException e)
	 {
	     System.out.println(e);
	 }
	
}
}
	   
	   
	
