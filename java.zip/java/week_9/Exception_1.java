
import java.util.*;
class UserException extends Exception
{
	public UserException(String message)
	{
		super(message);
	}
}
class Exception1
{
	public static void main(String[] args)
	{
		try
		{
			throwException();
		}
		catch(UserException e)
		{
			System.out.println("caught an exception:"+e.getMessage());
		}
		finally
		{
			System.out.println("Finally block executed");
		}
	}
	public static void throwException()
	throws UserException
	{
		throw new UserException("custom exception thrown!");
	}
}
