import java.io.*;
class Exception2
{
	public static void main(String args[])
	{
		int a;
		try
		{
			a=Integer.parseInt(args[0]);
			Exception2 obj=new Exception2();
			int cat=obj.one();
			
			if(a>50)
			{
				throw ( new ArithmeticException("num is greater"));
			}
			else
			{
			System.out.println("less than 50");}
		}
		catch(ArithmeticException e)
		{
			System.out.println("error found"+e.getMessage());
		}
		finally
		{
			System.out.println("done----");
		}
	}
	int one() throws ArithmeticException
	{
		Exception2 obj1=new Exception2();
		int a=12,b=0;
		int c=obj1.two(a,b);
		return c;
	}
	int two(int a,int b)
	{
		int d=a/b;
		return d;
	}
}

