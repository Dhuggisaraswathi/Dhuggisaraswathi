import java.util.*;
class MyException extends Exception
{
	private String customMessage;
	public MyException(String message)
	{
		super("User Exception="+message);
	customMessage=message;
	}
	public void printCustomMessage()
	{
		System.out.println("Custom message="+customMessage);
	}
}
class Exception6a
{
	public static void main(String[] args)
	{
		try
		{
			throwCustomException();
		}
		catch(MyException e)
		{
			System.out.println(e.getMessage());
			e.printCustomMessage();
		}
	}
	public static void throwCustomException() throws MyException
	{
		throw new MyException("this is a custom Excepton msg");
	}
}
			
	
