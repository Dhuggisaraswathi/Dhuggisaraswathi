package A.B;
public class Sam
{
 public void display()
{
System.out.println("Hai friends");
}
}

