import java.util.*;
import java.io.*;
class Case extends Thread
{
public void run()
{
for(int i=0;i<3;i++)
{
try{

System.out.println("red light is glowing");
Thread.sleep(10000);
}
catch(Exception e)
{
System.out.println("Turned off");
}
try{

System.out.println("yellow light is glowing");
Thread.sleep(10000);
}
catch(Exception e)
{

System.out.println("turned off");
}
try{

System.out.println("green light is glowing");
sleep(10000);
}
catch(Exception e)
{
System.out.println("turned off");
}
}
}
}
class ThreadEx2
{
public static void main(String[] arg)
{
Case c=new Case();
c.run();
}
}

