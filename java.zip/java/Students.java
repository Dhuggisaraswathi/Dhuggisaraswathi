import java.util.*;
import java.io.*;
class  Students
{
Students()
{
System.out.println("hello");
}
}
class C extends Students
{
C();
{super();
System.out.println("hai");
}
}
class B
{
public static void main(String[] arg)

{

C.obj=new C();
obj.C();
}
}

