import java.util.*;
import java.io.*;
class Super
{
String s;

/*Scanner   S=new Scanner(System.in);
System.out.println("enter any string");
s=S.nextLine();*/
}
class C extends Super
{
String n;
/*Scanner   R=new Scanner(System.in);
System.out.println("enter any string");
n=R.nextLine();*/

void display()
{
System.out.println(n);
System.out.println(super.s);
}
}
class B
{
public static void main(String arg[])
{
C o=new C();
o.display();
}
}

