import java.util.*; 

class String__reverse{
      public static void main(String[] args){
             Scanner S=new Scanner(System.in);
             String s1 ;
             System.out.println("enter the string");
             s1=S.nextLine();
             char arr [] = s1.toCharArray(); 
             //int j = 0 ; 
             System.out.println(s1.length()); 
             for(int i = s1.length()-1; i >= 0  ; i--){
                    char rev= s1.charAt(i); 
                     
            
            System.out.print(rev);
                    }
                    }
                    }
                   
                      
             
            
