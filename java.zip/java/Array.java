55import java.util.*;
import java.io.*;
class Array
{
public static void main(String arr[])
{
int n,i,j,m;
Scanner N=new Scanner(System.in);
System.out.println("enter size");
n=N.nextInt();
m=N.nextInt();
int a[][]=new int[n][m];
//int b[]=new int[n];
System.out.println("enter numbers");
for(i=0;i<a.length;i++)
{
for(j=0;j<a.length;j++)
{
a[i][j]=N.nextInt();
}
}
for(i=0;i<a.length;i++)
{
for(j=0;j<a.length;j++)
{

System.out.print(  a[i] [j]);
}
System.out.println("\n");
}
}
}
