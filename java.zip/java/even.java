import java.util.*;
import java.io.*;
class Even
{
public static void main(String arr[])
{
int n;
Scanner sc=new Scanner(System.in);
System.out.println("enter n value");
n=sc.nextInt();

if(n%2==0)
{
System.out.println("even");
}
else
{
System.out.println("odd");
}
}
}
