import java.util.*;
import java.io.*;
interface SBI
{
double getAmount();
}
 class Sbi implements SBI
{
public double getAmout()
{
return 1000;
}
}
class Balance implements SBI
{
public double getAmount()
{
return 500;
}
}
class Test 
{
public static void main(String arg[])
{
SBI S=new Sbi();
System.out.println(S.getAmount());
SBI A=new Balance();
System.out.println(A.getAmount());
}
}
