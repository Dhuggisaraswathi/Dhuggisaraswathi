import java.util.*;
import java.io.*;
class  Theatre implements Runnable
{
public static void main(String[] arg)
{
 Synchronized void run()
{

int i,n;
System.out.println("enter how many  member to enter into the theatre");
Scanner s=new Scanner(System.in);
n=s.nextInt();
int a[]=new int();
//int a[]=new int[n];
for(i=1;i<n;i++)
int a[i]=s.nextInt();
//Scanner u=new Scanner(System.in);
//a[i]=u.nextInt();
public void buy()
{
try
{
Sytem.out.println(" person buyed ticket:"+i);
}
catch(Exception e)

public void show()
{
try{

System.out.println("person showed ticket"+i);
}
catch(Exception e)

public void enter()
{
try
{
System.out.println("person entered into theatre"+i);
}
catch(
}
}

}
}
}
class Te
{
public static void main(String[] arg)
{
Scanner s=new Scanner(System.in);
Train T=new Train();
System.out.println("enter size");
n=s.nextInt();
T.start();
}
}
