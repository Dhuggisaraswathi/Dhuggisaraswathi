import java.util.*;
import  java.io.*;
class Mult
{
public static void main(String ... arg)
{
int r1,r2, c1,c2;
int j,i,k;
Scanner  N=new Scanner(System.in);
System.out.println("enter row &col size");
r1=N.nextInt();
c1=N.nextInt();
System.out.println("enter the row and col size");
r2=N.nextInt();
c2=N.nextInt();
if(c1==r2)
{
System.out.println("enter the elements");
int a[][]=new int[r1][c1];
for(i=0;i<a.length;i++)
{
for(j=0;j<a.length;j++)
{
a[i][j]=N.nextInt();
}
}

System.out.println("enter the elements ");
int b[][]=new int[r2][c2];
for(i=0;i<b.length;i++)
{
for(j=0;j<b.length;j++)
{
b[i][j]=N.nextInt();
}
}
int c[][]=new int[r1][c2];
for(i=0;i<c.length;i++)
{
for(j=0;j<c.length;j++)
{
c[i][j]=N.nextInt();
c[i][j]=0;
for(k=0;k<c.length;k++)
{
c[i][j]+=a[i][k]*b[k][j];
}
}
}
for(i=0;i<c.length;i++)
{
for(j=0;j<c.length;j++)
{

System.out.print(c[i][j]);
}
System.out.println();
}
}
else
{
System.out.println("not possible");
}
}
}
