import java.util.*;
class Products
{
public static void main(String arg[])
{
Scanner s=new Scanner(System.in);
double p1,p2,p3,p4,p5;
int quantity;
double totalsales=0;
System.out.println("choose product 1 to 5");
System.out.println("product1:Rs.99.90\nproduct2:Rs.20.20\nproduct3:6.87\nproduct4:Rs.45.50\nproduct5:Rs.40.49");
int productno=s.nextInt();
System.out.println("enter quantity sold");
quantity=s.nextInt();
switch(productno)
{
case 1:p1=99.90;
totalsales+=(99.90*quantity);
break;
case 2:p2=20.20;
totalsales+=(20.20*quantity);
break;
case 3:p3=6.87;
totalsales+=(6.87*quantity);
break;
case 4:p4=45.50;
totalsales+=(45.50*quantity);
break;
case 5:p5=40.49;
totalsales+=(40.49*quantity);
break;
}
System.out.println("the total retail value of all products sold:\n"+totalsales);
}
}

