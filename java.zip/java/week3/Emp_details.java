import java.util.*;
class Emp_details
{
public static void main(String[] arg)
{
Scanner s=new Scanner(System.in);
System.out.println("enter no of employees");

int n=s.nextInt();
System.out.println("enter "+n+ " Employee Details");
int id[]=new int[n];
String name[]=new String[n];
String gender[]=new String[n];
String Add[]=new String[n];
int Age[]=new int[n];
int salary[]=new int[n];
String des[]=new String[n];
System.out.println("enter employee  Details\nID\nName\ngender\nAddress\nsalary\nage\ndesignation\n");
int i;
int a;
int sal;
int age;
int ID;
String n1,ad,g,de;
for(i=0;i<n;i++)
{
System.out.println("enter employee "+(i+1)+" details");
id[i]=s.nextInt();
name[i]=s.next();
Add[i]=s.next();
gender[i]=s.next();
salary[i]=s.nextInt();
Age[i]=s.nextInt();
des[i]=s.next();
}


System.out.println("enter your choice to get details");
char ch=s.next().charAt(0);
switch(ch)
{
case 1:System.out.println("enter id ");
ID=s.nextInt();
break;
//System.out.println("employee ");
case 2:System.out.println("enter name");
n1=s.next();
break;
case 3:System.out.println("enter address");

ad=s.next();
break;
case 4:System.out.println("enter gender");
 g=s.next();
break;
case 5:System.out.println("enter designation");
 de=s.next();
break;
case 6:System.out.println("enter salary");
 sal=s.nextInt();
break;
case 7:System.out.println("enter age");
a=s.nextInt();
break;
default:System.out.println("invalid");
}

for(i=0;i<n;i++)
{
if(ID==id[i]||n1==name[i]||ad==Add[i]||g==gender[i]||de==des[i]||sal==salary[i]||a==Age[i])
{
System.out.println("emp_name "+id[i]);

System.out.println("emp_id "+name[i]);
System.out.println("emp_address"+Add[i]);
System.out.println("emp_gender "+gender[i]);
System.out.println("emp_designation "+des[i]);
System.out.println("emp_salary "+salary[i]);
System.out.println("emp_age "+Age[i]);
}
}

}
}


