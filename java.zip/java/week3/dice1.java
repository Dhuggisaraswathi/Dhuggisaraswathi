import java.util.*; 
class A{
    public static void main(String[] args){
        Random random = new Random(); 
        int count = 0 ; 
        
       for(int i = 0 ; i <10 ; i++){
       try{
            Thread.sleep(1000); 
            }
        catch(InterruptedException e){
           System.out.println("error"); 
        }
        int dice1 = random.nextInt(6)+1;
         System.out.print(dice1+" " ); 
        int dice2 = random.nextInt(6)+1; 
        System.out.println(dice2); 
        if(dice1 == dice2){
             count++; 
            
         System.out.println("Succesful attempts are"+(count)); 
        }
      else
      {
       System.out.println("unSuccesful attempts are"+(count)); 
       }}
       }
       }
