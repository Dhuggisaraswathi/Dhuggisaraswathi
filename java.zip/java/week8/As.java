package Good;
import Ds.*;
class As implements Frnd
{
public void display()
{
System.out.println("Hello guyyyysss");
}
public static void main(String[] arg)
{
Frnd f=new As();
f.display();
}
}

