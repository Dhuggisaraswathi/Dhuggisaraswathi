package samatha;
public class Div
{
public int Div(int a,int b)
{
return a/b;
}
}
