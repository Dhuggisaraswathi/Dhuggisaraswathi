package samatha;
public class Mul1
{
public int Mul(int a,int b)
{
return a*b;
}
}
