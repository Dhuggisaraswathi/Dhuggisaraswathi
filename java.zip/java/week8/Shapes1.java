package Program;
import org.shapes.*;
import java.util.*;
class Shapes1
{
public static void main(String[] arg)
{
Scanner S=new Scanner (System.in);
int s,r,b,h;
System.out.println("enter side,radius,breadth,height");
s=S.nextInt();
r=S.nextInt();
b=S.nextInt();
h=S.nextInt();
Square1 a=new Square1();
Circle1 d=new Circle1();
Triangle c=new Triangle();
System.out.println("Square area :"+a.getArea(s));
System.out.println("Square perimeter:"+a.getPerimeter(s));
System.out.println("Circle area :"+d.getArea(r));
System.out.println("Circle perimeter:"+d.getPerimeter(r));
System.out.println("Triangle area :"+c.getArea(h,b));
System.out.println("Triangle perimeter:"+c.getPerimeter(h,b));
}
}



