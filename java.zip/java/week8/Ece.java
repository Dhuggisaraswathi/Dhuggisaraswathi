package  dept;
public class  Ece
{
public void display()
{
System.out.println("DEC,NETWORK,EDC");
}
}
