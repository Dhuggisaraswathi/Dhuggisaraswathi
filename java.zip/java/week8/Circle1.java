package org.shapes;

public class  Circle1
{
public double getArea(int r)
{ 
return  3.14*r*r;
}
public double getPerimeter(int r)
{
return 2*3.14*r;
}
}
