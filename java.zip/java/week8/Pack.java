package Name;
public class Pack
{
public void display()
{
System.out.println("hello world");
}
}

