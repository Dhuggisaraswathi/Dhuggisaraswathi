package  dept;
public class  Ce
{
public void display()
{
System.out.println("A,B,C");
}
}
