package Nani;
import Name.*;
class Hello1
{
public static void main(String arg[])
{
Pack a=new Pack();
Pack1 b=new Pack1();
a.display();
b.display();
}
}

