package  dept;
public class  Me
{
public void display()
{
System.out.println("dom,COI");
}
}
