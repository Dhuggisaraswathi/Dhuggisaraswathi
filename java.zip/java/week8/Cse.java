package  dept;
public class  Cse
{
public void display()
{
System.out.println("OOPS,PPS,DBMS,COA,DSA");
}
}

