package Name;
public class Pack1
{
public void display()
{
System.out.println("Welcome");
}
}
