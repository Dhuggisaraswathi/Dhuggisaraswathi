package samatha;
public class Sub1
{
public int Sub(int a,int b)
{
return a-b;
}
}
