package Calculator;
import  java.util.*;


import samatha.*;
class Calculator1
{
public static void main(String[] arg)
{
Scanner S=new Scanner(System.in);
int a,b;
char ch;
System.out.println("enter a,b  values");
a=S.nextInt();
b=S.nextInt();
System.out.println("enter your choice 1.Add\n2.Sub\n3.Mul\n4.Div\n");
ch=S.next().charAt(0);
Add1 e=new Add1();
Sub1 f=new Sub1();
Mul1 c= new Mul1();
Div d=new Div();

switch(ch)
{
case '1':System.out.println(" sum:"+e.Add(a,b));
break;
case '2':System.out.println(" sub"+f.Sub(a,b));
break;
case '3':System.out.println(" mul:"+c.Mul(a,b));
break;
case '4':System.out.println("Div"+d.Div(a,b));
break;
default:System.out.println("invalid");
break;
}
}
}
