package org.shapes;

public class  Triangle
{
public double getArea(int b,int h)
{ 
return  0.5*b*h;
}
public double getPerimeter(int b,int h)
{
return b*h;
}
}
