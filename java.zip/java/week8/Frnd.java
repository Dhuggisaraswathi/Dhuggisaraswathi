package Ds;
 public interface Frnd

{
public void display();
}


