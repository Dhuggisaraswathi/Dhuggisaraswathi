package Sam;
class A
{
void display()
{
System.out.println("hello");
}
public static void main(String arg[])
{
A obj=new A();
obj.display();
}
}
