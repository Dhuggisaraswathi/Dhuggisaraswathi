package S;
import A.B.*;
class Ds
{
public static void main(String[] arg)
{
Sam obj=new Sam();
obj.display();
}
}
