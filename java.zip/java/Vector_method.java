import java .util.*;
import java .io.*;
class Vector_methods
{
public static void main(String arg[])
{
int b;
Vector<Integer>a=newVector<Integer>;

a.add(5);
System.out.println("Element added:" +a);
a.add(0,8);
System.out.println("adding element at index 0"+a);
a.add(1,5);
System.out.println("adding element at index 1"+a);
a.remove(1);
System.out.println("after removing 7"+a);
b=a.get(1);
System.out.println("element index at 1 is "+b);
b=a.sixe();
System.out.println("size of a list"+b);
b=a.firstElement();
System.out.println("first element "+b);
b=a.lastElement();
System.out.println("last element" +b);
a.addElement(10);
System.out.println("element added " +a);
a.capacity();
System.out.println("capacity" +a);
Boolean c=a.contains(67);
System.out.println(c);
b=a.indexOf(8);
System.out.println("index of 8 is "+b);
c=a.isEmpty();
System.out.println(c);
a.removeElementAt(0);
System.out.println("after removing element at 0 index " +a);
a.toArray();
System.out.println(a);
a.clear();
System.out.println("after clear"+a);
a.setSize();
System.out.println("after set the size"+a);
a.add(0,8);
a.add(1,2);
System.out.println("after adding elements acc to new size"+a);
a.clear();
System.out.println("after clear"+a);
}
}

