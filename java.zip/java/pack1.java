package pack;
public class A
{
protected void display()
{
System.out.println("hello");
}
}
