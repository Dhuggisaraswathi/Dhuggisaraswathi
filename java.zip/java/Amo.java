import java.util.Scanner;
interface Payable
{ double getAmount();
}
class Invoice implements Payable
{
double Amount;

 public Invoice(double Amount)
{
this.Amount=Amount;
}
 public double getAmount()
{
return Amount;
}
}
class Employee implements Payable
{
double salary;
 public Employee(double salary)
{
this.salary=salary;
}
 public double getAmount()
{
return salary;
}
}
class Amo
{
public static void main(String arg[])
{
Scanner S=new Scanner(System.in);
System.out.println("enter invoice amount");
double InA=S.nextDouble();
Invoice I=new Invoice(InA);
System.out.println("Amount paid for invoice:"+I.getAmount());
System.out.println("enter the employee salary");
double EmS=S.nextDouble();
Employee E=new Employee(EmS);
System.out.println("amount paid for employee:"+E.getAmount());
S.close();
}
}
