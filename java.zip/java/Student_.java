import java.util.*;
imort java.io.*;
class  Students
{
Student()
{
System.out.println("hello");
}
}
class C extends Student
{
C();
{super();
System.out.println("hai");
}
}
class B
{
public static void main(String[] arg)

{

C.obj=new C();
obj.C();
}
}

