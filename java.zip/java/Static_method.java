import java.util.*;
import java.io.*;
class Static_method
{
static int x;
static int cube()
{
return x*x;
}
public static void main(String arg[])
{
Scanner S=new Scanner(System.in);
System.out.println("enter the value");
x=S.nextInt();
System.out.println(cube());
}
}
