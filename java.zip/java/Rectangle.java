import java.util.*;
import java.io.*;
class Rectangle
{
int length;
int breadth;
void getarea(int l,int b)
{
length=l;
breadth=b;
int A;
A=l*b;
System.out.println(A);
}
void getperimeter(int l,int b)
{
int B;
B=2*(l*b);
System.out.println(B);
}
public static void main(String[] arg)
{
Rectangle S= new Rectangle();
Scanner N=new Scanner (System.in);
System.out.println("enter the a and b value");
int a=N.nextInt();
int b=N.nextInt();
S.getarea(a,b);
S.getperimeter(a,b);
}
}

