/*3. Create a GUI application to display a calculator using grid Layout (You do not
have to provide functionality).*/
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class CalculatorApp extends JFrame implements ActionListener {
    // Create components
    private JTextField textField;
    private JButton[] numberButtons;
    private JButton[] operationButtons;
    private JButton addButton, subButton, mulButton, divButton, eqButton, dotButton, clrButton;
    private JPanel panel;

    // Variables for calculation
    private String operator;
    private double firstNumber, secondNumber, result;

    public CalculatorApp() {
        // Set up the frame
        setTitle("Calculator");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 400);
        setLayout(new BorderLayout());

        // Create components
        textField = new JTextField();
        textField.setHorizontalAlignment(JTextField.RIGHT);
        textField.setFont(new Font("Arial", Font.PLAIN, 50));

        // Initialize number buttons
        numberButtons = new JButton[10];
        for (int i = 0; i < 10; i++) {
            numberButtons[i] = new JButton(String.valueOf(i));
            numberButtons[i].setFont(new Font("Arial", Font.PLAIN, 100));
            numberButtons[i].addActionListener(this);
        }

        // Initialize operation buttons
        addButton = new JButton("+");
        subButton = new JButton("-");
        mulButton = new JButton("*");
        divButton = new JButton("/");
        eqButton = new JButton("=");
        dotButton = new JButton(".");
        clrButton = new JButton("C");

        operationButtons = new JButton[]{addButton, subButton, mulButton, divButton, eqButton, dotButton, clrButton};

        for (JButton button : operationButtons) {
            button.setFont(new Font("Arial", Font.PLAIN, 100));
            button.addActionListener(this);
        }

        // Set up the panel with grid layout
        panel = new JPanel();
        panel.setLayout(new GridLayout(4, 3, 5,4));

        // Add components to the panel
        panel.add(numberButtons[7]);
        panel.add(numberButtons[8]);
        panel.add(numberButtons[9]);
        panel.add(divButton);

        panel.add(numberButtons[4]);
        panel.add(numberButtons[5]);
        panel.add(numberButtons[6]);
        panel.add(mulButton);

        panel.add(numberButtons[1]);
        panel.add(numberButtons[2]);
        panel.add(numberButtons[3]);
        panel.add(subButton);

        panel.add(numberButtons[0]);
        panel.add(dotButton);
        panel.add(eqButton);
        panel.add(addButton);

        // Add components to the frame
        add(textField, BorderLayout.NORTH);
        add(panel, BorderLayout.CENTER);

        // Set visible
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        JButton source = (JButton) e.getSource();
        String buttonText = source.getText();

        // Handle number buttons
        for (int i = 0; i < 10; i++) {
            if (buttonText.equals(String.valueOf(i))) {
                textField.setText(textField.getText() + buttonText);
                return;
            }
        }

        // Handle operation buttons
        switch (buttonText) {
            case "+":
            case "-":
            case "*":
            case "/":
                operator = buttonText;
                firstNumber = Double.parseDouble(textField.getText());
                textField.setText("");
                break;
            case "=":
                secondNumber = Double.parseDouble(textField.getText());
                calculateResult();
                break;
            case ".":
                if (!textField.getText().contains(".")) {
                    textField.setText(textField.getText() + buttonText);
                }
                break;
            case "C":
                textField.setText("");
                break;
        }
    }

    private void calculateResult() {
        switch (operator) {
            case "+":
                result = firstNumber + secondNumber;
                break;
            case "-":
                result = firstNumber - secondNumber;
                break;
            case "*":
                result = firstNumber * secondNumber;
                break;
            case "/":
                if (secondNumber != 0) {
                    result = firstNumber / secondNumber;
                } else {
                    textField.setText("Error");
                    return;
                }
                break;
        }
        textField.setText(String.valueOf(result));
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new CalculatorApp());
    }
}

