import java.util.*;
class Vehicle
{
int vno,ino;
String color,;
double fuel;
void setInfo(int vno,int ino,String color)
{
this.vno=vno;
this.ino=ino;
this.color=color;
}
void getConsumption(double fuel)
{
this.fuel=fuel;
}
void displayConsumption()
{
System.out.println("fuel consumption"+fuel);
}
void displayInfo()
{
System.out.println("vehicle"+vno);
System.out.println("insurance"+ino);
System.out.println("color"+color);
}
}
class Tw extends Vehicle
{
double avg;
double mt;
void setspecs(double avg,double mt)
{
this.avg=avg;
this.mt=mt;
}
double getMaintainance()
{
return mt;
}
double getAverage()
{
return avg;
}
}
class geared extends Tw

{
String typr,name;
geared(String type,String name)
{
this.type=type;
this.name=name;
}
String gettype()
{
return type;
}
String getname()
{
return name;
}
}
class Nongeared extends Tw
{
String type,name;
Nongeared(String type,String name)
{
this.type=type;
this.name=name;
}
String gettype()
{
return type;
}
String getname()
{
return name;
}
}
class Main
{
public static void main(String[] arg)
{
Scanner S=new Scanner(System.in);
//Tw t=new Tw();
//geared g=new gear



