import java.util.*;
import java.io.*;
class ContractEmployee
{
    void getDesig()
    {
       System.out.println("Hourly Employee");
    }
    void getDesign()
    {
       System.out.println("Weekly Employee");
    }
    
}
class HourlyEmployee extends ContractEmployee
{
	void cal_wages(int hours,int wagesph)
	{
	  System.out.println("monthly salary="+hours*wagesph*30);
	}
	void getDesig()
	{
	System.out.println("Designation=Hourly Employee");
           }
}
class WeeklyEmployee extends ContractEmployee
{
	void cal_wages(int now,int wagespw)
	{
	   System.out.println("monthly salary="+now*wagespw*30);
	}
	void getDesign()
	{
	System.out.println("Designation=Weekly Employee");
           }
           
}
class emp_hw
{
	public static void main(String[] args)
	{
	  int h,wph,nw,wpw;
	  System.out.println("HOURLY EMPLOYEE");
	  HourlyEmployee b=new HourlyEmployee();
	  Scanner user=new Scanner(System.in);
	  System.out.println("enter no of hours");
	  h=user.nextInt();
	  System.out.println("enter no of wages per hour");
	  wph=user.nextInt();
	  b.cal_wages(h,wph);
	  b.getDesig();
	   
	  System.out.println("***************************");
	  System.out.println("WEEKLY EMPLOYEE"); 
	  WeeklyEmployee w=new WeeklyEmployee();
	  System.out.println("enter no of weeks");
	  nw=user.nextInt();
	  System.out.println("enter no of wages per week");
	  wpw=user.nextInt();
	  w.cal_wages(nw,wpw);
	  w.getDesign();
	}
}
	  
	  
	  
           
	
	  
	
	
	
