import java.io.*;
import java.util.*;
class Ar
{
static int sum(int a,int b)
{
return a+b;
}
static float sum(float a,float b)
{
return a+b;
}
}class S
{
public static void main(String srg[])
{
Scanner S=new Scanner(System.in);
System.out.println("enter a ,b values");
int a=S.nextInt();
int b=S.nextInt();
System.out.println(Ar.sum(a,b));
System.out.println("enter a,b values");
float c=S.nextFloat();
float d=S.nextFloat();
System.out.println(Ar.sum(c,d));
}
}
