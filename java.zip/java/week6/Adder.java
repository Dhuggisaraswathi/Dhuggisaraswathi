import java.util.*;
import java.io.*;
class Adder
{
static int sum(int a, int b)
{
return a+b;
}
static  int sum(int a,int b,int c)
{
return a+b+c;
}
}
class Sum
{
public static void main(String[] arg)
{
Scanner S=new Scanner(System.in);
int a,b,c;
System.out.println("enter a,b, c values");
a=S.nextInt();
b=S.nextInt();
c=S.nextInt();
System.out.println(Adder.sum(a,b));
System.out.println(Adder.sum(a,b,c));
}
}

