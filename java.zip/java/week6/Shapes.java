import java.util.*;
import java.io.*;
class Shapes
{
//int rad ;
//int length;
//int breadth;
//int a;
 static double getCircleArea(double rad)
{
return (3.14)*rad*rad;
}
static int getSquareArea(int a)
 {
 return a*a;
 }
 static int getRectangleArea(int length,int breadth)
 {
 return length*breadth;
 }
}
class Test
{
public static void main(String[] arg)
{
double r;
 int l,a,b;
Scanner S=new Scanner(System.in);
System.out.println("enter the radius");
r=S.nextDouble();
System.out.println(Shapes.getCircleArea(r));
System.out.println("enter the length and breadth");
l=S.nextInt();
b=S.nextInt();
System.out.println(Shapes.getRectangleArea(l,b));
System.out.println("enter the side");
a=S.nextInt();

//System.out.println(Shapes.getCircleArea(r));
System.out.println(Shapes.getSquareArea(a));
//System.out.println(Shapes.getRectangleArea(l,b));
}
}
