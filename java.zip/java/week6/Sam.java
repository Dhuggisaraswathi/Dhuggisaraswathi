import java.util.*;
class Sam
{
void display()
{
System.out.println("hello ");
}
}
class B extends Sam
{
void display()
{
System.out.println("sam");
}
public static void main(String[] arg)
{
B o=new B();
o.display();
}
}
