import java.util.*;
import java.io.*;
class Twowheeler
{
           String v_type,name;
           int type;
         //  Scanner user=new Scanner(System.in);
           //System.out.println("enter the consumption");
           //type=user.nextInt();
	void maintenance(int type)
	{
	   if(type>60)
	   {
	    System.out.println("good condition");
	   }
	   else
	   {
	   System.out.println("bad condition");
	   }
	   
	 }
	void average( int c,int l)
	{
	   System.out.println("average of two wheeler:"+c/l);
	}
	public String getType()
	{
	   return v_type;
	}
	public void setType(String TYPE)
	{
	   this.v_type=TYPE;
	}
	public String getName()
	{
	    return name;
	}
	public void setName(String Name)
	{
	     this.name=Name;
	}
}
class Geared extends Twowheeler
{ 
         void avg(int g,int n)
         {
           System.out.println("avg of geared twowheeler="+g/n);
         }
}
class Nongeared extends Twowheeler
{ 
         void avg(int g,int n)
         {
           System.out.println("avg of non-geared twowheeler="+g/n);
         }
}     
class Test3
{
	public static void main(String[] args)
	{
	  int c,li,b,d,e;
	  String a,n;
	  System.out.println("GEARED TWO WHEELER");
	  Geared t=new Geared();
	  Scanner user=new Scanner(System.in);
	  System.out.println("enter the consumption");
	  e=user.nextInt();
	  System.out.println("enter the km");
	  c=user.nextInt();
	  System.out.println("enter no of litres");
	  li=user.nextInt();
	  System.out.println("enter the type");
	  a=user.next();
	  System.out.println("enter the company name");
	  n=user.next();
	  System.out.println("enter the  geared vehicles");
	  b=user.nextInt();
	  System.out.println("enter the no of geared vehicles");
	  d=user.nextInt();
	  t.maintenance(e);
	  t.average(c,li);
	  t.setType(a);
	  t.setName(n);
	  System.out.println("type of vehicle="+t.getType());
	  System.out.println("company name="+t.getName());
	  t.avg(b,d);
	  
	  System.out.println("************************");
	  
	  System.out.println("NON-GEARED TWO WHEELER");
	  Nongeared f=new Nongeared();
	  System.out.println("enter the consumption");
	  e=user.nextInt();
	  System.out.println("enter the km");
	  c=user.nextInt();
	  System.out.println("enter no of litres");
	  li=user.nextInt();
	  System.out.println("enter the type");
	  a=user.next();
	  System.out.println("enter the company name");
	  n=user.next();
	  System.out.println("enter the  non-geared vehicles");
	  b=user.nextInt();
	  System.out.println("enter the no of non-geared vehicles");
	  d=user.nextInt();
	  f.maintenance(e);
	  f.average(c,li);
	  f.setType(a);
	  f.setName(n);
	  System.out.println("type of vehicle="+f.getType());
	  System.out.println("company name="+f.getName());
	  f.avg(b,d);
	  
	 }
}
	 
	 

	
	   
