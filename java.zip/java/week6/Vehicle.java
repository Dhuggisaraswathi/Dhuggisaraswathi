import java.util.*;
import java.io.*;
class Vehicle
{
	int v_no,i_no;
	String color;
	int type;
	public int getConsumption()
	{
	   return type;
	}
	public void setConsumption(int t)
	{
	   this.type=t;
	}
	void displayConsumption()
	{
	  System.out.println("vehicle consumption:"+type);
	}
}
class Twowheeler extends Vehicle
{
	void maintenance()
	{
	   if(type>60)
	   {
	    System.out.println("good condition");
	   }
	   else
	   {
	   System.out.println("bad condition");
	   }
	   
	 }
	void average( int c,int l)
	{
	   System.out.println("average of two:"+c/l);
	}
}
class Fourwheeler extends Vehicle
{
           void maintenance()
	{
	   if(type>60)
	   {
	    System.out.println("good condition");
	   }
	   else
	   {
	   System.out.println("bad condition");
	   }
	 }
	void average(int c,int l)
	{
	System.out.println("average of four:"+c/l);
	}
}
class Test2
{
	public static void main(String[] args)
	{
	  int c,li;
	  System.out.println("TWO WHEELER");
	  Twowheeler t=new Twowheeler();
	  Scanner user=new Scanner(System.in);
	  System.out.println("enter the km");
	  c=user.nextInt();
	  System.out.println("enter no of litres");
	  li=user.nextInt();
	  t.setConsumption(c);
	  t.displayConsumption();
	  t.maintenance();
	  t.average(c,li);
	  System.out.println("************************");
	  System.out.println("FOUR WHEELER");
	  Fourwheeler f=new Fourwheeler();
	  System.out.println("enter the km");
	  c=user.nextInt();
	  System.out.println("enter no of litres");
	  li=user.nextInt();
	  f.setConsumption(c);
	  f.displayConsumption();
	  f.maintenance();
	  f.average(c,li);
	 }
}
	 
	 

	
	   
