import java.applet.Applet;
import java.awt.event.*;
import java.awt.*; 
import javax.swing.*;
import java.awt.Color;
 class Students extends Applet
 {
public static Label l,l1,l2,l3,l4,l5,l6,l7,l8;
public static TextField t1,t2,t3,t4,t5;
public static JComboBox cb;
public static void main(String[] args) 
{
 JFrame f=new JFrame("Student");
 f.setBackground(Color.BLACK);
l1=new Label("Roll no");
l1.setBounds(100,80,50,20);
l2=new Label("ID no");
l2.setBounds(100,110,50,20);
l3=new Label("Name");
l3.setBounds(100,140,50,20);
l4=new Label("Class");
l4.setBounds(100,170,50,20);
l5=new Label("Gender");
l5.setBounds(100,200,50,20);
l6=new Label("Course");
l6.setBounds(100,230,50,20);
l7=new Label("Address");
l7.setBounds(100,260,70,20);
l8=new Label("college");
l8.setBounds(100,290,50,20);
String course[]={"select" ,"DSA","DAA","OOPS","C","COA",};
cb=new JComboBox(course);
cb.setBounds(280,230,90,20);
t1=new TextField();
t1.setBounds(280,80,120,20);
t2=new TextField();
t2.setBounds(280,110,120,20);
t3=new TextField();
t3.setBounds(280,140,120,20); 
t4=new TextField();
t4.setBounds(280,260,120,20);
t5=new TextField();
t5.setBounds(280,290,120,20);
CheckboxGroup cbg=new CheckboxGroup(); 
Checkbox box1=new Checkbox("026",false,cbg); 
Checkbox box2=new Checkbox("023",false,cbg); 
Checkbox box3=new Checkbox("024",false,cbg); 
box1.setBounds(280,170,40,20);
box2.setBounds(400,170,40,20);
box3.setBounds(480,170,40,20); 
CheckboxGroup cbg1=new CheckboxGroup(); 
Checkbox box4=new Checkbox("Male",false,cbg1); 
Checkbox box5=new Checkbox("Female",false,cbg1);
box4.setBounds(280,200,60,20);
box5.setBounds(400,200,60,20); 
JButton b=new JButton("Submit");
b.setBackground(Color.BLUE);
b.setBounds(460,320,100,20);
l=new Label("Submitted!");
l.setBounds(320,350,170,20);
l.setVisible(false);
b.addActionListener(new ActionListener()
{
public void actionPerformed(ActionEvent e)
{
l.setVisible(true);
}
});
f.add(l1);
f.add(l2);
f.add(l3);
f.add(l4);
f.add(l5);
f.add(l7);
f.add(t1);
f.add(t2);
f.add(box1);
f.add(box2);
f.add(box3);
f.add(box4);
f.add(box5);
f.add(l6);
f.add(l8);
f.add(cb);
f.add(t3);
f.add(t4);
f.add(t5);
f.add(b);
f.add(l);
f.setSize(800,800);
f.setLayout(null);
f.setVisible(true);
f.addWindowListener(new WindowAdapter() 
{ 
public void windowClosing(WindowEvent e)
 {
System.exit(0);}
});
}
}
