import java.util.*;
import java.io.*;
class Employee
{
//String F_name;
//String L_name;
static String getFirstName(String F_name)
{
return F_name;
}
static String getLastName(String L_name)
{
return L_name;
}
}
class Contract extends Employee
{
static String getDept(String D)
{
return D;
}
static String getDesig_(String d)
{
retrun d;
}
static double getSalary(double S)
{
retrun S;
}
}
class Regular extends Employee
{
static String getDept(String W)
{
return W;
}
static String getDesig(String R)
{
return R;
}
static double getSal(double T)
{
retrun T;
}
void display()
{
System.out.println(Employee.getFirstName(F_name)+Employee.getLastName( L_name));
}
}
class Test
{
public static void main(String[] arg)
{
Contract A=new Contract();
Scanner S=new Scanner (System.in);
String F_name,L_name;
System.out.println("enter the first name");
F_name=S.nextLine();
System.out.println("first name:"+Employee.getFirstName(F_name));
System.out.println("enter the last name");
L_name=S.nextLine();
System.out.println(" last name:"+Employee.getLastName( L_name));

double salary;
System.out.println("enter the contracter salary");
salary=S.nextDouble();
System.out.println(Contract.getSalary(salary));
double sal;
System.out.println("enter the regular salary");
sal=S.nextDouble();
System.out.println(Regular.getSal(sal));
String D,d;
System.out.println("enter the department");
D=S.nextLine();
System.out.println(Contract.getDept(D));
String E;
System.out.println("enter the designation");
E=S.nextLine();
System.out.println(Contract.getDesig_(E));
A.display();
}
}

