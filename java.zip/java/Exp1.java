import java.util.*;
class Exp1 extends Exception
{
public Exp1(String M)
{
super(M);
}
}
  class Expt
  {
  public  static class void main(String arg[])
  {
  Scanner S=new Scanner(System.in);
  try
  {
  System.out.println("Enter the value");
  int i=S.nextInt();
  if(i<0)
  {
  throw new Exp1("-ve not allowed");
  }
  System.out.println("you enterd:"+i);
  }
  catch(Exp1 t)
  {
  System.out.println("cought exception":+e.M);
  }
  finally
  {
  System.out.println("handled");
  }
  }
  }
  
