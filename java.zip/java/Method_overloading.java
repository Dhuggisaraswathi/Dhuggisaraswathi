import java.util.*;
import java.io.*;
class Method_overloading
{
static int getSum(int a,int b)
{
return a+b;
}
static int getSum(int a,int b,int c)
{
return a+b+c;
}
}
class  T
{
public static void main(String[] arg)
{
Scanner S=new Scanner (System.in);
int a,b,c;
System.out.println("enter a,b value");
a=S.nextInt();
b=S.nextInt();
System.out.println("Sum:"+Method_overloading.getSum(a,b));
System.out.println("enter c value");
c=S.nextInt();
System.out.println("Sum:"+Method_overloading.getSum(a,b,c));
}
}
