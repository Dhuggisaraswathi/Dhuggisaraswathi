package samatha;
public class Calcu
{
public int Add(int a,int b)
{
return a+b;
}
public int Sub(int a,int b)
{
return a-b;
}
public double Mul(int a,int b)
{
return a*b;
}
public double Div(int a,int b)
{
return a/b;
}
}

