import java.util.*;
class String_comp
{
public static void main(String...arg)
{
Scanner S=new Scanner (System.in);
String a,b;
System.out.println("enter two strings");
a=S.nextline();
b=S.nextline();

if(a.compareTo(b)>0)
{
System.out.println(a+"greater than "+b);
}
else if(a.compareTo(b)<0)
{
System.out.println(a+"less than"+b);
}
else
{
Syem.out.println("equal");
}
}
}


