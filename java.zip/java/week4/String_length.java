import java.util.*;
class  String_length
{
public static void main(String...arg)
{
Scanner S=new Scanner(System.in);
String a;
System.out.println("enter any string");
a=S.nextLine();

System.out.println(a.length());
}
}
