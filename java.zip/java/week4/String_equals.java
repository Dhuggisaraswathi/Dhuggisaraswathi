import java.util.*;
class String_equals
{
public static void main(String...arg)
{
Scanner S=new Scanner(System.in);
String a,b;
System.out.println("enter two strings");
a=S.nextLine();
b=S.nextLine();

if(a.equals(b))
{
System.out.println("true");
}
else{
System.out.println("false");
}
//String c,d;
//ystem.out.println("enter two strings");
//c=S.nextLine();
//=S.nextLine();


if(a==b)
{
System.out.println("true");
}
else
{
System.out.println("false");
}
//String e,f;
//System.out.println("enter two strings");
//e=S.nextLine();
//f=S.nextLine();

if(a.equalsIgnoreCase(b))
{
System.out.println("true");
}
else
{
System.out.println("false");
}
}
}
