import java.util.*;
class String_concat
{
public static void main(String...arg)
{
Scanner S=new Scanner(System.in);
String a,b;
System.out.println("Enter two strings");
a=S.nextLine();
b=S.nextLine();
//concat(a,b);

System.out.println(a.concat(b));

}
}
