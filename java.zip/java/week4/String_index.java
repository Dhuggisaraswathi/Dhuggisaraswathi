import java.util.*;
class String_index
{
public static void main(String...arg)
{
Scanner S=new Scanner (System.in);
String str;
char ch;
int i=0;
System.out.println("enter any text");
str=S.nextLine();
System.out.println("enter the character");
ch=S.next().charAt(0);
int r=0;
for(i=0;i<str.length();i++)
{
if(str.charAt(i)==ch)
{
r++;}
}

System.out.println(r);
}
}
