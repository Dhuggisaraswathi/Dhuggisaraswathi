import java.util.*;
import java.io.*;
class Train extends Thread
{
try
{
public void run()
{

int i,n;
System.out.println("enter how many  member to enter into the theatre");
//int a[]=new int[n];
for(i=1;i<n;i++)
//Scanner u=new Scanner(System.in);
//a[i]=u.nextInt();
public void buy()
{
Sytem.out.println(" person buyed ticket:"+i);
}
public void show()
{
System.out.println("person showed ticket"+i);
}
public void enter()
{
System.out.println("person entered into theatre"+i);
}
}
}
catch(Exception e)
{
System.out.println("no person came");
}
}
class T
{
public static void main(String[] arg)
{
Scanner s=new Scanner(System.in);
Train T=new Train();
System.out.println("enter size");
n=s.nextInt();
T.start();
}
}
