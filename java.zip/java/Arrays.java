import java.util.*;
import java.io.*;
class Arrays
{
public static void main(String[] aggs)
{
int n,i;
Scanner s=new Scanner(System.in);
System.out.println("enter the size");

n=s.nextInt();
int a[]=new int[n];
System.out.println("enter the elements");
for(i=0;i<a.length;i++)
{
a[i]=s.nextInt();
}
for(i=0;i<a.length;i++)
{
System.out.print(a[i]+" ");
}
}
}

