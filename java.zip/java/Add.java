import java.util.*;
import java.io.*; 
class Sum
{
public static void main(String[] arr)
{
int r1,r2,c1,c2,i,j;
Scanner N=new Scanner(System.in);
System.out.println("enter the no of rows");
r1=N.nextInt();
r2=N.nextInt();
System.out.println("enter the no of coloums");
c1=N.nextInt();
c2=N.nextInt();
int a[][]=new int[r1][c1];
int b[][]=new int[r2][c1];
int c[][]=new int[r1][c1];
if(r1==r2&&c1==c2)
{
System.out.println("enter the elements");
for(i=0;i<a.length;i++)
{
for(j=0;j<a.length;j++)
{
a[i][j]=N.nextInt();
}
}
System.out.println("enter  the elements");
for(i=0;i<b.length;i++)
{
for(j=0;j<b.length;j++)
{
b[i][j]=N.nextInt();
}
}
for(i=0;i<c.length;i++)
{
for(j=0;j<c.length;j++)
{
//c[i][j]=N.nextInt();
c[i][j]=a[i][j]+b[i][j];
System.out.print(c[i][j]);
}
System.out.println("\n");
}
}
else
{
System.out.println("not possible");


}

}
}
