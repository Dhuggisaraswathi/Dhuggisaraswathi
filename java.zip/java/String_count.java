import java.util.*;
import java.io.*;
class String_count
{
public static void main(String...arg)
{
Scanner S=new Scanner(System.in);
char str;
int count=0,i=0;
System.out.println("enter the string");
str=S.next().charAt(0);
if(str=='a'||str=='e'||str=='i'||str=='o'||str=='u'||str=='A'||str=='E'||str=='I'||str=='O'||str=='U')
{
count++;
System.out.println(count);
}
else
{
i++;
System.out.println(i);
}
}
}
