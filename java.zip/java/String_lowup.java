import java.util.*;
import java.io.*;
class String_lowup
{
public static void main(String...arg)
{
Scanner S=new Scanner (System.in);
String a,b;
System.out.println("enter  string");
a=S.nextLine();
System.out.println(a.toLowerCase());
//System.out.println("enter another string");
//b=S.nextLine();
System.out.println(a.toUpperCase());

}
}
