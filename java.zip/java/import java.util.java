import java.util.*;
class Add
{
    public static void main(String[] arg)
    {
        int a,b,c;
        Scanner S=new Scanner(System.in);
        System.out.println("enter a,b values");
        a=S.nextInt();
        b=S.nextInt();
        c=a+b;
        Syatem.out.println(c);
    }
}