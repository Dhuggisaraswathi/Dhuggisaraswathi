import java.util.*;
import java.io.*;
class E
{
public static void main(String[] arg)
{
System.out.println("hello");
try
{

int a=10/0;
}
catch(ArithmaticException e)
{
System.out.println(e);
System.out.println("exception handled");
System.out.println("bye");

}
}
}

