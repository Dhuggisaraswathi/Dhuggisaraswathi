import java.util.*;
import java.io.*;
class Exception3
{
public static void main(String[] arg)
{
Scanner S=new Scanner(System.in);
System.out.println("enter any string");
String name=S.nextLine();
try{
Class<?>clazz=Class.forName(name);
System.out.println("found"+clazz.getName());
}
catch(ClassNotFoundException e)
{
System.out.println("not found"+e.getMessage());
}
}
}
