import java.util.*;
import java.io.*;
class This
{
int id;
String name;
void display(int id,String name)

{
this.id=id;
this.name=name;
System.out.println("id:"+" "+id+" "+"name:"+ " "+name);
}
public static void main(String arg[])
{
This S=new This();
int id;
String name;
Scanner R=new Scanner(System.in);
System.out.println("enter the id and name");
id=R.nextInt();
name=R.nextLine();

S.display(id,name);
}
}


