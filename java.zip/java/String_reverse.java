import java.util.*;
import java.io.*;
class String_reverse
{
public static void main(String...arg)
{
Scanner S=new Scanner(System.in);
int i;
String str;
System.out.println("enter any string");
str=S.nextLine();
for(i=str.length()-1;i>=0;i--)
{
String ch=str.charAt(i);
}
System.out.println(str);
}
}
