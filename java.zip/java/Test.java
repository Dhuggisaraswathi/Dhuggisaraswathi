import java.util.*;
import java.io.*;
class Employee
{
	String firstname;
	String lastname;
	public String getFirstname()
	{
	   return firstname;
	}
	public String getLastname()
	{
	   return lastname;
	}
	public void setFirstname(String name)
	{
	    this.firstname=name;
	}
	public void setLastname(String newname)
	{
	    this.lastname=newname;
	}
}
class ContractEmployee extends Employee
{
	String dep;
	String design;
	double salary;
	public void display()
	{
	  System.out.println(firstname.concat(lastname));
	}
	public String getDepartment()
	{
	   return dep;
	}
	public String getdesignation()
	{
	   return design;
	}
	public void setDepartment(String depart)
	{
	   this.dep=depart;
	}
	public void setdesignation(String des)
	{
	    this.design=des;
	}
}
class RegularEmployee extends Employee
{
	String dep;
	String design;
	double salary;
	public void display()
	{
	  System.out.println(firstname.concat(lastname));
	}
	public String getDepartment()
	{
	   return dep;
	}
	public String getdesignation()
	{
	   return design;
	}
	public void setDepartment(String depart)
	{
	   this.dep=depart;
	}
	public void setdesignation(String des)
	{
	    this.design=des;
	}
}
class Test
{
	public static void main(String[] args)
	{
	  String f,l,d,de;
	  double s;
	  System.out.println("Contract Employee");
	  ContractEmployee obj=new ContractEmployee();
	  Scanner user=new Scanner(System.in);
	  System.out.println("enter the first name");
	  f=user.next();
	  System.out.println("enter the last name");
	  l=user.next();
	  System.out.println("enter the department");
	  d=user.next();
	  System.out.println("enter the designation");
	  de=user.next();
	  System.out.println("enter the salary");
	  s=user.nextDouble();
	  System.out.println("*********************");
	  obj.setFirstname(f);
	  obj.setLastname(l);
	  obj.display();
	  obj.setDepartment(d);
	  obj.setdesignation(de);
	  System.out.println("Firstname="+obj.getFirstname());
	  System.out.println("lastname="+obj.getLastname());
	  System.out.println("department="+obj.getDepartment());
	  System.out.println("designation="+obj.getdesignation());
	  System.out.println("salary="+s);
	  
	  System.out.println("---------");
	  System.out.println("Regular Employee");
	  RegularEmployee obj1=new RegularEmployee();
	  System.out.println("enter the first name");
	  f=user.next();
	  System.out.println("enter the last name");
	  l=user.next();
	  System.out.println("enter the department");
	  d=user.next();
	  System.out.println("enter the designation");
	  de=user.next();
	  System.out.println("enter the salary");
	  s=user.nextDouble();
	  System.out.println("*********************");
	  obj1.setFirstname(f);
	  obj1.setLastname(l);
	  obj1.display();
	  obj1.setDepartment(d);
	  obj1.setdesignation(de);
	  System.out.println("firstname="+obj1.getFirstname());
	  System.out.println("lastname="+obj1.getLastname());
	  System.out.println("department="+obj1.getDepartment());
	  System.out.println("designation="+obj1.getdesignation());
	  System.out.println("salary="+s);
	  
	  
	 }
}
	  
	  
	  
	  
	


