import java.util.*;
import java.io.*;
class Wrapper
{
public static void main(String[] ar)
{
Scanner S=new Scanner (System.in);
int n;
int r;
System.out.println("enter n value");
n=S.nextInt();
System.out.println("enter r value");
r=S.nextInt();
//Integer r=n;
int n2=r;
System.out.println(n2);
String s="123";
int n3=Integer.parseInt(s);
System.out.println(n3*2);
}
}

//=n.intValue();

