import java.util.*;
import java.io.*;
class Twowheeler
{
static String getType(String Type)
{
return Type;
}
static String getName(String Name)
{
return Name;
}
}
class Geared extends twowheeler
{

{
class Test
{
public static void main(String[] arg)
{
Scanner S=new Scanner(System.in);
String Type,Name;
System.out.println("enter the type");
Type=S.nextLine();
Twowheeler.getType(Type);
System.out.println("enter the name");
Name=S.nextLine();
Twowheeler.getName(Name);
int n,i;
int a[];
System.out.println("enter  the geared vehicles");
for(i=0;i<a.length;i++)
{
a[i]=S.nextInt();
}

}
}
