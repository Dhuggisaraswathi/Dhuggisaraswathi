import java.util.*;
import java.io.*;
class Duplicate
{
	public static void main(String...args)
	{
	Vector <Integer>integers=new Vector<Integer>();
	System.out.print("enter the num");
	Scanner user=new Scanner(System.in);
	for(int i=0;i<5;i++)
	{
	int temp=user.nextInt();
	if(!integers.contains(temp))
	integers.add(temp);
	}
	System.out.println(integers);
	}
}
