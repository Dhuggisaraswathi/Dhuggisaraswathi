import java.util.*;
import java.io.*;
class Method_overriding
{
void display()
{
System.out.println("Hello");
}
}
class Over extends Method_overriding
{
void display()
{
System.out.println("world");
}
public static void main(String[] arg)
{
Over B=new Over();
B.display();
}
}

