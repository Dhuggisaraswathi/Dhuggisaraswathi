import java.util.*;
import java.io.*;
class Aaaa

{
//public static void main(String[] arg)
//{
/*final int a=10;
a=a+10;
System.out.println(a);*/
final void display()
{
System.out.println("hello");

}
}
class B extends Aaaa
{
void display()
{
System.out.println("child");
}
}
class C
{
public static void main(String[] arg)
{
B obj=new B();
obj.display();
}
}


