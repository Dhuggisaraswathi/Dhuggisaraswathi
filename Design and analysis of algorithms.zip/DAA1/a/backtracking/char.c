import java.util.Scanner;

public class backtrack_Strings{
    public void per(char[] arr,char n,char pos)
    {
            if(pos==n)
            {
                    for(char i='a';i<n;i++)
                    {
                         System.out.print(arr[i]+" ");
                    }
                    System.out.println();
                    return;
            }
            for(char i='a';i<=n;i++)
            {
                int f=0;
                for(char j=0;j<pos;j++)
                {
                    if(arr[j]==i)
                    {
                        f=1;
                        break;
                    }
                }
                if(f==0)
                {
                    arr[pos]=i;
                    per(arr,n,pos+1);
                }
            }

    }
    public static void main(String args[])
    {
        Scanner user=new Scanner(System.in);
        System.out.println("Enter size:");
        int n=user.nextInt();
        char a[]=new char[n];
        int arr[]=new int[n];
        backtrack_Strings bb=new backtrack_Strings();
        int i=0;
        bb.per(arr,n,i);
    }
    
}
