#include <stdio.h>
#include <stdbool.h>

#define MAX 20 // Maximum board size

void printSolution(int board[MAX][MAX], int N) {
    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++)
            printf(" %d ", board[i][j]);
        printf("\n");
    }
}

bool isSafe(int board[MAX][MAX], int row, int col, int N) {
    int i, j;

    // Check this row on the left side
    for (i = 0; i < col; i++)
        if (board[row][i])
            return false;

    // Check upper diagonal on the left side
    for (i = row, j = col; i >= 0 && j >= 0; i--, j--)
        if (board[i][j])
            return false;

    // Check lower diagonal on the left side
    for (i = row, j = col; j >= 0 && i < N; i++, j--)
        if (board[i][j])
            return false;

    return true;
}

bool solveNQUtil(int board[MAX][MAX], int col, int N) {
    if (col >= N)
        return true;

    for (int i = 0; i < N; i++) {
        if (isSafe(board, i, col, N)) {
            board[i][col] = 1;

            if (solveNQUtil(board, col + 1, N))
                return true;

            board[i][col] = 0; // Backtrack
        }
    }

    return false;
}

void solveNQ(int N) {
    int board[MAX][MAX] = {0};

    if (solveNQUtil(board, 0, N) == false) {
        printf("Solution does not exist");
    } else {
        printSolution(board, N);
    }
}

int main() {
    int N;
    printf("Enter the size of the board (maximum %d): ", MAX);
    scanf("%d", &N);

    if (N > 0 && N <= MAX) {
        solveNQ(N);
    } else {
        printf("Invalid board size.\n");
    }

    return 0;
}

