//fractional knapsack
#include<stdio.h>
void fractional(int wt[],int val[],int n,int w)
{
    int res=0;
    for(int i=0;i<n;i++)
    {
        if(wt[i]<=w)
        {
            res=res+val[i];
            w=w-wt[i];
        }
        else
        {
            res=res+(w*val[i])/wt[i];
            break;
        }
    }
    printf("the value of the bag=%d\n",res);
}
int main()
{
    int n,i,j,t,w;
    printf("enter no.of weights:");
    scanf("%d",&n);
    int frac[n],wt[n],val[n];
    for(i=0;i<n;i++)
    {
        printf("enter the weight and its value:");
        scanf("%d%d",&wt[i],&val[i]);
    }
    printf("enter the bag weight:");
    scanf("%d",&w);
    for(i=0;i<n;i++)
    {
        frac[i]=val[i]/wt[i];
    }
    for(i=0;i<n-1;i++)
    {
        for(j=0;j<n-i-1;j++)
        {
            if(frac[j]<frac[j+1])
            {
                t=frac[j];
                frac[j]=frac[j+1];
                frac[j+1]=t;
               
               
                t=wt[j];
                wt[j]=wt[j+1];
                wt[j+1]=t;
                
                
                
                t=val[j];
                val[j]=val[j+1];
                val[j+1]=t;
            }
        }
    }
    for(i=0;i<n;i++)
    {
    printf("sorted array %d\t%d=%d\n",wt[i],val[i],frac[i]);
    }
    printf("\n");
    fractional(wt,val,n,w);
}
