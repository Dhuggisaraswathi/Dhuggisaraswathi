#include<stdio.h>
#include<limits.h>

int a[100],freq[100];

int sum(int i,int j){
    int s=0;
    for (int k=i;k<=j;k++)
    {
         s+=freq[k];
     }
 return s;
 }
 
int obst(int i,int j)
{
     if(i==j)
       return freq[i];
    //if(i>j)
       //return 0;
    int min=INT_MAX;
    for(int k=i;k<=j;k++)
    {
        int val=obst(i,k-1)+obst(k+1,j)+sum(i,j);
        if(val<min)
            min=val;
     }
    return min;
}

int main()
{
int n,i;
printf("enter size");
scanf("%d",&n);
int key[n],freq[n];
for(i=1;i<=n;i++)
{
printf("keys of %d and freq of %d",i,i);
scanf("%d%d",&key[i],&freq[i]);
}
printf("%d",obst(1,n));
}

