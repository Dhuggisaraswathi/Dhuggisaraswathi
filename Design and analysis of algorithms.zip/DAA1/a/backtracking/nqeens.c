#include<stdio.h>
#include <stdlib.h>
#include <stdbool.h>

int a[100]; 

   bool issafe(int i , int k){
        for(int j = 0 ; j < k ; j++){
               if(a[j]==i ||abs(k-j)==abs(i-a[j])){
                             return false; 
                             }
                       }
                       return true;
                        }
                       
 void nqueens(int n , int k){
    if(n == k){
       for(int i = 0 ; i < n ; i++){
               printf("%d",a[i]); 
            
               }   return ; 
            }
    for(int i = 0 ; i < n ; i++){
          if(issafe(i,k)){
                a[k] = i; 
                nqueens(n,k+1);
                printf("  ");
                //printf("%d\n",t); }}
                }
                }
                }
      
    int main(){
    printf("enter size");
    int n;
    scanf("%d",&n);
   nqueens(n,0); 
   }
