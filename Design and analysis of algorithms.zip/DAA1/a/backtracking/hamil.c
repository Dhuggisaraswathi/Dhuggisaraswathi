#include<stdio.h>
#include<stdbool.h>
int  adj[10][10],a[10],n;
void print(int n)
{
for(int i=0;i<n;i++)
{
printf("%d",a[i]);
}
printf("\n");
}
bool isSafe(int pos,int i)
{
for(int j=1;j<pos;j++)
{
if(a[j]==i)
{
return false;
}
}

if(adj[a[pos]][i]!=1)

return false;
if(pos==n&&adj[i][a[0]]!=1)

return false;
return true;
}

void hc(int n,int pos)
{
if(pos==n)
{
print(n);
return;

}
for(int i=1;i<n;i++)
{
if(isSafe(pos,i))
{
a[pos]=i;
hc(n,pos+1);
}

}
}
int main()
{
int n,i,j;
printf("enter n vertices");
scanf("%d",&n);
printf("enter edges");
for(i=0;i<n;i++)
{
for(j=0;j<n;j++)
{
printf("edge between %d and %d or not",i,j);
scanf("%d",&adj[i][j]);

}
}
hc(n,1);
}


