#include <stdio.h>
#include <limits.h>

// Function to find the sum of frequencies from index i to j
int sum(int freq[], int i, int j) {
    int s = 0;
    for (int k = i; k <= j; k++)
        s += freq[k];
    return s;
}

// Function to find the minimum cost of OBST using tabulation
int obst(int freq[], int n) {
    int dp[n][n];

    // Initialize the cost for a single key
    for (int i = 0; i < n; i++)
        dp[i][i] = freq[i];

    // L is the chain length.
    for (int L = 2; L <= n; L++) {
        for (int i = 0; i <= n - L; i++) {
            int j = i + L - 1;
            dp[i][j] = INT_MAX;

            // Try making all keys in interval keys[i..j] as root
            for (int k = i; k <= j; k++) {
                // Cost when keys[k] becomes root
                int cost = (k > i ? dp[i][k-1] : 0) +
                           (k < j ? dp[k+1][j] : 0) +
                           sum(freq, i, j);
                if (cost < dp[i][j])
                    dp[i][j] = cost;
            }
        }
    }
    return dp[0][n-1]; // Return the minimum cost for the whole array
}

int main() {
    int n;
    printf("Enter the size: ");
    scanf("%d", &n);
    int keys[n], freq[n];
    
    printf("Enter the keys: ");
    for(int i = 0; i < n; i++) {
        scanf("%d", &keys[i]);
    }
    
    printf("Enter the frequencies: ");
    for(int i = 0; i < n; i++) {
        scanf("%d", &freq[i]);
    }

    int minCost = obst(freq, n);
    printf("Minimum cost of OBST: %d\n", minCost);
    return 0;
}

