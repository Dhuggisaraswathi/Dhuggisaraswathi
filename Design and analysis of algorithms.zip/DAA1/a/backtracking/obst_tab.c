#include <stdio.h>
#include <limits.h>
// Recursive function to find the minimum number of multiplications
int sum(int freq[], int i, int j)
{
    int s = 0;
    for (int k = i; k <=j; k++)
       s += freq[k];
    return s;
}
int obst(int freq[],int n) {
//int n;
int dp[n][n];
for (int i = 0; i < n; i++)
dp[i][i] = freq[i];
for (int L = 2; L <= n; L++) {
for (int i = 1; i <=n - L ; i++) {
int j = i + L - 1;
dp[i][j] = INT_MAX;
for (int k = i; k <=j; k++) 
{
int cost = (k > i ? dp[i][k-1] : 0) +
                           (k < j ? dp[k+1][j] : 0) +
                           sum(freq, i, j);
}
}
}
return dp[0][n - 1]; // Return the minimum number of scalar multiplications needed
}
int main() {
int n;
printf("Enter the size: ");
scanf("%d", &n);
int  keys[n],freq[n];
    printf ("enter the keys");
    for(int i=0;i<n;i++)
    {
    	scanf("%d",&keys[i]);
    }
    printf ("enter the freq");
    for(int i=0;i<n;i++)
    {
    	scanf("%d",&freq[i]);
    }

int o= obst(freq, n + 1);
printf("Minimum number of scalar multiplications needed: %d\n",o);
return 0;
}

