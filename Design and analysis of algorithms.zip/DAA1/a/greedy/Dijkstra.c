#include<stdio.h>
#include<limits.h>
int adj[10][10],c[10],p[10],v[10],node[10];
int findminnode(int n)
{
	int i,j,min=INT_MAX;
	for(i=0;i<n;i++)
	{
		if(v[i]==-1)
		{
			if(c[i]<min)
			{
				min=c[i];
				j=i;
			}
		}
	}
	return j;
}
int dijkstra(int n,int s)
{
	int i,j,k=n,sum=0;
	while(k>0)
	{
		i=findminnode(n);
		v[i]=1;
		for(j=0;j<n;j++)
		{
			if(v[j]==-1 && adj[i][j]!=-1)
			{
				if(c[j]>c[i]+adj[i][j])
				{
					c[j]=c[i]+adj[i][j];
					p[j]=i;
				}
			}
		}
		printf("%d-%d=%d\n",node[s],node[i],c[i]);
		sum=sum+c[i];
		k--;
	}
	printf("%d",sum);
}
int main()
{
	int n,s,i,j;
	printf("enter the no of vertices");
	scanf("%d",&n);
	printf("enter the source");
	scanf("%d",&s);
	
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
		printf("edges of %d and %d",i,j);
			scanf("%d",&adj[i][j]);
		}
		node[i]=i;
			p[i]=-1;
			v[i]=-1;
			c[i]=INT_MAX;
	}
	p[s]=s;
	c[s]=0;
	dijkstra(n,s);
}
			
