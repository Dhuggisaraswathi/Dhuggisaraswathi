#include <stdio.h>
#include <limits.h>

#define MAX 100  // Define the maximum number of vertices

int parent[MAX];
int a[MAX][MAX];
int n;

void init(int n) {
    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            printf("%d row %d col  cost", i, j);
            if (i != j) {
                scanf("%d", &a[i][j]);
                a[j][i] = a[i][j];
            } else {
                a[i][j] = 0;
            }
        }
    }
}

int prims(int visit[], int n) {
    int k = n - 1;
    int cost = 0;
    while (k > 0) {
        int min = INT_MAX;
        int p = -1, c = -1;
        for (int i = 0; i < n; i++) {
            if (visit[i] == 1) {
                for (int j = 0; j < n; j++) {
                    if (visit[j] != 1 && a[i][j] != 0) {
                        if (min > a[i][j]) 
                        {
                            min = a[i][j];
                            p = i;
                            c = j;
                        }
                    }
                }
            }
        }
      
        //if (c == -1)
            //break;
        visit[c] = 1;
        parent[c] = p;
        cost += a[p][c];
         printf("Edge %d - %d with cost %d\n", p, c, a[p][c]); 
        k--;
    }
    return cost;
}

int main() {
printf("enter size");
    scanf("%d", &n);
    init(n);
    int visit[MAX] = {0};
    visit[0] = 1;
    printf("minimum cost %d\n", prims(visit, n));
    
    return 0;
}

