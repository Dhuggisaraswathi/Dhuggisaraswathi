#include<stdio.h>
#include<limits.h>






int findmin(int cost[], int visit[]) {
    int min = INT_MAX;
    int mindex = -1; // Initialize mindex to -1
    for (int i = 0; i < 5; i++) {
        if (visit[i] == -1 && cost[i] < min) { // Check if the node is unvisited
            min = cost[i];
            mindex = i;
        }
    }
    return mindex;
}


        
        
    void printpath(int parent[]){
     
     for(int i = 0 ; i < 5 ; i++){
        printf("%d \t",parent[i]); 
        }
    
    
    
    
       for(int i = 1 ; i < 5 ; i++){
            printf("%d --- %d",parent[i],i); 
            }}
            
            













 
  
void dik(int parent[],int cost[], int graph[][5] , int visit[],int n){
      int k = 1 ; 
    while(k <= n){
    
     int i = findmin(cost,visit); 
     visit[i] = 0 ; 
     for(int j = 0 ; j < n ; j++){
           if(graph[i][j] != 0 && visit[j] == -1 ){
               if(cost[j] > cost[i]+graph[i][j]){
                 cost[j] = cost[i]+graph[i][j] ; 
                 parent[j] = i ; 
                 }
                 }}
                 
                 k++; 
                 }
                 
           printpath(parent); 
           }      
                 
               
               
           
       
     
     
    
    


















int main(){
 
  int parent[5]; 
  int visit[5]; 
  int cost[5]; 
  int n = 5 ; 
  
   int graph[5][5] = {
        {0, 2, 0, 6, 0},
        {2, 0, 3, 8, 5},
        {0, 3, 0, 0, 7},
        {6, 8, 0, 0, 9},
        {0, 5, 7, 9, 0}
    };
  for(int i = 0  ; i < n ; i++){
       parent[i] = 0 ; 
       visit[i] = -1 ; 
       cost[i] = INT_MAX; 
       
       }
         cost[0] = 0 ; 
     parent[0] = 0 ;
     dik(parent,cost,graph,visit,5); 
     }
