import java.util.*;
import java.math.*;
class tree{
	int n;
	int a[],freq[];
	int dp[][];
	 Scanner sc=new Scanner(System.in);
	public tree(int n){
		this.n=n;
		dp=new int[n+2][n+2];
		for(int i=0;i<=n+1;i++)
		{
			for(int j=0;j<=n+1;j++)
			{
				dp[i][j]=-1;
			}
		}
		a=new int[n+1];
        	freq=new int[n+1];
        	System.out.println("enter key values:");
        	for(int i=1;i<=n;i++)
        	{
           		a[i]=sc.nextInt();
         	}
         	System.out.println("enter freq for corresponding key values:");
         	for(int i=1;i<=n;i++)
        	{
           		freq[i]=sc.nextInt();
         	}
	}
	 int sum(int i,int j)
	 {
	 int s=0;
	 for(int k=i;k<=j;k++)
	 {
		s=s+freq[k];
	}
	return s;
	}

	int obst(int i,int j)
	{
		if(dp[i][j]!=-1)
		return dp[i][j];
		if(i>j)
		return dp[i][j]=0;
		if(i==j){
		 return dp[i][j]=freq[i];
		 }
		
		 int min=Integer.MAX_VALUE;
		for( int k=i;k<=j;k++)
		 {
			 int val=obst(i,k-1)+obst(k+1,j)+sum(i,j);
			 if(val<min)
			 	min=val;
			 	
		 }
		 return dp[i][j]=min;
	}
 }
class test{
    public static void main(String args[]){
      
        Scanner sc=new Scanner(System.in);
        int n;
        System.out.println("enter array size:");
        n=sc.nextInt();
        tree b=new tree(n);       
       System.out.println(b.obst(1,n));
      }
}
