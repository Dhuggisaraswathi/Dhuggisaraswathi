import java.util.*;
class prims
{
int[] parent;
int[][] a;
int n,c,p;
public prims(int n)
{
parent=new int[n];
a=new int[n][n];
Scanner sc=new Scanner(System.in);
for(int i=0;i<n;i++)
{
for(int j=i+1;j<n;j++)
{
System.out.println(i+"row"+j+"col");
if(i!=j)
{
a[i][j]=a[j][i]=sc.nextInt();
}
else
a[i][j]=0;
}
}
}
int prims(int visit[],int n)
{
int k=n-1;
int cost=0;
while(k>0)
{
int min=Integer.MAX_VALUE;
p=-1;
c=-1;
for(int i=0;i<n;i++)
{
if(visit[i]==1)
{
for(int j=0;j<n;j++)
{
if(visit[j]!=1 && a[i][j]!=0)
{
if(min>a[i][j])
{
min=a[i][j];
p=i;
c=j;
}
}
}
}
}
if(c==-1)
break;
visit[c]=1;
parent[c]=p;
cost+=a[p][c];
k--;
}
return(cost);
}

}
class primscode
{
public static void main(String[] args)
{
Scanner sc=new Scanner(System.in);
int n=sc.nextInt();
prims p=new prims(n);
int[] visit=new int[n];
visit[0]=1;
System.out.println(p.prims(visit,n));
}
}
