#include<stdio.h>
#include<string.h>
//string matching with one ,2,3..... skipping
int main() {
    char str1[100];
     printf("enter text");
      fgets(str1,sizeof(str1),stdin);

    char str2[100];
     printf("enter text");
      fgets(str2,sizeof(str2),stdin);
 

    int m = strlen(str1);
    int n = strlen(str2);
    int f2 = 0;

    if (n > m) {
        printf("Not found");
        return 0;
    }

    for (int i = 0; i <= m - n; i++) {
        if (str1[i] == str2[0]) {
            int f = 0;
              int s = 1 ; 
            for (int j = 1; j < n; j++) {
                if (str1[i + j * 2] != str2[j]) {
                    f = 1;
                    break;
                }
            }

            if (f == 0) {
                f2 = 1;
                break;
            }
        }
    }

    if (f2 == 1) {
        printf("found");
    } else {
        printf("Not found");
    }

    return 0;
}

