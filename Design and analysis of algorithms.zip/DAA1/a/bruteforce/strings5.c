#include<stdio.h>
#include<string.h>
//string matching with skipping characters by increasing the comparision
int main() {
    char str1[100] = "abcdefghijklmnopqrstu";
    char str2[100] = "acfjou"; 

    int m = strlen(str1);
    int n = strlen(str2);
    int f2 = 0 ;

    int skip = 0;
    for (int i = 0; i <= n ;i++) {
        
          
       if(str1[i] == str2[skip]){
        skip++;
        i = i+skip; 
        f2 = 1 ;
        }
        else{
          f2 = 0 ; 
          break; 
         
         }
        
       
        
    }

    if (f2 == 1) {
        printf("Found");
    } else {
        printf("Not found");
    }

    return 0;
}

