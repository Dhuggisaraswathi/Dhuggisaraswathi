#include <stdio.h>
//convex hull
struct point {
    int x;
    int y;
}; 

int main() {
    int n; 
    scanf("%d", &n);
    struct point p[10];
    
    // Input the points
    for (int i = 0; i < n; i++) {
        scanf("%d %d", &p[i].x, &p[i].y);
    }
    
    int cnt = 0;
    
    // Iterate over all pairs of points
    for (int i = 0; i < n - 1; i++) {
        for (int j = i + 1; j < n; j++) {
            int a = p[i].y - p[j].y; 
            int b = p[j].x - p[i].x; 
            int c = p[j].x * p[i].y - p[i].x * p[j].y; 
            int np = 0, nn = 0; 
            
            // Count the number of points on each side of the line
            for(int k = 0; k < n; k++) {
                int val = a * p[k].x + b * p[k].y - c; 
                if(val > 0)
                    np++; 
                else if(val < 0)
                    nn++; 
            }
            
            // Check if all points are on one side of the line
            if(np == 0 || nn == 0)
                cnt++;
        }
    }
    
    // Output the number of edges on the convex hull
    printf("%d", cnt);     
    return 0;
}

