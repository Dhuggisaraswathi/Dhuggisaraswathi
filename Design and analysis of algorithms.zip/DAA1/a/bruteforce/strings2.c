#include<stdio.h>
#include<string.h>

void reverse(char* str ){
        int length = strlen(str); 
        for(int i = 0 ; i < length/2 ; i++){
           int temp = str[i] ;
           str[i] = str[length-i-1]; 
           str[length-i-1] = temp; 
           }
           }
         int main(){

      char  str1[100] = "abcabcabcadcba";
      char str2[100] = "abcde";
      
      int m = strlen(str1); 
      int n = strlen(str2); 
       reverse(str2); 
       
      int f2 = 0 ; 
      for(int i = 0 ; i <= m-n ; i++){
          
         
           if(str1[i] == str2[0]){
                int f = 0 ; 
           for(int j = 0 ; j < n ; j++){
                       
               if(str2[j] != str1[i+j]){
                     f = 1; 
                           break; }}
                        if(f == 0 ){
                           f2 = 1; 
                          }}}
                          if(f2 == 1){
                            printf("found"); }
                            else if(f2 == 0){
                             printf("Not found"); }
                            
           }
