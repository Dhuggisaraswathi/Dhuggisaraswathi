#include <stdio.h>
#include <string.h>

int main() {
    char s1[100] = "abcdefghijk";
    char s2[100];
 
    int m = strlen(s1);
    
    printf("%c", s1[0]); // Print the first character of s1 as a character, not a string
    int k = 1;
    for (int i = 1; i < m; i++) {
        if (i % 2 == 0) { // Check if the index is even
            printf(" %c", s1[i + k]); // Print the character at index i+k from s1
            k++;
        }
    }
    
    return 0; // Return 0 to indicate successful execution
}

