#include <stdio.h>
#include <math.h>
#include <limits.h>
//convex hull
struct point {
    int x;
    int y;
}; 

int main() {
    int n; 
    scanf("%d", &n);
    int nn, np; 
    struct point p[10];
     for (int i = 0; i < n; i++) {
        scanf("%d %d", &p[i].x, &p[i].y);
    }
    int a ,b,c ;
    int cnt = 2 ; 
      for (int i = 0; i < n - 1; i++) {
        for (int j = i + 1; j < n; j++) {
          a = p[i].y-p[j].y; 
          b = p[j].x-p[i].x; 
          c = p[j].x*p[j].y-p[i].x*p[j].y; 
          np = 0 , nn= 0 ; 
          for(int k = 0 ; k < n ; k++){
              int val = a*p[k].x+b*p[k].y-c; 
              if(val >0){
                 np++; 
                 cnt += 2 ; 
                 }
                else if(val < 0){
                nn++; 
                cnt += 2 ; 
                 }
                 if(np == 0 || nn == 0){
                     printf("The no of points in %d %d   \n",k,cnt); 
                     }}}
                 
                 
                 }}
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
