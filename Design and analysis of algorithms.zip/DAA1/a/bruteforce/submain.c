#include<stdio.h>
#include<string.h>
int main()
{
	char a[20],b[20];
	int f1=0,f,i,j,s;
	printf("enter the super string");
	scanf("%s",a);
	printf("enter the substring");
	scanf("%s",b);
	int m=strlen(a)+1;
	int n=strlen(b);
	for(i=0;i<m-n;i++)
	{
		if(a[i]==b[0])
		{
			f=0;
			for(j=0;j<n;j++)
			{
				if(b[j]!=a[i+j])
				{
					f=1;
					break;
				}
			}
			if(f==0)
			{
				f1++;
				s=i;
			}
		}
	}
		printf("the count of each subtring is %d\n",f1);
		if(f1==0)
		printf("string doesn't match\n");
		else
		{
		printf("string is matched\n");
		printf("index=%d\n",s);
		}
	
}

	
