#include<stdio.h>
#include<string.h>
void main()
{
int flag=0;
char a[100];
int c=0;
char b[100];
printf("enter ");
scanf("%s",a);
scanf("%s",b);
int m=strlen(a);
int n=strlen(b);
int p=0;
int k=0;
int f1=0;
int f=0;
for(int i=0;i<=m-n;i++)
{
if(a[i]==b[0])
{
int flag=0;
for(int j=0;j<n;j++)
{
if(b[j]!=a[i+p+j])
{
flag=1;
break;
}
k++;
p=p+k;
} 
if(flag==0)
{c++;
f=i;
f1++;
}
}
}
if(f1==0)
printf("not present ");
else
printf("index of matching substring in string=%d \n" ,f);
printf("count of occuring of substring =%d", c);
}

