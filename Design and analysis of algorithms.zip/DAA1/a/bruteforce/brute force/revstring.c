#include<stdio.h>
#include<string.h>
int main()
{
	char a[20],b[20];
	int f1=0,f,i,j,s;
	printf("enter the superstring");
	scanf("%s",a);
	printf("Enter the substring");
	scanf("%s",b);
	int m=strlen(a)+1;
	int n=strlen(b);
	for(int i=0;i<n/2;i++)
	{
		char t=b[i];
		b[i]=b[n-i-1];
		b[n-i-1]=t;
	}
	printf("reverse of substring is %s\n",b);
	int l=strlen(b);
	printf("%d\n",l);
	for(i=0;i<m-l;i++)
	{
		if(a[i]==b[0])
		{
			f=1;
			for(j=0;j<n;j++)
			{
				if(b[j]!=a[i+j])
				{
					f=1;
					break;
				}
			}
			if(f==1)
			{
				f1++;
				s=i;
			}
		}
	}
		
		if(f1==1)
		printf("string doesn't match\n");
		else
		{
		printf("string is matched\n");
		printf("index=%d\n",s);
		}
	
}

