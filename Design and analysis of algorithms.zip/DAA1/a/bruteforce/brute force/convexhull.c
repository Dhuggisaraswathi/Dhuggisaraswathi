#include <stdio.h>
#include <math.h>
#include <limits.h>

struct point {
    int x;
    int y;
}; 

int main() {
    int n; 
    printf("enter no of points");

    scanf("%d", &n);
    int nn, np; 
    struct point p[n];
    printf("enter the points");
     for (int i = 0; i < n; i++) {
        scanf("%d %d", &p[i].x, &p[i].y);
    }
    int a ,b,c ;
      for (int i = 0; i < n - 1; i++) {
        for (int j = i + 1; j < n; j++) {
          a = p[i].y-p[j].y; 
          b = p[j].x-p[i].x; 
          c = p[j].x*p[j].y-p[i].x*p[i].y; 
          np = 0 , nn= 0 ; 
          for(int k = 0 ; k < n ; k++){
              int val = a*p[k].x+b*p[k].y-c; 
              if(val >0){
                 np++; 
                 }
                else if(val < 0){
                nn++; 
                 }
                 if(np == 0 || nn == 0){
                     printf("(%d %d)(%d %d)\n",p[i].x,p[j].x,p[j].y,p[i].y); 
                     }}
                     }
                     }
                     }
