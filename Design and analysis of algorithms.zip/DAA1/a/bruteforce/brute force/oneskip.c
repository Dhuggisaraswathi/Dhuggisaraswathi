#include<stdio.h>
#include<string.h>
//string matching one skipping
int main(){
 
    char a[100]; 
    char b[100];
    printf("enter the super string");
	scanf("%s",a);
	printf("enter the substring");
	scanf("%s",b);
    int f1 = 0 ; 
    int k = 0 ; 
   for(int i = 0 ; i < strlen(a); i++){
    printf("%c",a[k]); 
          if(a[i] == b[k]){
              f1 = 1;
               }
          else {
            
             f1 = 0 ; 
            }
          i++; 
          k++; 
          }
          
     if(f1 == 1){
     
     printf("found at %s",f1); 
     
     }     
       
     else{
        printf("Not found"); 
        }   
          
          
          
          }
          
