#include<stdio.h>
#include<string.h>
void main()
{
char a[10] ;
char b[10];
printf("enter the string ");
scanf("%s" ,a);
printf("enter the sub string ");
scanf("%s" ,b);
int m=strlen(a);
int n=strlen(b);
int flag=0;
int p,k;
int f,f1;
int c=0;
for(int i=0;i<=m-n;i++)
{
if(a[i]==b[0])
{
flag=0, p=0,k=0;
for(int j=0;j<n;j++)
{
if(b[j]!=a[i+p+j])
{
flag=1;
break;
}
k++;
p=p+k;
} 
if(flag==0)
{c++;
f1++;
f=i;
}
}
}
if(f1==0)
printf("not present ");
else
printf("index of matching substring in string=%d \n" ,f);
printf("count of occuring of substring =%d", c);
}


