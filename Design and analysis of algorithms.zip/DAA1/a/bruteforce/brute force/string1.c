#include<stdio.h>
#include<string.h>
//string matching of multiple skip
int main(){

      char  str1[100] ;
      printf("enter text");
      fgets(str1,sizeof(str1),stdin);

      char str2[100];
       printf("enter  matching text");
      fgets(str2,sizeof(str2),stdin);

      int m = strlen(str1); 
      int n = strlen(str2); 
      int f2 = 0 ; 
      int j,i;
      for(i = 0 ; i <= m-n ; i++){
          
         
           if(str1[i] == str2[0]){
                int f = 0 ; 
           for( j = 0 ; j < n ; j++){
                       
               if(str2[j] != str1[i+j]){
                     f = 1; 
                           break; }}
                        if(f == 0 ){
                           f2 = 1; 
                          }}}
                          if(f2 == 1){
                          i--;
                            printf("found at %d",i); }
                            else {
                             printf("Not found"); 
                             }
                            
           }
