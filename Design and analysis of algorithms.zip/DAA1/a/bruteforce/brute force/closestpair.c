#include<stdio.h>
#include<math.h>
#include<limits.h>
struct point
{
	int x,y;
};
int main()
{
	int n;
	printf("enter the no of points");
	scanf("%d",&n);
	struct point p[n];
	printf("enter the points x and y");
	int min=INT_MAX,a,b;
	for(int i=0;i<n;i++)
	{
		scanf("%d%d",&p[i].x,&p[i].y);
	}
for(int i=0;i<(n-1);i++)
{
	for(int j=i+1;j<n;j++)
	{
		int d=sqrt(pow((p[i].x-p[j].x),2)+pow((p[i].y-p[j].y),2));
		if(d<min)
		{
			min=d;
			a=i;
			b=j;
		
		}
	}
}
printf("min closest pair %d\n",min);
printf("at points (%d,%d) and (%d,%d)",p[a].x,p[a].y,p[b].x,p[b].y);
}

