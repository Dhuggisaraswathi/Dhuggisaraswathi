#include<stdio.h>
#include<stdbool.h>
int ss(int n,int w,int wt[])
{
int i,j;
if(n==0&&w!=0)
return false;
if(w==0)
return true;
if(wt[n-1]<=w)
return ss(n-1,w-wt[n-1],wt)||ss(n-1,w,wt);
else
return ss(n-1,w,wt);

}
int main()
{
int n,w,i;
printf("enter the size of set and sum");
scanf("%d%d",&n,&w);
int val[n],wt[n];
printf("enter the elements in the set");
for(i=0;i<n;i++)
{
scanf("%d",&wt[i]);
}
bool k;
k=ss(n,w,wt);
if(k==true)
printf("yes");
else
printf("no");
}

