#include<stdio.h>
#include<stdbool.h>
int ss(int n,int w,int wt[])
{
int i,j,max;
int a[n+1][w+1];
for(i=0;i<=n;i++)
{
for(j=0;j<=w;j++)
{
if(i==0&&j!=0)
{
a[i][j]=0;
}
else if(j==0)
{
a[i][j]=1;
}
else if(wt[i-1]<=j)
{
a[i][j]=a[i-1][j-wt[i-1]]||a[i-1][j];
}
else
{
a[i][j]=a[i-1][j];
}
}
}    
return a[n][w];
}
int main()
{
int n,w,i;
printf("enter the size of set and sum");
scanf("%d%d",&n,&w);
int val[n],wt[n];
printf("enter the elements in th set");
for(i=0;i<n;i++)
{
scanf("%d",&wt[i]);
}
int k;
k=ss(n,w,wt);
if(k!=0)
printf("yes");
else
printf("no");
}




