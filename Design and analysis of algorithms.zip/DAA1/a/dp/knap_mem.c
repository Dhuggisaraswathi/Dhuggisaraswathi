#include<stdio.h>
#include<math.h>
#include<limits.h>
int ks(int n,int w,int val[],int wt[],int a[n][w])
{
if(a[n][w]!=-1)
return a[n][w];
 if(n==0||w==0)
return a[n][w]=0;
 if(wt[n-1]<=w)
 {
//return a[n][w]=max((val[n-1]+ks(n-1,w-//wt[n-1],val,wt,a)),ks(n-1,w,val,wt,a));
int k=val[n-1]+ks(n-1,w-wt[n-1],val,wt,a);
int b=ks(n-1,w,val,wt,a);
int max;
if(k>b)
{
max=k;
}
else
{
max=b;
}
}
else
return a[n][w]=ks(n-1,w,val,wt,a);
}
int main()
{
int i,j,w=0,n=0;
printf("enter the no.of ways and whole weight");
scanf("%d%d",&n,&w);
int val[n],wt[n];
printf("enter the weight of all items");
for(i=0;i<n;i++)
{
scanf("%d",&wt[i]);
}
printf("enter the value of all items");
for(i=0;i<n;i++)
{
scanf("%d",&val[i]);
}

int a[n+1][w+1];
for(i=0;i<=n;i++)
{
for(j=0;j<=w;j++)
{
a[i][j]=-1;
}
}
printf("%d",ks(n,w,val,wt,a));
}
