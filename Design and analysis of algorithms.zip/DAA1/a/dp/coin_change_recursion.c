#include<stdio.h>//no.of ways for getting given amount by given type of coins //unbounded
#include<stdbool.h>
int cc(int n,int w,int wt[])
{
  
 if(n==0 && w!=0)
 return false;
 else if(w==0)
 return true;
 if(wt[n-1]<=w)
  return cc(n,w-wt[n-1],wt)+cc(n-1,w,wt);
 else
  return cc(n-1,w,wt);
 }

int main()
{
 int n,i,w;
 printf("no. of total  coins: ");
 scanf("%d",&n);
 int wt[n];
 printf("enter the value of coins:\n");
 for(i=0;i<n;i++)
 {
  scanf("%d",&wt[i]);
 }
 printf("sum of the coins:");
 scanf("%d",&w);
 printf("no.of ways for required rupees by given coins:%d",cc(n,w,wt));
 }
 
 
 
