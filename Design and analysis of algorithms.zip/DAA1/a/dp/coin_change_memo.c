#include<stdio.h>//no.of ways for getting given amount by given type of coins 
 
int cc(int n,int w,int wt[])
{
 int i,j,a[n+1][w+1];
 for(i=0;i<=n;i++)
 {
  for(j=0;j<=w;j++)
  {
   a[i][j]=-1;
   }
 }
 if(a[n][w]!=-1)
 return a[n][w];
 else if(n==0 && w!=0)
 return a[n][w]=0;
 else if(w==0)
 return a[n][w]=1;
 if(wt[n-1]<=w)
  return a[n][w]=cc(n,w-wt[n-1],wt)+cc(n-1,w,wt);
 else
  return a[n][w]=cc(n-1,w,wt);
 }

int main()
{
 int n,i,w;
 printf("how many types of coins: ");
 scanf("%d",&n);
 int wt[n];
 printf("enter the type of coins:\n");
 for(i=0;i<n;i++)
 {
  scanf("%d",&wt[i]);
 }
 printf("enter the rupees:");
 scanf("%d",&w);
 printf("no.of ways: %d",cc(n,w,wt));
 }
 
 
 
