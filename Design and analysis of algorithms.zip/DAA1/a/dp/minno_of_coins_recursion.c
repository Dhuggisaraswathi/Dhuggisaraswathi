 #include<stdio.h>// minimum no.of coins required for getting given amount 
#include<limits.h>
int cc(int n,int w,int wt[])
{
  
 if(n==0 && w!=0)
 return INT_MAX-1000;
 else if(w==0)
 return 0;
 if(wt[n-1]<=w)
 { 
  int x=1+cc(n,w-wt[n-1],wt);
  int y=cc(n-1,w,wt);
  return (x<y?x:y);
  //return 1+cc(n,w-wt[n-1],wt)+cc(n-1,w,wt);
 }
 else
  return cc(n-1,w,wt);
 }

int main()
{
 int n,i,w;
 printf("how many types of coins: ");
 scanf("%d",&n);
 int wt[n];
 printf("enter the type of coins:\n");
 for(i=0;i<n;i++)
 {
  scanf("%d",&wt[i]);
 }
 printf("enter the rupees:");
 scanf("%d",&w);
 printf("minimum no.of coins:%d",cc(n,w,wt));
 }
 
 
 
