#include <stdio.h>
#include <limits.h>
int static a[100][1000];
// Recursive function to find the minimum number of multiplications
int mcm(int p[], int i, int j) 
{
	if(a[i][j]!=-1)
	return a[i][j];
    if (i == j)
        return  a[i][j]=p[i];
        if(j<i)
        return 0;

    int min = INT_MAX;
    //int fsum=sum(p,i,j);
    for (int k = i; k < j; k++) {
        int count = mcm(p, i, k) + 
                    mcm(p, k + 1, j) + 
                    p[i-1]*p[k]*p[j];

        if (count < min)
            min = count;
    }

    return min;
}

int main() {
    int n;

    printf("Enter the size ");
    scanf("%d", &n);

        int  rows[n],col[n];
    
    for(int i=0;i<n;i++)
    
    {
    	printf ("enter the rows %d  and columns %d",i,i);
    	scanf("%d%d",&rows[i],&col[i]);
    }
    

    int arr[n + 1];
    arr[0] = rows[0];
    for (int i = 1; i <= n; i++) {
        arr[i] = col[i - 1];
    }
    for(int i=0;i<=n;i++)
    {
    	for(int j=0;j<=n;j++)
    	{
    	a[i][j]=-1;
    	}
    }

    printf("Minimum number of multiplications is %d\n", mcm(arr, 1, n));

    return 0;
}

