#include<stdio.h>
int steps(int n);
int steps(int n)
{
    int a[n];
for(int i=0;i<=n;i++)
{
if(i==1)
{
a[i]=1;
}
else if(i==2)
{
a[i]=2;
}
else
{
a[i]= a[i-1]+a[i-2];
}
}
printf("total no.of ways:%d",a[n]);
}
void main()
{
int n;
printf("enter number of steps:");
scanf("%d",&n);
steps(n);
}