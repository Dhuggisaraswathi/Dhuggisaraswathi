#include<stdio.h>
int fib(int);
int main()
{
int i,n;
printf("enter the n value\n");
scanf("%d",&n);
for(i=0;i<n;i++)
{
printf("%d",fib(i));
}
}
int fib(int n)
{
int i;
int a[n];
for(i=0;i<=n;i++)
{
a[i]=-1;
}
if(a[n]!=-1)
{
return a[n];
}
else {
if(n==0)
return a[n]=0;
else if(n==1)
return a[n]=1;
else
return a[n]=fib(n-1)+fib(n-2);
}
}
