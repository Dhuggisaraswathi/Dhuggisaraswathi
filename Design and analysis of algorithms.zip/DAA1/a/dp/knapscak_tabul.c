#include<stdio.h>
int max(int a, int b) {
    return (a > b) ? a : b;
}
int knapsack_tabulation(int capacity, int weights[], int values[], int n) {
    int i, w;
    int K[n + 1][capacity + 1];
    for (i = 0; i <= n; i++) {
        for (w = 0; w <= capacity; w++) {
            if (i == 0 || w == 0)
                K[i][w] = 0;
            else if (weights[i - 1] <= w)
                K[i][w] = max(values[i - 1] + K[i - 1][w - weights[i - 1]], K[i - 1][w]);
            else
                K[i][w] = K[i - 1][w];
        }
    }
    return K[n][capacity];
}
int main() {
    int weights[100], values[100];
    int capacity, n, i;
    printf("Enter the number of items: ");
    scanf("%d", &n);
    printf("Enter the weights of items:\n");
    for (i = 0; i < n; i++)
    scanf("%d", &weights[i]);
    printf("Enter the values of items:\n");
    for (i = 0; i < n; i++)
    scanf("%d", &values[i]);
    printf("Enter the capacity of knapsack: ");
    scanf("%d", &capacity);
    printf("Maximum value: %d\n", knapsack_tabulation(capacity, weights, values, n));
    return 0;
}

