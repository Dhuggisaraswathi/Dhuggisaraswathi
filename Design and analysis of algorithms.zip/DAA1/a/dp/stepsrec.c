#include<stdio.h>
int steps(int n);
int steps(int n)
{

if(n==0)
{
return 0;
}
else if(n==1)
{
return 1;
}
else if(n==2)
{
return 2;
}
else
{
return steps(n-1)+steps(n-2);
}
}
void main()
{
int n;
printf("enter number of steps:");
scanf("%d",&n);
int a[n];
for(int i=0;i<=n;i++)
{
steps(i);
}
printf("total no.of possible steps are:%d ",steps(n));
}