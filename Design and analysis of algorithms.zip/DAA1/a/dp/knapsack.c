#include<stdio.h>
int max(int a,int b)
{
return (a>b?a:b);
}
int ks(int n,int w,int val[],int wt[])
{
int i,max=0,a,b;
for(i=0;i<n;i++)
{
if(n==0||w==0)
{
return 0;
}
else if(wt[n-1]<=w)
{
a=val[n-1]+ks((n-1),w-wt[n-1],val,wt);
b=ks(n-1,w,val,wt);
if(a>b)
{
max=a;
}
else{
max=b;
}
return max;
}
//return (a<b?a:b);
//}
else
{
return ks(n-1,w,val,wt);
}
}
}
int main()
{
int n,w,i;
printf("enter the no.of ways & weight of bag");
scanf("%d%d",&n,&w);
int v[n],wt[n];
printf("enter the value of all items& weights");
for(i=0;i<n;i++)
{
scanf("%d",&v[i]);
}
for(i=0;i<n;i++)
{
scanf("%d",&wt[i]);
}
printf("%d",ks(n,w,v,wt));
}



