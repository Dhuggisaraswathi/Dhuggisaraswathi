#include<stdio.h>

int fib(int n)
{
  int a[n+1];
  int i;
  for(i=0;i<=n;i++)
  {
   if(i==0)
   {
  a[i]=0;
  continue;
  }
  else if(i==1)
  {
   a[i]=1;
   continue;
   }
  else
  {
    a[i]=a[i-1]+a[i-2];
    continue;
  }
  }
  return a[n];
}

int main()
{
 int n;
 printf("enter n value");
 scanf("%d",&n);
 
 for(int i=0;i<n;i++)
 {
  printf("%d",fib(i));
 }}
