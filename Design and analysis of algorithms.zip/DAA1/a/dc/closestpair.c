#include <stdio.h>
#include <stdlib.h>
#include <math.h>
typedef struct {
int x;
int y;
} Point;
double euclidean_distance(Point p1, Point p2) {
return sqrt(pow(p1.x - p2.x, 2) + pow(p1.y - p2.y, 2));
}
void closest_pair(Point points[], int n) {
if (n < 2) {
printf("At least 2 points are required.\n");
return;
}
double min_distance = INFINITY;
Point closest_pair[2];
for (int i = 0; i < n; i++) {
for (int j = i + 1; j < n; j++) {
double distance = euclidean_distance(points[i], points[j]);
if (distance < min_distance) {
min_distance = distance;
closest_pair[0] = points[i];
closest_pair[1] = points[j];
}}}
printf("Closest pair:(%d, %d)and(%d, %d)\n",closest_pair[0].x, closest_pair[0].y,closest_pair[1].x,closest_pair[1].y);
printf("Distance: %f\n", min_distance);
}
int main() {
int n;
printf("Enter the number of points: ");
scanf("%d", &n);
if (n < 2) {
printf("At least 2 points are required.\n");
return 1;
}
Point *points = (Point*)malloc(n * sizeof(Point));
printf("Enter the coordinates of each point (x, y):\n");
for (int i = 0; i < n; i++) {
scanf("%d %d", &points[i].x, &points[i].y);
}
closest_pair(points, n);
free(points);
return 0;
}

