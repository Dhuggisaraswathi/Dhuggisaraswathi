#include <stdio.h>

int fibonacci_memo(int n, int m[]) {
    if (n <= 1)
        return n;
    if (m[n] != -1)
        return m[n];
    m[n] = fibonacci_memo(n - 1, m) + fibonacci_memo(n - 2, m);
    return m[n];
}

int main() {
    int n;
    printf("Enter a number: ");
    scanf("%d", &n);
    
    int m[n+1];
    for (int i = 0; i <= n; i++) {
        m[i] = -1;
    }
    
    printf("Fibonacci number is: %d\n", fibonacci_memo(n, m));
    return 0;
}

