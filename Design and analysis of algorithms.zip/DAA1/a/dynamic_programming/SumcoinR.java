import java.util.*;
import java.math.*;
//import java.bool.*;

class sum
{
int n;
int w;
int[] val;
int[] wt;
int[][] a;
Scanner in=new Scanner(System.in);
public  sum(int  n,int w)
{
this.n=n; 
this.w=w;
val=new int[n];
wt=new int[n];
a=new int[n+1][w+1];
System.out.println("enter the weight ");
for(int i=0;i<n;i++)
{
wt[i]=in.nextInt();
}
}

boolean ss(int n,int s)
{
if(s==0)
return true;
if(n==0)
return false;
if(wt[n-1]<=s)
return ss(n-1,s-wt[n-1]);
else
return ss(n-1,s);
}
}
class   SumcoinR
{

public static void main(String agrs[])
{
Scanner in= new Scanner(System.in);
System.out.println("enter the n0 of items :  ");
int n=in.nextInt();
System.out.println("enter the weight of bag:   ");
int w=in.nextInt();
sumR k1=new sumR(n,w);
if(k1.ss(n,w)==1)
{
System.out.println("true");

}
else
{
System.out.println("false");
}
}
}

