import java.util.*;
import java.io.*;
INT_MAX 100;

class Mcm
{
int i,j;
int a[];
int n;
Scanner s=new Scanner(System.in);
public void sam(int i,int n)
{
this.n=n;
this.i=i;
a=new int[n];
System.out.println("enter array size");
n=s.nextInt();
System.out.println("enter elements");
for(i=0;i<n;i++)
{ a[i]=s.nextInt();
}
for(i=0;i<n;i++)
{
a[i]=-1;
}
}

public void mcm(int i,int j)
{
if(i==j)
return ;

int min=MAX_VAL;
for(int k=i;k<j;k++)
{
int val=mcm(i,k)+mcm(k+1,j)+a[i-1]*a[k]*a[j];
if(val<min)
{
min=val;
}
}
return min;
}
}
class main
{
public static void main(String... arg)
{
Scanner in=new Scanner(System.in);
System.out.println("enter the size ");
int n,i;
n=in.nextInt();
int a[]=new int[n];
System.ot.println("enter elements");
for(int i=0;i<n;i++)
{
a[i]=in.nextInt();

} 
Mcm m=new Mcm(n,i);
System.out.println(m.mcm(n,i));
}
}



