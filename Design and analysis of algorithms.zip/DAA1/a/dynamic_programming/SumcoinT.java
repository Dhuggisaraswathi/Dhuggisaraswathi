import java.util.*;
import java.math.*;
class sum
{
int n;
int w;
int[] val;
int[] wt;
int[][] a;
Scanner in=new Scanner(System.in);
public sum(int  n,int w)
{
this.n=n;
this.w=w;
val=new int[n];
wt=new int[n];
a=new int[n+1][w+1];
System.out.println("enter the weight ");
for(int i=0;i<n;i++)
{
wt[i]=in.nextInt();
}
}
boolean ss(int n,int s)
{
int i,j;
for(i=0;i<=n;i++)
{
for(j=0;j<=s;j++)
{
if(j==0){
a[i][j]=true;
continue;}
if(i==0){
a[i][j]=false;
continue;}
if(wt[i-1]<=j){
a[i][j]=a[i-1][j-wt[i-1]]+a[i-1][j];}
else{
a[i][j]=a[i-1][j];}
}
}
}
}
class   SumTable
{

public static void main(String agrs[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the n0 of items :  ");
int n=in.nextInt();
System.out.println("enter the weight of bag:   ");
int w=in.nextInt();
sumR k1=new sumR(n,w);
System.out.println(k1.ss(n,w));
}
}

