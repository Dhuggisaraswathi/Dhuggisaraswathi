#include <stdio.h>
#include <stdlib.h>
#include <limits.h>

// Function to find the minimum number of multiplications using memoization
int matrixChainMemoized(int p[], int i, int j, int **m) {
    if (i == j)
        return 0;

    if (m[i][j] != -1)
        return m[i][j];

    m[i][j] = INT_MAX;
    for (int k = i; k < j; k++) {
        int count = matrixChainMemoized(p, i, k, m) + 
                    matrixChainMemoized(p, k + 1, j, m) + 
                    p[i - 1] * p[k] * p[j];

        if (count < m[i][j])
            m[i][j] = count;
    }

    return m[i][j];
}

int main() {
    int n;

    printf("Enter the number of matrices: ");
    scanf("%d", &n);

    int rows[n], cols[n];
    printf("Enter the dimensions of the matrices (rows and columns):\n");
    for (int i = 0; i < n; i++) {
        printf("Matrix %d rows: ", i + 1);
        scanf("%d", &rows[i]);
        printf("Matrix %d columns: ", i + 1);
        scanf("%d", &cols[i]);
    }

    int arr[n + 1];
    arr[0] = rows[0];
    for (int i = 1; i <= n; i++) {
        arr[i] = cols[i - 1];
    }

    int **m = (int **)malloc((n + 1) * sizeof(int *));
    for (int i = 0; i <= n; i++) {
        m[i] = (int *)malloc((n + 1) * sizeof(int));
        for (int j = 0; j <= n; j++)
            m[i][j] = -1;
    }

    printf("Minimum number of multiplications is %d\n", matrixChainMemoized(arr, 1, n, m));

    for (int i = 0; i <= n; i++)
        free(m[i]);
    free(m);

    return 0;
}

