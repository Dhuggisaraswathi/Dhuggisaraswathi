import java.util.*;
import java.math.*;
class sum
{
int n;
int w;
int[] val;
int[] wt;
int[][] a;
Scanner in=new Scanner(System.in);
public sum(int  n,int w)
{
this.n=n;
this.w=w;
val=new int[n];
wt=new int[n];
a=new int[n+1][w+1];
System.out.println("enter the weight ");
for(int i=0;i<n;i++)
{
wt[i]=in.nextInt();
}
}
int ss(int n,int s)
{
if(a[n][s]!=-1)
return a[n][s];
if(s==0)
return a[n][s]=1;
if(n==0)
return a[n][s]=0;
if(wt[n-1]<=s)
return a[n][s]=ss(n-1,s-wt[n-1]+ss(n-1,s));
else
return a[n][s]=ss(n-1,s);
}
}
class   Summem
{

public static void main(String agrs[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the n0 of items :  ");
int n=in.nextInt();
System.out.println("enter the weight of bag:   ");
int w=in.nextInt();
sumR k1=new sumR(n,w);
System.out.println(k1.ss(n,w));
}
}

