import java.util.*;
import java.math.*;
class kavya
{
int n;
int s;
int a[];
Scanner in=new Scanner(System.in);
kavya(int n,int s)
{
this.n=n;
this.s=s;
a=new int[n];
System.out.println("enter the array ");
for(int i=0;i<n;i++)
{
a[i]=in.nextInt();
}
}
int  sum(int n,int s)
{
if(s==0)
return 1;
if(n==0)
return 0;
if(a[n-1]<=s)
{
return sum(n,s-a[n-1])+sum(n-1,s);
}
else
return sum(n-1,s);
}
}
class subset_ways_recc
{
public static void main(String args[])
{
int n,s;
Scanner in=new Scanner(System.in);
System.out.println("enter  the n and sum value");
n=in.nextInt();
s=in.nextInt();
kavya k1=new kavya(n,s);
System.out.println(k1.sum(n,s));
}
}

