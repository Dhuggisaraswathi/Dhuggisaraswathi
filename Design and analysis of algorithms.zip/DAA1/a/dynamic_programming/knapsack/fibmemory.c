#include<stdio.h>
#include<stdlib.h>

int main()
{
int n,i;
printf("enter size");
scanf("%d",&n);
int a[n];
int fib(int n)
{
if(a[n]!=-1)
{
return a[n];
}
if(n==0||n==1)
{
return a[n]=1;
}
else
{
return a[n]=fib(n-1)+fib(n-2);
}
}
int k=fib(n);
{
printf("%u  \n",k);
}


}

