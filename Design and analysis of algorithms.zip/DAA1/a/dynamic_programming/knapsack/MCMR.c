#include <stdio.h>
#include <limits.h>

// Recursive function to find the minimum number of multiplications
int mcm(int p[], int i, int j) {
    if (i == j)
        return 0;

    int min = INT_MAX;
    for (int k = i; k < j; k++) {
        int val = mcm(p, i, k)+mcm(p, k + 1, j)+p[i - 1] * p[k] * p[j];
                    
            if (val < min)
            min = val;
            }
            return min;
}
int main() 
{
    int n;

    printf("Enter the number of matrices: ");
    scanf("%d", &n);

    int rows[n], cols[n];
    printf("Enter the dimensions of the matrices (rows and columns):\n");
    for (int i = 0; i < n; i++) {
        printf("Matrix %d rows: ", i + 1);
        scanf("%d", &rows[i]);
        printf("Matrix %d columns: ", i + 1);
        scanf("%d", &cols[i]);
    }

    int arr[n + 1];
    arr[0] = rows[0];
    for (int i = 1; i <= n; i++) {
        arr[i] = cols[i - 1];
    }

    printf("Minimum number of multiplications is %d\n", mcm(arr, 1, n));

    return 0;
}

