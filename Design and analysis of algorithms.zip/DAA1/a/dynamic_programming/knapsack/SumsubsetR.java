import java.util.*;
import java.math.*;
class sumR
{
int n;
int w;
int[] val;
int[] wt;
int[][] a;
Scanner in=new Scanner(System.in);
public sumR(int  n,int w)
{
this.n=n;
this.w=w;
val=new int[n];
wt=new int[n];
a=new int[n][w];
System.out.println("enter the weights ");
for(int i=0;i<n;i++)
{
wt[i]=in.nextInt();
}
}
int ss(int n,int s)
{
if(s==0)
return 1;
if(n==0)
return 0;
if(wt[n-1]<=s)
return ss(n-1,s-wt[n-1]+ss(n-1,s));
else
return ss(n-1,s);
}
}

class   SumsubsetR
{

public static void main(String agrs[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the n0 of items :  ");
int n=in.nextInt();
System.out.println("enter the weight of bag:   ");
int w=in.nextInt();
sumR k1=new sumR(n,w);
System.out.println(k1.ss(n,w));
}
}

