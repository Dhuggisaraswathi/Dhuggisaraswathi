import java.util.*;
import java.io.*;
class mem
{
int n;
int w;
int wt[];
int[][] a;
int[] val;
Scanner in=new Scanner(System.in);
public mem(int  n,int w)
{
this.n=n;
this.w=w;
val=new int[n];
wt=new int[n];
a=new int[n+1][w+1];
System.out.println("enter the weight ");
for(int i=0;i<n;i++)
{
wt[i]=in.nextInt();
}
System.out.println("enter the values ");
for(int i=0;i<n;i++)
{

val[i]=in.nextInt();
}
for(int i=0;i<=n;i++)
{
for(int j=0;j<=w;j++)
{
a[i][j]=-1;
}
}
}
int ks(int n,int w)
{
if(a[n][w]!=-1)
{
return a[n][w];
}
if(n==0||w==0)
{
return a[n][w]=0;
}
else if(wt[n-1]<=w)
{
return a[n][w]=Math.max(val[n-1]+ks(n-1,w-wt[n-1]),ks(n-1,w));
}
else
{
return a[n][w]=ks(n-1,w);
}
}
}

class knapmem
{
public static void main(String agrs[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the n0 of items  and weight of bag ");
int n=in.nextInt();
int w=in.nextInt();
mem k1=new mem(n,w);
System.out.println(k1.ks(n,w));
}
}

