#include<stdio.h>
int main()
{
int n,i;
printf("enter size");
scanf("%d",&n);
int a[n];
printf("enter elements");
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
int fib( int n)
{
for(i=0;i<n;i++)
{
if(i==0||i==1)
{
a[i]=1;
}
else
{
a[i]=a[i-1]+a[i-2];
}
}
}
printf("%d  \n",fib(n));
}
