import java.util.*;
import java.io.*;
class table
{
int n;
int w;
int wt[];
int[][] a;
int[] val;
Scanner in=new Scanner(System.in);
public table(int  n,int w)
{
this.n=n;
this.w=w;
val=new int[n];
wt=new int[n];
a=new int[n+1][w+1];
System.out.println("enter the weight ");
for(int i=0;i<n;i++)
{
wt[i]=in.nextInt();
}
System.out.println("enter the values ");
for(int i=0;i<n;i++)
{

val[i]=in.nextInt();
}
for(int i=0;i<=n;i++)
{
for(int j=0;j<=w;j++)
{
a[i][j]=0;
}
}
}
int ks(int n,int w)
{
for(int i=1;i<=n;i++)
{
for(int j=1;j<=w;j++)
{
if(i==1||j==1){
 a[i][j]=0;}
if(wt[i-1]<=j){
 a[i][j]=Math.max(val[i-1]+a[i-1][j-wt[i-1]],a[i-1][j]);}
else{
a[i][j]=(a[i-1][j]);}


}
}
return a[n][w];
}

}
class  knapTable
{

public static void main(String agrs[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the n0 of items  and weight of bag ");
int n=in.nextInt();
int w=in.nextInt();
table k1=new table(n,w);
System.out.println(k1.ks(n,w));
}
}

