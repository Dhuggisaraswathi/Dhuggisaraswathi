import java.util.*;
import java.io.*;
INT_MAX 100;
class obst
{int i,j;
int[] f;
int k;
Scanner sc=new Scanner(System.in);

public obst(int i,int j)
{
this.i=i;
this.j=j;
 f=new int[i];
 for(k=0;k<j;k++)
 {
 f[i]=sc.nextInt();
 }
 }
 
 int obst(int j,int i)
 {
 int val;
 int min=MAX_VAL;
 if(i==j)
 {
 return f[i];
 
 }
 for(k=0;k<j;k++)
 {
 val=obst(i,k-1)+obst(k+1,j)+sum(f,i,j);
 if(val<min)
 {
 min=val;}
 }
 
 //return f[i];
 }
 int sum(int f[],int i,int j)
 {
 int s=0;
 for(int k=0;k<=j;k++)
 {s=s+f[k];
 }
 return s;
 }
 }
 
 
 class main
 {
 public static void main(String[] arg)
 {
 int n,i;
 System.out .println("enter size");
 Scanner s=new Scanner(System.in);
 n=s.nextInt();
 int a=new int[n];
 System.out.println("enter elements");
 for(i=0;i<n;i++)
 {
 
 a[i]=s.nextInt();
 }
 obst(n,i);
 }
 }
 
