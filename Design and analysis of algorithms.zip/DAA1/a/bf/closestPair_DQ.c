#include<stdio.h>
#include<math.h>
#include<limits.h>
struct point {
  int x;
  int  y;
 };
 int cp(struct point [],int,int);
 int bruteforce(struct point[],int,int);
 void swap(int *,int*);
void quick_sort(struct point p[],int st,int end){
int i=st,j=end,pivot=st;
      while(i<j){
      while(p[i].x<=p[pivot].x ){
         i++;
      }
      while(p[j].x>p[pivot].x ){
        j--;
      }
      if(i<j){
        swap(&p[i].x,&p[j].x);
      }
      else{
      swap(&p[j].x,&p[pivot].x);
      }
   quick_sort(p,st,j-1);
  quick_sort(p,i,end);
 }
 }
 int cp(struct point p[],int st,int end){
   int mid;
     if(end-st>=2){
         mid=(st+end)/2;
        int ld=cp(p,st,mid);
        int rd=cp(p,mid+1,end);
        int d=ld>rd?rd:ld;
        return d;
      }
      else{
      int res=bruteforce(p,0,mid);
      return res;
      }
 }
 int bruteforce(struct point p[],int st,int end){
 int min=INT_MAX;
    for(int i=0;i<end-1;i++){
       for(int j=i+1;j<end;j++){
        int d=sqrt(pow((p[j].x-p[i].x),2)+pow((p[j].y-p[i].y),2));
        if(d<min){
          min=d;
        }
      }
   }
   return min;
 }
void main(){
  int n;
  printf("Enter size");
  scanf("%d",&n);
  
  struct point p[n];
  printf("Enter points");
  for(int i=0;i<n;i++){
      scanf("%d%d",&p[i].x,&p[i].y);
 }
 quick_sort(p,0,n-1);
 for(int i=0;i<5;i++){
    printf("%d\t",p[i].x);
  }
  int r=cp(p,0,n-1);
  printf("%d",r);
}
 void swap(int *a,int *b){
    int temp=*a;
    *a=*b;
    *b=temp;
 }
  
 
 
