//convexhull
#include<stdio.h>
#include<math.h>
struct point
{
    int x,y;
};
int main()
{
    int n,i,j,k,nn,np,a,b,c,count=0,x1,x2,y1,y2;
    printf("enter the no.of points");
    scanf("%d",&n);
    struct point p[n];
    for(i=0;i<n;i++)
    {
        scanf("%d%d",&p[i].x,&p[i].y);
    }
    for(i=0;i<n;i++)
    {
        for(j=i+1;j<n;j++)
        {
            x1=p[i].x;
            x2=p[j].x;
            y1=p[i].y;
            y2=p[j].y;
            a=y2-y1;
            b=x1-x2;
            c=x1*y2-x2*y1;
            np=0;
            nn=0;
            for(k=0;k<n;k++)
            {
                int val=a*p[k].x+b*p[k].y-c;
                if(val>0)
                {
                    np++;
                }
                else if(val<0)
                {
                    nn++;
                }
            }
            if(np==0||nn==0)
            {
                count++;
                printf("(%d,%d),(%d,%d)\n",p[i].x,p[i].y,p[j].x,p[j].y);
               
            }  
        }
    }
    printf("total no.of edges are:%d",count);
    
   
}
