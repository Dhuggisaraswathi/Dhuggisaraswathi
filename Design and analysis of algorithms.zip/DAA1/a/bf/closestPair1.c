#include<stdio.h>
#include<math.h>
#include<limits.h>
void main(){
struct point{
  int x;
  int y;
};
int n;
int index1,index2;
printf("Enter no.of points");
scanf("%d",&n);
struct point p[n];
for(int i=0;i<n;i++){
   scanf("%d%d",&p[i].x,&p[i].y);
 }
int min=INT_MAX;
for(int i=0;i<n-1;i++){
for(int j=i+1;j<n;j++){
   int d=sqrt(pow((p[i].x-p[j].x),2)+(pow((p[i].y-p[j].y),2)));
   printf("%d\t%d\t%d\t%d\t",p[i].x,p[i].y,p[j].x,p[j].y);
   printf("\t%d",d);
   printf("\n");
   if(min>d){
     min=d;
    index1=i;
    index2=j;
  }
  }
  }
  printf(" Minimum distance is %d\n",min);
  printf("%d\t%d\t",p[index1].x,p[index1].y);
  printf("%d\t%d\t",p[index2].x,p[index2].y);
  /*for(int i=0;i<n-1;i++){
for(int j=0;j<n-2;j++){
   int d=sqrt((p[i].x-p[j].x)^2+(p[i].y-p[j].y)^2);
   if(d==min)
       printf("%d\t%d",p[i].x,p[i].y);
  }
  }*/
  }


