//no.of edges
/*#include<stdio.h>
struct point
{
 int x,y;
};

int main()
{
   struct point p[10];
   int n;
   printf("enter n value");
   scanf("%d",&n);
   int count=0;
   int nn,np,k,i,j,val;
   for(i=0;i<n;i++)
   {
    scanf("%d%d",&p[i].x,&p[i].y);
   }
   
   for(i=0;i<n-1;i++)
   {
    for(j=i+1;j<n;j++)
    {
      int a=p[i].y-p[j].y;
        int b=p[j].x-p[i].x;
        int c=(p[j].x*p[i].y)-(p[i].x*p[j].y);
        np=0;
        nn=0;
        for(k=0;k<n;k++)
        {
          val=a*p[k].x+b*p[k].y-c;
          if(val>0)
          {
           np++;
          }
          else if(val<0)
          {
           nn++;
          }
        }
        if(np==0||nn==0)
        {
         count++;
       }
       
    }}
    printf("%d",count);
 } 
*/
//no.of points
/*#include<stdio.h>
struct point
{
 int x,y;
};
      
int main()
{
   struct point p[10];
   int n;
   printf("enter n value");
   scanf("%d",&n);
   int count=0;
   int nn,np,k,i,j,val;
   for(i=0;i<n;i++)
   {
    scanf("%d%d",&p[i].x,&p[i].y);
   }
   
   for(i=0;i<n-1;i++)
   {
    for(j=i+1;j<n;j++)
    {
      int a=p[i].y-p[j].y;
        int b=p[j].x-p[i].x;
        int c=(p[j].x*p[i].y)-(p[i].x*p[j].y);
        np=0;
        nn=0;
        for(k=0;k<n;k++)
        {
          val=a*p[k].x+b*p[k].y-c;
          if(val>0)
          {
           np++;
          }
          else if(val<0)
          {
           nn++;
          }
          else
          {
           count++;
          }
    }}}
    printf("%d",count);
  }*/
  //for each point
   #include<stdio.h>
 struct point
 {
  int x,y;
 };
 
 int main()
 {
   struct point p[10];
   int n,val;
   printf("enetr n value");
   scanf("%d",&n);
   int np,nn,i,j,k;
   for(i=0;i<n;i++)
   {
     scanf("%d%d",&p[i].x,&p[i].y);
   }
   
   for(i=0;i<n-1;i++)
   {
      for(j=i+1;j<n;j++)
      {
        int a=p[i].y-p[j].y;
        int b=p[j].x-p[i].x;
        int c=(p[j].x*p[i].y)-(p[i].x*p[j].y);
        np=0;
        nn=0;
        for(k=0;k<n;k++)
        {
          val=a*p[k].x+b*p[k].y-c;
          if(val>0)
          {
           np++;
          }
          else if(val<0)
          {
           nn++;
          }
        }
    printf("the convex hull points are:\n%d %d\n%d %d\n%d\n",p[i].x,p[i].y,p[j].x,p[j].y,val);
}}}
