#include<stdio.h>
#include<math.h>
#include<limits.h>
void main(){
struct point{
  int x;
  int y;
};
int n;
int index1,index2;
int min=INT_MAX;
printf("Enter no.of points");
scanf("%d",&n);
struct point p[n];
for(int i=0;i<n;i++){
   scanf("%d%d",&p[i].x,&p[i].y);
 }
 int sum=0,count=0;
for(int i=0;i<n;i++){
for(int j=i+1;j<n;j++){
   int d=sqrt(pow((p[i].x-p[j].x),2)+(pow((p[i].y-p[j].y),2)));
   sum+=d;
   count++;
   printf("\n");
  }
    printf("Average distance of %d\t%d\t is %d\n",p[i].x,p[i].y,(sum/count));
  int avg=(sum/count);
  if(min>avg){
  min=avg;
  index1=i;
  }
  }
printf("Min =%d\n",min);
  printf("%d\t%d",p[index1].x,p[index1].y);
  }
