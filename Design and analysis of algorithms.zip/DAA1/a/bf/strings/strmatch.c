#include<stdio.h>//checking whether the substring is present or not in main string
#include<string.h>
void main()
{
 char m[50],s[50];
 printf("enter the main string and sub string\n");
 gets(m);
 gets(s);
 int i,f,j,f1=0,c=0;
 for(i=0;i<=(strlen(m)-strlen(s));i++)
 {   
  if(s[0]==m[i]) //to find the matched character
  { 
   f=0;
    for(j=0;j<strlen(s);j++)
     { 
     if(s[j]!=m[j+i]) //to check the substring in main string
      {
        f=1;
       break;
      }
     }
   if(f==0)
   {
     printf("match is  found at %d\n",i);
      f1=1;
    }
  }
}
if(f1==0)
 printf("match is not found");
}
