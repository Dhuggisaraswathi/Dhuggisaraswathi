#include<stdio.h>//checking whether the reverse of substring present or not in main string
#include<string.h>
int main()
{
char a[100];
char b[100];
printf("enter the str ");
scanf("%s",a);
printf("enter the sub str ");
scanf("%s",b);
int m=strlen(a);
int n=strlen(b);
char r[100];
 int i,f,j,t=0,f1=0;
 int l=strlen(b);
for(i=l-1;i>=0;i--)
{
 r[t++]=b[i];
}
for(i=0;i<strlen(r);i++)
{
 printf("%c\n",r[i]);
 }
 for(i=0;i<=(strlen(a)-strlen(r));i++)
 {   
  if(r[0]==a[i])
  { 
   f=0;
  for(j=0;j<strlen(r);j++)
  { 
  if(r[j]!=a[j+i])
  {
   f=1;
   break;
   }
  }
 if(f==1)
 {
 printf("match is  found at %d\n",i);
 f1=1;
 }
}
}
if(f1==0)
 printf("match is not found");
}
