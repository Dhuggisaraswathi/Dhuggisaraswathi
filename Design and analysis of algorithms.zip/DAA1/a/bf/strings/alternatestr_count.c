#include<stdio.h>
#include<string.h>
void main()
{
/* char m[50],s[50];
 printf("enter the main string and sub string\n");
 fgets(m);
 fgets(s);
 //scanf("%s %s",*/
 char  str1[100] ;
      printf("enter text");
      fgets(str1,sizeof(str1),stdin);

      char str2[100];
       printf("enter  matching text");
      fgets(str2,sizeof(str2),stdin);

      int m=strlen(str1); 
      int n=strlen(str2);
 int i,f,j,c=0;
 for(i=0;i<(m-n);i++)
 {   
  if(str1[0]==str2[i])
  {  
   f=0;
  for(j=0;j<(n);j++)
  { 
  if(str1[j]!=str2[i+j*2])
  {
   f=1;
   break;
   }
  }
 if(f==0)
 {
 c++;
 }
}
}
printf("alternate str count=%d\n",c);
}
