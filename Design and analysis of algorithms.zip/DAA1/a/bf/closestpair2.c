#include<stdio.h>
#include<math.h>
#include<limits.h>
void main(){
struct point{
  int x;
  int y;
};
int n;
int index1,index2;
printf("Enter no.of points");
scanf("%d",&n);
struct point p[n];
for(int i=0;i<n;i++){
   scanf("%d%d",&p[i].x,&p[i].y);
 }
int max=INT_MIN;
for(int i=0;i<n-1;i++){
for(int j=i+1;j<n;j++){
   int d=sqrt(pow((p[i].x-p[j].x),2)+(pow((p[i].y-p[j].y),2)));
   printf("(%d\t%d)(%d\t%d)",p[i].x,p[i].y,p[j].x,p[j].y);
   printf("\t%d",d);
   printf("\n");
   if(max<d){
     max=d;
    index1=i;
    index2=j;
  }
  }
  }
  printf(" Maximum distance is %d\n",max);
  printf("%d\t%d\t",p[index1].x,p[index1].y);
  printf("%d\t%d\t",p[index2].x,p[index2].y);
 }
