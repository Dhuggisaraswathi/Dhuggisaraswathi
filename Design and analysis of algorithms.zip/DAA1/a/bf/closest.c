//closest pair
#include<stdio.h>
#include<math.h>
struct points
{
int x,y;
};
void main()
{
int d,x1,x2,y1,y2;
int n;
printf("enter the number of points:");
scanf("%d",&n);
struct points p[n];
if(n>=2)
{
for(int i=0;i<n;i++)
{
scanf("%d%d",&p[i].x,&p[i].y);
}
int dmin=99999;
for(int i=0;i<n-1;i++)
{
for(int j=i+1;j<n;j++)
{
d=sqrt(pow(p[i].x-p[j].x,2)+pow(p[i].y-p[j].y,2));
{
x1=p[i].x;
x2=p[j].x;
y1=p[i].y;
y2=p[j].y;
dmin=d;
}
}
}
printf("the closest points are (%d,%d) and (%d,%d): the distance between two points are %d",x1,y1,x2,y2,dmin);
}
else
{
printf("enter atleast two points");
}
}
