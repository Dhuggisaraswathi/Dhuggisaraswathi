#include<stdio.h>
#include<limits.h>
#include<math.h>
//closest pair
struct point {
    int x, y;
};
//to find min distance
float min(float a, float b)
 {
 return (a < b) ? a : b;
}
//to find distance bt 2 points
float bruetforce(struct point p[], int n) {
    float min_dist = INT_MAX;
    int i, j;
    for (i = 0; i < n - 1; i++) {
        for (j = i + 1; j < n; j++) {
            float val = sqrt((p[j].x - p[i].x) * (p[j].x - p[i].x) + (p[j].y - p[i].y) * (p[j].y - p[i].y));
            if (min_dist > val) {
                min_dist = val;
            }
        }
    }
    return min_dist;
}
//2 or 3 points ,then use brute force to find closest distance
float cp(struct point p[], int n) {
    int mid, k = 0, i;
    float dl, dr, l, db;
    struct point strip[10];
    if (n <= 3) {
        bruetforce(p, n);
    }
    else {
        mid = n / 2;

        dl = cp(p, mid);//sort left side points
        dr = cp(p + mid, n - mid);//right side points 

        l = min(dl, dr); //indexes of left and right subarrays

        for (i = 0; i < n; i++) {
            if (p[i].x - p[mid].x < l) {
                strip[k++] = p[i];
            }
        }
        db = bruetforce(strip, k);//the smaller of two distances
        return min(l, db);//return minimum of distance and distance of strip

    }
}

void quicksort(struct point p[], int low, int high) {
    if (low < high) {
        int pivot = p[low].x;
        int i = low;
        int j = high;
        while (i < j) {
            while (i < j && (p[i].x < pivot || (p[i].x == pivot && p[i].y <= p[j].y)))
                i++;
            while (p[j].x > pivot || (p[j].x == pivot && p[j].y > p[low].y))
                j--;
            if (i < j) {
                struct point temp = p[i];
                p[i] = p[j];
                p[j] = temp;
            }
        }
        struct point temp = p[low];
        p[low] = p[j];
        p[j] = temp;
        quicksort(p, low, j - 1);
        quicksort(p, j + 1, high);
    }
}

int main() {
    int n, i;
    printf("Enter the number of points:\n");
    scanf("%d", &n);
    struct point p[n];
    printf("Enter the points:\n");
    for (i = 0; i < n; i++) {
        scanf("%d %d", &p[i].x, &p[i].y);
    }

    quicksort(p, 0, n - 1);
    float k = cp(p, n);
    printf("Minimum distance is %.4f\n", k);

    return 0;
}

