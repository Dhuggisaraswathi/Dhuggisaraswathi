#include<stdio.h>
int main()
{
int i,j,k,n,temp,f=0;

printf("enter array size:");
scanf("%d",&n);
int a[n];
printf("enter the elements:");
for(i=0;i<n;i++)
{
scanf("%d",&a[i]);
}
for(i=0;i<n;i++)
{
for(j=i+1;j<n;j++)
{
if(a[i]>a[j])
{
temp=a[i];
a[i]=a[j];
a[j]=temp;
}
printf("after sorting\n");
for(i=0;i<n;i++)
{
printf("%d\n",a[i]);
}
}
}
printf("enter the key :");
scanf("%d",&k);
int low,high=n-1,mid;
for(i=0;i<n;i++)
{
while(low<=high)
{
mid=(low+high)/2;
}

if(k==a[i])
{
printf("element is found at %d position\n",mid);
f=1;
break;
}
}
if(k>a[mid])
{
low=mid+1;
}
else
{
high=mid-1;
printf("element not found");
}
}

