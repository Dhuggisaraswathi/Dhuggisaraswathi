import java.util.*;
import java.math.*;
class kavya
{
int n;
int w;
int[] val;
int[] wt; 
Scanner in=new Scanner(System.in);
public kavya(int n,int w)
{
this.n=n;
this.w=w;
wt=new int[n];
val=new int[n];
System.out.println("enter the weight ");
for(int i=0;i<n;i++)
{
wt[i]=in.nextInt();
}
System.out.println("enter the values ");
for(int i=0;i<n;i++)
{
val[i]=in.nextInt();
}
}
int ks(int n,int w)
{
if(n==0||w==0)
return 0;
if(wt[n-1]<=w)
return Math.max(val[n-1]+ks(n-1,w-wt[n-1]),ks(n-1,w));
else
return ks(n-1,w);
}
}
class knapsack_recurrsive
{
public static void main(String agrs[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the n0 of items  and weight of bag ");
int n=in.nextInt();
int w=in.nextInt();
kavya k1=new kavya(n,w);
System.out.println(k1.ks(n,w));
}
}

