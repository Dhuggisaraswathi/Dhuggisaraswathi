#include<stdio.h>
#include<string.h>
void main()
{
int flag=0;
int c=0;
//int p=0;
char a[100];
char b[100];
printf("enter the str ");
scanf("%s",a);
printf("enter the sub str ");
scanf("%s",b);
int i,j;
int m=strlen(a);
int n=strlen(b);
for(i=0;i<=m-n;i++)
{
if(a[i]==b[0])
{
int  flag=0;
for(j=0;j<n;j++)
{
if(b[j]!=a[i+2*j])
{
flag=1;
break;
}
}
if(flag==0)
{
printf("%d",i);
}
else
{
printf("not present ");
}
}
}
}

/*if(b[j]==a[i+2*j])
{
flag=1;
break;
}
else
{
flag=0;
printf("not found");
}
}

if(flag==1)
{
printf("%d\n",i);
c++;
}
}
}
printf("%d",c);

}*/
