import java.util.*;
import java.math.*;
class kavya
{
int n,s;
int a[][];
int sum[];
Scanner in=new Scanner(System.in);
kavya(int n,int s)
{
this.n=n;
this.s=s;
a=new int[n+1][s+1];
sum=new int[n];
System.out.println("enter the array ");
for(int i=0;i<n;i++)
{
sum[i]=in.nextInt();
}
}
int subset(int n,int s)
{
for(int i=0;i<=n;i++)
{
for(int j=0;j<=s;j++)
{
if(i==0){
 a[i][j]= 0;
 continue;}
if(j==0){
 a[i][j]=1;
 continue;}
if(sum[i-1]<=j)
{
if(a[i-1][j-sum[i-1]]!=0||a[i-1][j]!=0){
 a[i][j]=1;
}
else
a[i][j]=0;
}
else
{
a[i][j]=a[i-1][j];
}
}
}
return a[n][s];
}
}
class sumsubset_table
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the n and s value ");
int n,s;
n=in.nextInt();
s=in.nextInt();
kavya k1=new kavya(n,s);
System.out.println(k1.subset(n,s));
}
}

