#include<stdio.h>
#include<string.h>
void main()
{
int flag=0;
char a[100];
char b[100];
printf("enter the first String ");
scanf("%s",a);
printf("enter the second String ");
scanf("%s",b);
int m=strlen(a);
int n=strlen(b);
for(int i=0;i<=m-n;i++)
if(a[i]==b[0])
{
int flag=0;
for(int j=0;j<n;j++)
{
if(b[j]!=a[i+j])
{
flag=1;
break;
}

if(flag==0)
{

printf("IS FOUND AT %d\n" ,i);
}
else
{
printf("not present %d",i);
}
}
}
}


