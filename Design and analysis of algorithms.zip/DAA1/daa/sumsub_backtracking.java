import java.util.*;
class back{
    int n;
    int a[];
    int wt[];
    int sum;
    Scanner in=new Scanner(System.in);
    public back(int n,int sum)
    {
        this.n=n;
        this.sum=sum;
        a=new int[n];
        wt=new int[n];
          System.out.println("enter the values");
          for(int i=0;i<n;i++)
          {
          wt[i]=in.nextInt();
          }

    }
     void  fill(int n,int k)
     {
        if(k==n)
        {
         print(a,n);
        System.out.println();
        return;
        }
        
       
        for(int i=0;i<=1;i++)
        {
           
                a[k]=i;
                 fill(n,k+1);  
        }

}
	void print(int a[],int n)
	{
	int s=0;
	for(int i=0;i<n;i++)
	{
	if(a[i]==1)
	{
	s=s+wt[i];
	}
	}
	if(s==sum)
	System.out.println("true");
	else
	System.out.println("false");
	
	}
     }
class test {
    public static void main(String args[])
    {
        Scanner in=new Scanner(System.in);
        System.out.println("enter the n");
        int n=in.nextInt();
        System.out.println("enter the sum");
	int sum=in.nextInt();
        back b=new back(n,sum);
    
        b.fill(n,0);
    }
}
