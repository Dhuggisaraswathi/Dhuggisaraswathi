import java.util.*;
class fibanocii
{
int n;
int[] a;
public fibanocii(int n)
{
this.n=n;
a=new int[n+1];
}
int fib(int n)
{
for(int i=0;i<=n;i++)
{
if(i==0||i==1)
a[i]=1;
else
a[i]=a[i-1]+a[i-2];
}
return a[n];
}
}
class Fib_tabular
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the n value ");
int n=in.nextInt();
fibanocii f=new fibanocii(n);
System.out.println(f.fib(n));
}
}

