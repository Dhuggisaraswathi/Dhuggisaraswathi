import java.util.*;
import java.math.*;
class kavya
{
int n,s;
int sum[];
int a[][];
Scanner in=new Scanner(System.in);
kavya(int n,int s)
{
this.n=n;
this.s=s;
sum=new int[n];
a=new int[n+1][s+1];
System.out.println("enter the array ");
for(int i=0;i<n;i++)
{
sum[i]=in.nextInt();
}
for(int i=0;i<n;i++)
{
for(int j=0;j<s;j++)
{
a[i][j]=-1;
}
}
}
int subset(int n,int s)
{
if(a[n][s]!=-1)
{
return a[n][s];
}
if(s==0)
return a[n][s]=1;

if(n==0)
return a[n][s]=0;

if(sum[n-1]<=s){

return subset(n-1,s-sum[n-1]) + subset(n-1,s);

 

}
else
return a[n][s]=subset(n-1,s);

}
}
class subset_ways_memo
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the n and s value ");
int n,s;
n=in.nextInt();
s=in.nextInt();
kavya k1=new kavya(n,s);
System.out.println(k1.subset(n,s));
}
}
