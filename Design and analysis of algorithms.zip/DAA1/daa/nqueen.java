import java.util.*;
class kavya
{
int n;
int a[];
Scanner in=new Scanner(System.in);
kavya(int n)
{
this.n=n;
a=new int[n];
System.out.println("enter the array ");
for(int i=0;i<n;i++)
{
a[i]=in.nextInt();
}
}
int fill(int n,int k)
{
if(k==n)
{
return 1;
}
for(int i=0;i<=n;i++)
{
if(issafe(k,i))
a[k]=i;
fill(n,k+1);
}
}
int issafe(int k ,int i)
{
for(int i=0;i<k;i++)
{
if(a[j]==i)
return 0;
if(


