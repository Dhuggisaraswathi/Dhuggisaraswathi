import java.util.*;
class string_match
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the Strings a and b ");
String a=in.nextLine();
String b=in.nextLine();
int m=a.length();
int n=b.length();
int flag=0;
for(int i=0;i<=m-n;i++)
{
if(a.charAt(i)==b.charAt(0))
{
for(int j=0;j<n;j++)
{
if(b.charAt(j)!=a.charAt(i+j))
{
flag=1;
break;
}
}
if(flag==0)
{
System.out.println("the index of that matching string is present= "+i);
}
else
{
System.out.println("not present ");
}
}

}
}

