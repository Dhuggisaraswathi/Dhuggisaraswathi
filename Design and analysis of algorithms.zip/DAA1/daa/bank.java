import java.util.*;
class bank{
String accountant_name;
int accountant_number;
double amount,withdraw,deposit;
bank(String s,double a,int i,double w,double d){
accountant_name= s;
amount =a;
accountant_number=i;
deposit =d;
withdraw=w;
}
void debit(double w){
if(w>amount){
System.out.println("insufficient balance");
}else{
//System.out.println("total amount after withdrawed"+withdraw+"is:"+amount);
double m=(amount-withdraw)+deposit;

System.out.println("balance amount :"+m);
}
}
void credit(double d){
double m=(amount+d);
System.out.println("accountant name:"+accountant_name);
System.out.println("accountant number:"+accountant_number);
System.out.println("total amount after deposited "+deposit+"is"+m);
}}
class banking
{
public static void main(String args[]){
Scanner s=new Scanner(System.in);
System.out.println("enter accountant_name:");
String name=s.nextLine();
System.out.println("enter accountant_number:");
int i=s.nextInt();
System.out.println("enter amount:");
double a=s.nextDouble();
System.out.println("enter withdrawl ammount:");
double w=s.nextDouble();
System.out.println("enter deposit amount:");
double d=s.nextDouble();
System.out.println("account details:");
bank ac=new bank(name,a,i,w,d);
ac.credit(d);
ac.debit(w);
}
}
