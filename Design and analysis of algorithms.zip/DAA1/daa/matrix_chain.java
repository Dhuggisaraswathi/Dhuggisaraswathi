import java.util.*;
class matrix
{
int n;
int a[];
//int i,j;
int min=Integer.MAX_VALUE;
Scanner in=new Scanner(System.in);
public matrix(int n)
{
this.n=n;
a=new int[n];
System.out.println("enter the array ");
for(int i=0;i<n;i++)
{
a[i]=in.nextInt();
}
}
int mcm(int i,int j)
{
int val;
//int val1,val2;
if(i==j)
{
return 0;
}
for(int k=i;k<j;k++)
{
//val2=a[i-1]*a[j]*a[k];
//val1=mcm(i,k)+mcm(k+1,j);
val=(mcm(i,k)+mcm(k+1,j)+a[i-1]*a[j]*a[k]);
//val=val1+val2;
if(val<min)
{
min=val;
}
}
return min;
}
}
class matrix_chain
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the array size ");
int n=in.nextInt();
matrix m1=new matrix(n);
System.out.println("enter the values of i and j");
int i=in.nextInt();
int j=in.nextInt();
System.out.println(m1.mcm(i,j));
}
}

