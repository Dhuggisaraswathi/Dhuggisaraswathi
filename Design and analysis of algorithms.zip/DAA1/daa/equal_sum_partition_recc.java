import java.util.*;
import java.math.*;
class kavya
{
int n;
int s;
int a[];
Scanner in=new Scanner(System.in);
public kavya(int n,int s)
{
this.n=n;
this.s=s;
a=new int[n];
System.out.println("enter the array");
for(int i=0;i<n;i++)
{
a[i]=in.nextInt();
}
}
int equal_sum(int n,int s)
{
int sum=0;
for(int i=0;i<n;i++)
{
sum=sum+a[i];
}
int avg=sum/2;
if(avg%2!=0){
return 0;}
else {
if(s==0)
return 1;
if(n==0)
return 0;
if(a[n-1]<=s)
{
return equal_sum(n-1,s-a[n-1])+equal_sum(n-1,s);
}
else
return equal_sum(n-1,s);
}
}
}
class equal_sum_partition_recc
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the n and s values ");
int n=in.nextInt();
int s=in.nextInt();
kavya k1=new kavya(n,s);
System.out.println(k1.equal_sum(n,s));
}
}



