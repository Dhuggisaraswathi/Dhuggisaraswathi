import java.util.*;
class kavya
{
int n;
int k;
char a[];
Scanner in=new Scanner(System.in);
kavya(int n)
{
this.n=n;
a=new char[n];
System.out.println("enter the array ");
for(int  i=0;i<n;i++)
{
a[i]=in.next().charAt(i);
}
}
int  fill(int n,int k)
{
if(k==n)
{
for(int i=0;i<n;i++)
{
System.out.println(a[i]);
}
return 1;//1;
}
for(char i='a';i<='c';i++)
{ 
if(issafe(k,i))
{
a[k]=i;
fill(n,k+1);
//return 1;
}
}
return 1;
}
boolean issafe(int k,char i)
{
for(int j=0;j<k;j++)
{
if(a[j]==i){
return false;}// 0;}
}
return true;// 1;
}
}
class Backtracking
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the array size ");
int n=in.nextInt();
kavya k1 =new kavya(n);
System.out.println(k1.fill(n,0));
}
}




