#include<stdio.h>
#include<math.h>
#include<limits.h>
#include<stdlib.h>
#include<float.h>

struct point {
    int x, y;
};

int indexi = 0, indexj = 0; // Global variables to store indices of closest points

// Function to calculate distance between two points
double distance(struct point p1, struct point p2) {
    return sqrt(pow((p1.x - p2.x), 2) + pow((p1.y - p2.y), 2));
}

// Function to find closest pair of points using brute-force method
double bruteforce(struct point *p, int st, int end) {
    double min = DBL_MAX; // Initialize min distance to a large value
    for (int i = st; i < end-1; i++) {
        for (int j = i + 1; j < end; j++) {
            double d = distance(p[i], p[j]);
            if (d < min) {
                min = d;
                indexi = i; // Update indices of closest points
                indexj = j;
            }
        }
    }
    return min;
}

// Function to find closest pair of points recursively
double closestpair(struct point *p, int st, int end) {
    if (end - st <= 3) {
        return bruteforce(p, st, end);
    }
    
    int mid = (st + end) / 2;
    double ld = closestpair(p, st, mid);
    double rd = closestpair(p, mid, end);
    double d = ld < rd ? ld : rd;
    
    // Gather points in strip that are within distance 'd' from the middle line
    struct point strip[end - st];
    int k = 0;
    for (int i = st; i < end; i++) {
        if (abs(p[i].x - p[mid].x) < d) {
            strip[k++] = p[i];
        }
    }
    
    // Find closest pair in the strip and update 'd' if needed
    for (int i = 0; i < k; i++) {
        for (int j = i + 1; j < k && (strip[j].y - strip[i].y) < d; j++) {
            double dist = distance(strip[i], strip[j]);
            if (dist < d) {
                d = dist;
                indexi = i + st; // Update indices of closest points
                indexj = j + st;
            }
        }
    }
    
    return d;
}

int main() {
    int n;
    printf("Enter number of points: ");
    scanf("%d", &n);
    
    struct point p[n];
    printf("Enter the points (x y): ");
    for (int i = 0; i < n; i++) {
        scanf("%d %d", &p[i].x, &p[i].y);
    }
    
    double min_dist = closestpair(p, 0, n);
    printf("Minimum distance between two points: %.2f\n", min_dist);
    printf("Closest points are: (%d, %d) and (%d, %d)\n", p[indexi].x, p[indexi].y, p[indexj].x, p[indexj].y);
    
    return 0;
}

