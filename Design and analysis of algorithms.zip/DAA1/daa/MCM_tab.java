import java.util.*;
import java.math.*;
class Mcm
{
int n;
int dp[][];
int a[];
Scanner in=new Scanner(System.in);
public Mcm(int n)
{
this.n=n;
System.out.println("enter the elements ");
a=new int[n+1];
dp=new int[n+1][n+1];
for(int i=0;i<n;i++)
{
a[i]=in.nextInt();
}
}
int mcm(int i,int j)
{
for(int l=0;l<n;l++)
{
for(i=1;i<=n-l;i++)
{
if(i==j)
{
dp[i][j]=0;
continue;
}
j=i+l;
int min=Integer.MAX_VALUE;
int val;
for(int k=i;k<j;k++)
{
val=dp[i][k]+dp[k+1][j]+a[i-1]*a[k]*a[j];
if(val<min)
{
min=val;
}
dp[i][j]=min;
}
}
}
return dp[1][n-1];
}
}
class MCM_tab
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the size of the array ");
int n=in.nextInt();
Mcm m1=new Mcm(n);
System.out.println(m1.mcm(1,n-1));
}
}

