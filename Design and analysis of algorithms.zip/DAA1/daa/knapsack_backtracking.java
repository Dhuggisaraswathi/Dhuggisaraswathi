import java.util.*;
class back{
    int n;
    int a[];
    int wt[];
    int val[];
    int w;
   int max=Integer.MIN_VALUE;
    Scanner in=new Scanner(System.in);
    public back(int n)
    {
        this.n=n;
        this.w=w;
        a=new int[n];
        wt=new int[n];
        val=new int[n];
           System.out.println("enter the capicity of bag weight ");
        int w=in.nextInt();
     
        System.out.println("enter the weights  ");
       
        for(int i=0;i<n;i++)
        {
        wt[i]=in.nextInt();
        }
        
        System.out.println("enter the values ");
        
        for(int i=0;i<n;i++)
        {
        val[i]=in.nextInt();
        }
      

    }
     void  fill(int n,int k)
     {
        if(k==n)
        {
    	 print(a,n,w,max);
    	 
        System.out.println();
        return;
        }
             for(int i=0;i<=1;i++)
        {
           
                a[k]=i;
                 fill(n,k+1);  
        }
        //return;
        }
       
      void print(int a[],int n,int w,int max)
      {
      int ws=0;
      int vs=0;
      for(int i=0;i<n;i++)
      {
      if(a[i]==1)
      {
      ws=ws+wt[i];
      vs=vs+val[i];
      }
      }
      if(ws<=w)
      {
      if(vs>max)
      {
      max=vs;
      }
      }
      System.out.println(max);
      
      }
      }
class test {
    public static void main(String args[])
    {
        Scanner in=new Scanner(System.in);
        System.out.println("enter the n");
        int n=in.nextInt();
     
        

        
        back b=new back(n);
    
        b.fill(n,0);
    }
}
