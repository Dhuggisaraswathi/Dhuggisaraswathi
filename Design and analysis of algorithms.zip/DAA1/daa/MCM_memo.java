import java.util.*;
import java.math.*;
class Mcm
{
int a[];
int dp[][];
int n;
Scanner in=new Scanner(System.in);
public Mcm(int n)
{
dp=new int[n][n];
a=new int[n];
this.n=n;
System.out.println("enter the array");
for(int i=0;i<n;i++)
{
a[i]=in.nextInt();
}
for(int i=0;i<n;i++)
{
for(int j=0;j<n;j++)
{
dp[i][j]=-1;
}
}
}
int mcm(int i,int j)
{
if(dp[i][j]!=-1)
{
return dp[i][j];
}
if(i==j)
{
return dp[i][j]=0;
}
int min=Integer.MAX_VALUE;
int val;
for(int k=i;k<j;k++)
{
val=mcm(i,k)+mcm(k+1,j)+a[i-1]*a[k]*a[j];
if(val<min)
{
min=val;
}
}
return dp[i][j]=min;
}
}


class MCM_memo
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the size ");
int n=in.nextInt();
Mcm m1=new Mcm(n);
System.out.println(m1.mcm(1,n-1));
}
}


