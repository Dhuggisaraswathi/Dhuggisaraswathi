import java.util.*;
class kavya
{
int n;
int w;
int[] val;
int[] wt;
int[][] a;
Scanner in=new Scanner(System.in);
public kavya(int n,int w)
{
this.n=n;
this.w=w;
val=new int[n];
wt=new int[n];
a=new int[n+1][w+1];
System.out.println("enter the weight ");
for(int i=0;i<n;i++)
{
wt[i]=in.nextInt();
}
System.out.println("enter the values ");
for(int i=0;i<n;i++)
{
val[i]=in.nextInt();
}

}
int ks(int n,int w)
{
for(int i=0;i<=n;i++)
{
for(int j=0;j<=w;j++)
{
if(i==0||j==0)
a[i][j]=0;
if(wt[i-1]<=j)
{
a[i][j]=Math.max(val[i-1]+a[i-1][j-wt[i-1]],a[i-1][j]);
}
else
a[i][j]=a[i-1][j];
}
}
return a[n][w];
}
}
class knapsack_tabular
{
public static void main(String agrs[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the no of items  and weight of bag ");
int n=in.nextInt();
int w=in.nextInt();
kavya k1=new kavya(n,w);
System.out.println(k1.ks(n,w));
}
} 

