#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<limits.h>
struct point
{
int x,y;
};
int main()
{
int n,d,index;
printf("enter the no villages ");
scanf("%d",&n);
struct point p[n];
double avg_dist=INT_MAX;
for(int i=0;i<n;i++)
{
scanf("%d%d",&p[i].x,&p[i].y);
}
for(int i=0;i<n;i++)
{
float sum=0;
for(int j=0;j<n;j++)
{
d=sqrt(pow((p[j].x-p[i].x),2)+pow((p[j].y-p[i].x),2));
sum=sum+d;
}
double avg=sum/n;
if(avg_dist<avg)
{
avg_dist=avg;
index=i;
}
}
printf("At these points we can construct msnl company (%d,%d) ",p[index].x,p[index].y);
printf("the avg distance = %f ", avg_dist);
}

