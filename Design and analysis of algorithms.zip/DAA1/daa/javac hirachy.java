//hirachy.java
import java.util.*;
class parent
{
int a=30;
int b=80;
int x=a+b;
void display()
{
     System.out.println("parent:"+x);
 }
 }
 class child1 extends parent
 {
 int m=14;
 int n=22;
 int y=m+n;
 void show()
 {
    System.out.println("child1:"+y);}
   }
   class child2 extends parent
   {
   int p=24;
   int q=54;
   int z=p+q;
   void disk()
   {
     System.out.println("child2:"+z);
     }
     }
     class hirachy
     {
       public static void main(String args[])
       {
       child1 obj=new child();
       obj1.show();
       obj1.display();
       child2 obj=new child2();
       obj2.disk();
       obj1.display();
       }
       }
       
