#include<stdio.h>
#include<limits.h>
#include<math.h>
struct point
{
int x;
int y;
};
int main()
{
int n,d;
printf("enter the number of points ");
scanf("%d" ,&n);
struct point p[n];
printf("enter the points ");
int min=INT_MAX;
for(int i=0;i<n;i++)
{
scanf("%d%d",&p[i].x,&p[i].y);
}
int indexi,indexj;
for(int i=0;i<n-1;i++)
{
for(int j=i+1;j<n;j++)
{
d=sqrt(pow((p[i].x-p[j].x),2)+pow((p[i].y-p[j].y),2));
if(d<min)
{
min=d;
indexi=i;
indexj=j;
}
}
}
printf("min distance=%d , point 1=%d ,point 2=%d ",min,indexi,indexj);
}
