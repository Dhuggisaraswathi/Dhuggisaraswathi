import java.util.*;
class matrix
{
int n;
int a[];
int dp[][];
int min=Integer.MAX_VALUE;
Scanner in=new Scanner(System.in);
public matrix(int n)
{
this.n=n;
a=new int[n];
dp=new int[n][n];
System.out.println("enter the array ");
for(int i=0;i<n;i++)
{
a[i]=in.nextInt();
}
for(int i=0;i<n;i++)
{
for(int j=0;j<n;j++)
{
dp[i][j]=-1;
}
}
}
int mcm(int i,int j)
{
int val;
if(dp[i][j]!=-1)
{
return dp[i][j];
}
if(i==j)
{
return dp[i][j]=0;
}
for(int k=i;k<j;k++)
{
val=mcm(i,k)+mcm(k+1,j)+a[i-1]*a[j]*a[k];
if(val<min)
{
min=val;
}
}
return dp[i][j]=min;
}
}
class test
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the array size ");
int n=in.nextInt();
System.out.println("enter the i value and j value ");
int i=in.nextInt();
int j=in.nextInt();
matrix m1=new matrix(n);
System.out.println(m1.mcm(i,j));
}
}


