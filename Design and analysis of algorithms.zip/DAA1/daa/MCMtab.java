import java.util.*;
import java.math.*;
class mem{
int dp[][];
int a[];
int n;
Scanner in=new Scanner(System.in); 
public mem(int n)
{
this.n=n;
a=new int[n+1];
dp=new int[n+1][n+1];
System.out.println("Enter the array");
for(int i=0;i<n;i++)
{
a[i]=in.nextInt();
}
}


int mcm(int i,int j)
{
for(int l=0;l<n;l++)
{
for( i=1;i<=n-l;i++)
{
if(i==j)
{
dp[i][j]=0;
continue;
}
j=i+l;
int min=Integer.MAX_VALUE;
for(int k=i;k<j;k++)
{
int val=dp[i][k]+dp[k+1][j]+a[i-1]*a[k]*a[j];
if(val<min)
{
min=val;
}
dp[i][j]=min;
}
}
}
return dp[1][n-1];
}
}

class test{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the n");
int n;
n=in.nextInt();
matrix m=new matrix(n);
System.out.println(m.mcm(1,n-1));
}
}



