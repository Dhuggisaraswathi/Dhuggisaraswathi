#include<stdio.h>
#include<math.h>
#include<limits.h>
#include<stdlib.h>
#include<float.h>
double min;
int indexi=0,indexj=0,mid;
struct point
{
int x,y;
};
int bruteforce(struct point *p,int st,int end)
{
int d;
min=DBL_MAX;
for(int i=st;i<end-1;i++)
{
for(int j=i+1;j<end;j++)
{
d=sqrt(pow((p[i].x-p[j].x),2)+pow((p[i].y-p[j].y),2));
if(min<d)
{
min=d;
indexi=i+1;
indexj=j+2;
}
}
}
return min;
}
int closestpair(struct point *p,int st,int end)
{
struct point s[20];
int k=0,ld,rd,bd,d;
if(end>st+1)
{
mid=(st+end)/2;
ld=closestpair(p,st,mid);
rd=closestpair(p,mid+1,end);
d=ld>rd?rd:ld;
for(int i=st;i<=end ;i++)
{
if(abs(p[i].x-p[mid].x<d))
{
s[k++]=p[i];
}
}
bd=bruteforce(s,0,k);
return bd>d?d:bd;
}
else
return bruteforce(p,st,end);
}
int main()
{
double min;
int n,d,indexi,indexj;
printf("enter no of points ");
scanf("%d",&n);
struct point p[n];
printf("enter the points ");
for(int i=0;i<n;i++)
{
scanf("%d%d",&p[i].x,&p[i].y);
}
min=closestpair(p,0,n);
printf("minimum shortest distance = %lf\n ",min);
printf("point 1=%d",indexi);
printf("point 2=%d",indexj);
return 0;
}

