#include<stdio.h>
#include<string.h>
#include<limits.h>
#include<math.h>
struct hospital
{
int x,y;
};
void main()
{
int n,d;
double avg;
printf("enter the no of points");
scanf("%d",&n);
struct hospital h[n];
for(int i=0;i<n;i++)
{
scanf("%d%d",&h[i].x,&h[i].y);
}
double avgmin=INT_MAX;
int index;
double sum=0;
for(int i=0;i<n-1;i++)
{
for(int j=i+1;j<n;j++)
{
d=sqrt(pow((h[j].x-h[i].x),2)-pow((h[j].y-h[i].y),2));
sum=sum+d;
}
avg=sum/(n-1);
if(avgmin>avg)
{
avgmin=avg;
index=i;
}
}
printf("%lf is min avg and points are (%d,%d)",avgmin,h[index].x,h[index].y);
}
