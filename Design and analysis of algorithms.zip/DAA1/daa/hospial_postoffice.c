#include<stdio.h>
#include<stdlib.h>
#include<math.h>
struct point
{
int x,y;
};
int main()
{
int n,index;
double avg;
printf("enter the number of points ");
scanf("%d",&n);
struct point p[n];
double avg_dist=INT_MIN;
for(int i=0;i<n;i++)
{
scanf("%d%d",&p[i].x,&p[i].y);
}
for(int i=0;i<n;i++)
{
float sum=0;
for(int j=0;j<n;j++)
{
d=sqrt(pow((p[j].x-p[i].x),2)+pow((p[j].y-p[i].y),2));
sum=sum+d;
}
avg=sum/n;
if(avg_dist<avg)
{
avg_dist=avg;
index=i;
}
}
printf("At point we can construct hospital or postoffice (%d,%d)",p[index].x,p[index].y);
printf("the average distance= %d ",avg_dist);
}
