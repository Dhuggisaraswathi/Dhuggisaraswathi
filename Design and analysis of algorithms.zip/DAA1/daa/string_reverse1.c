#include<stdio.h>
#include<string.h>
int main()
{
int flag=0;
char a[100];
char b[100];

printf("enter the String 1 ");
scanf("%s",a);
printf("enter the String 2");
scanf("%s",b);
int m=strlen(a);
int n=strlen(a);
int i,j;
int temp;
for(i=0,j=n-1;i<=j;i++,j--)
{
temp=b[i];
b[i]=b[j];
b[j]=temp;
}
printf("%s",b);
printf("hello");
}
