import java.util.*;
import java.math.*;
class Mcm
{
int a[];
int n;
Scanner in=new Scanner(System.in);
public Mcm(int n)
{
this.n=n;
System.out.println("enter the elements ");
a=new int[n];
for(int i=0;i<n;i++)
{
a[i]=in.nextInt();
}
}
int mcm(int p, int q)
{
if(p==q)
{
return 0;
}
int min=Integer.MAX_VALUE;
int val;
for(int k=p;k<q;k++)
{
val=mcm(p,k)+mcm(k+1,q)+a[p-1]*a[k]*a[q];
if(val<min)
{
min=val;
}
}
return min;
}
}
class MCM_rec
{
public static void main(String args[])
{
Scanner in=new Scanner(System.in);
System.out.println("enter the size of the array ");
int n=in.nextInt();
Mcm m1=new Mcm(n);
System.out.println(m1.mcm(1,n-1));
}
}

