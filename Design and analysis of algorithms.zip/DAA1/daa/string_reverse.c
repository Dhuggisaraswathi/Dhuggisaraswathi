#include<stdio.h>
#include<string.h>
/*void reverse(char*b,int n)
{
int i,j,temp;

/*for(i=0;i<n/2;i++)
{
temp=b[i];
b[i]=b[n-i-1];
b[n-i-1]=temp;
}
for(i=0,j=n-1;i<=j;i++,j--)
{
temp=b[i];
b[i]=b[j];
b[j]=temp;
}
printf("%s",b);
}*/
int main()
{
char a[100];
char b[100];
printf("enter the a string ");
scanf("%s",a);
printf("enter the b sub string of a   :");
scanf("%s",b);
int m=strlen(a);
int n=strlen(b);
//reverse(b,n);
int i,j;
int temp;

for(i=0,j=n-1;i<=j;i++,j--)
{
temp=b[i];
b[i]=b[j];
b[j]=temp;
}
printf("%s",b);

int flag=0;

for(i=0;i<=m-n;i++)
{
if(a[i]==b[0])
{
int  flag=0;
for(j=0;j<n;j++)
{
if(b[j]!=a[i+j])
{
flag=1;
break;
}
}

if(flag==0)
{
printf("%d\n",i);
}
}
}
}





