#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<limits.h>
struct point
{
int x,y;
};
int main()
{
int n;
int a,b,c;
printf("enter the no of points ");
scanf("%d",&n);
struct point p[n];
for(int i=0;i<n;i++)
{
scanf("%d%d", &p[i].x,&p[i].y);
}
for(int i=0;i<n-1;i++)
{
for(int j=i+1;j<n;j++)
{
a=p[j].y-p[i].y;
b=p[j].x-p[i].x;
c=p[i].x*p[j].y-p[i].y*p[j].x;
}
}
int nn=0;//negative
int np=0;
int val;
for(int i=0;i<n;i++)
{
val=a*p[i].x+b*p[i].y-c;
if(val<0)
nn++;
else if(val>0)
np++;
if(nn==0||np==0)
printf("the convex hall points are %d,%d,%d,%d ",p[i].x,p[i].y,p[j].x,p[j].y);
}
}
